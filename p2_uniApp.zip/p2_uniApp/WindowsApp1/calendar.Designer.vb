﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class cal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.menuItem41 = New System.Windows.Forms.MenuItem()
        Me.menuItem18 = New System.Windows.Forms.MenuItem()
        Me.menuItem32 = New System.Windows.Forms.MenuItem()
        Me.menuItem33 = New System.Windows.Forms.MenuItem()
        Me.menuItem34 = New System.Windows.Forms.MenuItem()
        Me.menuItem35 = New System.Windows.Forms.MenuItem()
        Me.menuItem36 = New System.Windows.Forms.MenuItem()
        Me.menuItem37 = New System.Windows.Forms.MenuItem()
        Me.menuItem22 = New System.Windows.Forms.MenuItem()
        Me.menuItem29 = New System.Windows.Forms.MenuItem()
        Me.menuItem30 = New System.Windows.Forms.MenuItem()
        Me.menuItem31 = New System.Windows.Forms.MenuItem()
        Me.menuItem28 = New System.Windows.Forms.MenuItem()
        Me.menuItem38 = New System.Windows.Forms.MenuItem()
        Me.menuItem39 = New System.Windows.Forms.MenuItem()
        Me.menuItem40 = New System.Windows.Forms.MenuItem()
        Me.menuItem20 = New System.Windows.Forms.MenuItem()
        Me.MenuItem43 = New System.Windows.Forms.MenuItem()
        Me.menuItem21 = New System.Windows.Forms.MenuItem()
        Me.MenuItem44 = New System.Windows.Forms.MenuItem()
        Me.menuItem42 = New System.Windows.Forms.MenuItem()
        Me.menuItem24 = New System.Windows.Forms.MenuItem()
        Me.menuItem19 = New System.Windows.Forms.MenuItem()
        Me.ScheduleControl1 = New Syncfusion.Windows.Forms.Schedule.ScheduleControl()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu(Me.components)
        Me.menuItem1 = New System.Windows.Forms.MenuItem()
        Me.menuItem2 = New System.Windows.Forms.MenuItem()
        Me.menuItem4 = New System.Windows.Forms.MenuItem()
        Me.menuItem3 = New System.Windows.Forms.MenuItem()
        Me.menuItem25 = New System.Windows.Forms.MenuItem()
        Me.menuItem27 = New System.Windows.Forms.MenuItem()
        Me.menuItem26 = New System.Windows.Forms.MenuItem()
        Me.menuItem5 = New System.Windows.Forms.MenuItem()
        Me.menuItem6 = New System.Windows.Forms.MenuItem()
        Me.menuItem7 = New System.Windows.Forms.MenuItem()
        Me.menuItem8 = New System.Windows.Forms.MenuItem()
        Me.menuItem9 = New System.Windows.Forms.MenuItem()
        Me.menuItem10 = New System.Windows.Forms.MenuItem()
        Me.menuItem11 = New System.Windows.Forms.MenuItem()
        Me.menuItem12 = New System.Windows.Forms.MenuItem()
        Me.menuItem13 = New System.Windows.Forms.MenuItem()
        Me.menuItem14 = New System.Windows.Forms.MenuItem()
        Me.menuItem15 = New System.Windows.Forms.MenuItem()
        Me.menuItem16 = New System.Windows.Forms.MenuItem()
        Me.menuItem17 = New System.Windows.Forms.MenuItem()
        Me.menuItem23 = New System.Windows.Forms.MenuItem()
        Me.SuspendLayout()
        '
        'menuItem41
        '
        Me.menuItem41.Index = 1
        Me.menuItem41.Text = "Load..."
        '
        'menuItem18
        '
        Me.menuItem18.Index = 1
        Me.menuItem18.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem32, Me.menuItem33, Me.menuItem34, Me.menuItem35, Me.menuItem36, Me.menuItem37})
        Me.menuItem18.Text = "Culture"
        '
        'menuItem32
        '
        Me.menuItem32.Index = 0
        Me.menuItem32.Text = "Invariant"
        '
        'menuItem33
        '
        Me.menuItem33.Index = 1
        Me.menuItem33.Text = "Application"
        '
        'menuItem34
        '
        Me.menuItem34.Index = 2
        Me.menuItem34.Text = "fr-FR"
        '
        'menuItem35
        '
        Me.menuItem35.Index = 3
        Me.menuItem35.Text = "it-IT"
        '
        'menuItem36
        '
        Me.menuItem36.Index = 4
        Me.menuItem36.Text = "en-US"
        '
        'menuItem37
        '
        Me.menuItem37.Index = 5
        Me.menuItem37.Text = "de-DE"
        '
        'menuItem22
        '
        Me.menuItem22.Index = 2
        Me.menuItem22.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem29, Me.menuItem30, Me.menuItem31})
        Me.menuItem22.Text = "Navigation Panel"
        '
        'menuItem29
        '
        Me.menuItem29.Index = 0
        Me.menuItem29.Text = "Hidden"
        '
        'menuItem30
        '
        Me.menuItem30.Index = 1
        Me.menuItem30.Text = "Left"
        '
        'menuItem31
        '
        Me.menuItem31.Index = 2
        Me.menuItem31.Text = "Right"
        '
        'menuItem28
        '
        Me.menuItem28.Index = 3
        Me.menuItem28.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem38, Me.menuItem39, Me.menuItem40})
        Me.menuItem28.Text = "Save on Close"
        '
        'menuItem38
        '
        Me.menuItem38.Index = 0
        Me.menuItem38.Text = "Do Not Save"
        '
        'menuItem39
        '
        Me.menuItem39.Index = 1
        Me.menuItem39.Text = "Prompt Before Saving"
        '
        'menuItem40
        '
        Me.menuItem40.Index = 2
        Me.menuItem40.Text = "Save Without Prompt"
        '
        'menuItem20
        '
        Me.menuItem20.Checked = True
        Me.menuItem20.Index = 4
        Me.menuItem20.Text = "Week Numbers"
        '
        'MenuItem43
        '
        Me.MenuItem43.Index = 5
        Me.MenuItem43.Text = "Alerts"
        '
        'menuItem21
        '
        Me.menuItem21.Index = 6
        Me.menuItem21.Text = "Additional Panel"
        '
        'MenuItem44
        '
        Me.MenuItem44.Index = 7
        Me.MenuItem44.Text = "Test"
        '
        'menuItem42
        '
        Me.menuItem42.Index = 2
        Me.menuItem42.Text = "Save..."
        '
        'menuItem24
        '
        Me.menuItem24.Index = 0
        Me.menuItem24.Text = "About..."
        '
        'menuItem19
        '
        Me.menuItem19.Index = 0
        Me.menuItem19.Text = "Change..."
        '
        'ScheduleControl1
        '
        Me.ScheduleControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ScheduleControl1.Appearance.WeekHeaderFormat = "MMMM dd"
        Me.ScheduleControl1.Appearance.WeekMonthFullFormat = "dddd, dd MMMM yyyy"
        Me.ScheduleControl1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.ScheduleControl1.Culture = New System.Globalization.CultureInfo("")
        Me.ScheduleControl1.DataSource = Nothing
        Me.ScheduleControl1.ISO8601CalenderFormat = False
        Me.ScheduleControl1.Location = New System.Drawing.Point(25, 12)
        Me.ScheduleControl1.Name = "ScheduleControl1"
        Me.ScheduleControl1.Size = New System.Drawing.Size(1013, 576)
        Me.ScheduleControl1.TabIndex = 4
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem6, Me.menuItem11, Me.menuItem16, Me.menuItem23})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem2, Me.menuItem4, Me.menuItem3, Me.menuItem25, Me.menuItem27, Me.menuItem26, Me.menuItem5})
        Me.menuItem1.Text = "File"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 0
        Me.menuItem2.Text = "Open Calendar..."
        '
        'menuItem4
        '
        Me.menuItem4.Index = 1
        Me.menuItem4.Text = "New Calendar..."
        '
        'menuItem3
        '
        Me.menuItem3.Index = 2
        Me.menuItem3.Text = "Save Calendar"
        '
        'menuItem25
        '
        Me.menuItem25.Index = 3
        Me.menuItem25.Text = "Save Calendar as..."
        '
        'menuItem27
        '
        Me.menuItem27.Index = 4
        Me.menuItem27.Text = "Merge Calendar..."
        '
        'menuItem26
        '
        Me.menuItem26.Index = 5
        Me.menuItem26.Text = "Random Data"
        '
        'menuItem5
        '
        Me.menuItem5.Index = 6
        Me.menuItem5.Text = "Exit"
        '
        'menuItem6
        '
        Me.menuItem6.Index = 1
        Me.menuItem6.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem7, Me.menuItem8, Me.menuItem9, Me.menuItem10})
        Me.menuItem6.Text = "Edit"
        '
        'menuItem7
        '
        Me.menuItem7.Index = 0
        Me.menuItem7.Text = "New Item"
        '
        'menuItem8
        '
        Me.menuItem8.Index = 1
        Me.menuItem8.Text = "New AllDay Item"
        '
        'menuItem9
        '
        Me.menuItem9.Index = 2
        Me.menuItem9.Text = "Edit Item"
        '
        'menuItem10
        '
        Me.menuItem10.Index = 3
        Me.menuItem10.Text = "Delete Item"
        '
        'menuItem11
        '
        Me.menuItem11.Index = 2
        Me.menuItem11.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem12, Me.menuItem13, Me.menuItem14, Me.menuItem15})
        Me.menuItem11.Text = "View"
        '
        'menuItem12
        '
        Me.menuItem12.Index = 0
        Me.menuItem12.Text = "Day"
        '
        'menuItem13
        '
        Me.menuItem13.Index = 1
        Me.menuItem13.Text = "Workweek"
        '
        'menuItem14
        '
        Me.menuItem14.Index = 2
        Me.menuItem14.Text = "Week"
        '
        'menuItem15
        '
        Me.menuItem15.Index = 3
        Me.menuItem15.Text = "Month"
        '
        'menuItem16
        '
        Me.menuItem16.Index = 3
        Me.menuItem16.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem17, Me.menuItem18, Me.menuItem22, Me.menuItem28, Me.menuItem20, Me.MenuItem43, Me.menuItem21, Me.MenuItem44})
        Me.menuItem16.Text = "Options"
        '
        'menuItem17
        '
        Me.menuItem17.Index = 0
        Me.menuItem17.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem19, Me.menuItem41, Me.menuItem42})
        Me.menuItem17.Text = "Appearance..."
        '
        'menuItem23
        '
        Me.menuItem23.Index = 4
        Me.menuItem23.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem24})
        Me.menuItem23.Text = "Help"
        '
        'calendar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1116, 736)
        Me.Controls.Add(Me.ScheduleControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Menu = Me.mainMenu1
        Me.Name = "calendar"
        Me.Text = "calendar"
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents menuItem41 As MenuItem
    Private WithEvents menuItem18 As MenuItem
    Private WithEvents menuItem32 As MenuItem
    Private WithEvents menuItem33 As MenuItem
    Private WithEvents menuItem34 As MenuItem
    Private WithEvents menuItem35 As MenuItem
    Private WithEvents menuItem36 As MenuItem
    Private WithEvents menuItem37 As MenuItem
    Private WithEvents menuItem22 As MenuItem
    Private WithEvents menuItem29 As MenuItem
    Private WithEvents menuItem30 As MenuItem
    Private WithEvents menuItem31 As MenuItem
    Private WithEvents menuItem28 As MenuItem
    Private WithEvents menuItem38 As MenuItem
    Private WithEvents menuItem39 As MenuItem
    Private WithEvents menuItem40 As MenuItem
    Private WithEvents menuItem20 As MenuItem
    Friend WithEvents MenuItem43 As MenuItem
    Private WithEvents menuItem21 As MenuItem
    Friend WithEvents MenuItem44 As MenuItem
    Private WithEvents menuItem42 As MenuItem
    Private WithEvents menuItem24 As MenuItem
    Private WithEvents menuItem19 As MenuItem
    Private WithEvents ScheduleControl1 As Syncfusion.Windows.Forms.Schedule.ScheduleControl
    Private WithEvents mainMenu1 As MainMenu
    Private WithEvents menuItem1 As MenuItem
    Private WithEvents menuItem2 As MenuItem
    Private WithEvents menuItem4 As MenuItem
    Private WithEvents menuItem3 As MenuItem
    Private WithEvents menuItem25 As MenuItem
    Private WithEvents menuItem27 As MenuItem
    Private WithEvents menuItem26 As MenuItem
    Private WithEvents menuItem5 As MenuItem
    Private WithEvents menuItem6 As MenuItem
    Private WithEvents menuItem7 As MenuItem
    Private WithEvents menuItem8 As MenuItem
    Private WithEvents menuItem9 As MenuItem
    Private WithEvents menuItem10 As MenuItem
    Private WithEvents menuItem11 As MenuItem
    Private WithEvents menuItem12 As MenuItem
    Private WithEvents menuItem13 As MenuItem
    Private WithEvents menuItem14 As MenuItem
    Private WithEvents menuItem15 As MenuItem
    Private WithEvents menuItem16 As MenuItem
    Private WithEvents menuItem17 As MenuItem
    Private WithEvents menuItem23 As MenuItem
End Class
