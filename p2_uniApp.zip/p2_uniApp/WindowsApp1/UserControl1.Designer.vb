﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl1
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UserControl1))
        Me.GunaLinePanel1 = New Guna.UI.WinForms.GunaLinePanel()
        Me.GunaPictureBox6 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaLabel4 = New Guna.UI.WinForms.GunaLabel()
        Me.GunaLabel3 = New Guna.UI.WinForms.GunaLabel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GunaPictureBox5 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaPictureBox4 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaPictureBox3 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaPictureBox2 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaPictureBox1 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaSeparator1 = New Guna.UI.WinForms.GunaSeparator()
        Me.GunaLabel2 = New Guna.UI.WinForms.GunaLabel()
        Me.GunaLabel1 = New Guna.UI.WinForms.GunaLabel()
        Me.GunaCircleButton2 = New Guna.UI.WinForms.GunaCircleButton()
        Me.SfToolTip1 = New Syncfusion.Windows.Forms.SfToolTip(Me.components)
        Me.GunaLinePanel1.SuspendLayout()
        CType(Me.GunaPictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GunaPictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GunaPictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GunaPictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GunaPictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GunaPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GunaLinePanel1
        '
        Me.GunaLinePanel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(251, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.GunaLinePanel1.Controls.Add(Me.GunaPictureBox6)
        Me.GunaLinePanel1.Controls.Add(Me.GunaLabel4)
        Me.GunaLinePanel1.Controls.Add(Me.GunaLabel3)
        Me.GunaLinePanel1.Controls.Add(Me.Label1)
        Me.GunaLinePanel1.Controls.Add(Me.GunaPictureBox5)
        Me.GunaLinePanel1.Controls.Add(Me.GunaPictureBox4)
        Me.GunaLinePanel1.Controls.Add(Me.GunaPictureBox3)
        Me.GunaLinePanel1.Controls.Add(Me.GunaPictureBox2)
        Me.GunaLinePanel1.Controls.Add(Me.GunaPictureBox1)
        Me.GunaLinePanel1.Controls.Add(Me.GunaSeparator1)
        Me.GunaLinePanel1.Controls.Add(Me.GunaLabel2)
        Me.GunaLinePanel1.Controls.Add(Me.GunaLabel1)
        Me.GunaLinePanel1.Controls.Add(Me.GunaCircleButton2)
        Me.GunaLinePanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GunaLinePanel1.LineColor = System.Drawing.Color.Red
        Me.GunaLinePanel1.LineStyle = System.Windows.Forms.BorderStyle.None
        Me.GunaLinePanel1.Location = New System.Drawing.Point(0, 0)
        Me.GunaLinePanel1.Name = "GunaLinePanel1"
        Me.GunaLinePanel1.Size = New System.Drawing.Size(1203, 51)
        Me.GunaLinePanel1.TabIndex = 3
        '
        'GunaPictureBox6
        '
        Me.GunaPictureBox6.BackgroundImage = CType(resources.GetObject("GunaPictureBox6.BackgroundImage"), System.Drawing.Image)
        Me.GunaPictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaPictureBox6.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaPictureBox6.Location = New System.Drawing.Point(1111, 11)
        Me.GunaPictureBox6.Name = "GunaPictureBox6"
        Me.GunaPictureBox6.Size = New System.Drawing.Size(30, 30)
        Me.GunaPictureBox6.TabIndex = 23
        Me.GunaPictureBox6.TabStop = False
        Me.GunaPictureBox6.Visible = False
        '
        'GunaLabel4
        '
        Me.GunaLabel4.AutoSize = True
        Me.GunaLabel4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaLabel4.ForeColor = System.Drawing.Color.DarkRed
        Me.GunaLabel4.Location = New System.Drawing.Point(507, 20)
        Me.GunaLabel4.Name = "GunaLabel4"
        Me.GunaLabel4.Size = New System.Drawing.Size(20, 15)
        Me.GunaLabel4.TabIndex = 22
        Me.GunaLabel4.Text = "siz"
        Me.GunaLabel4.Visible = False
        '
        'GunaLabel3
        '
        Me.GunaLabel3.AutoSize = True
        Me.GunaLabel3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaLabel3.ForeColor = System.Drawing.Color.DarkRed
        Me.GunaLabel3.Location = New System.Drawing.Point(667, 20)
        Me.GunaLabel3.Name = "GunaLabel3"
        Me.GunaLabel3.Size = New System.Drawing.Size(116, 15)
        Me.GunaLabel3.TabIndex = 21
        Me.GunaLabel3.Text = "Τύπος Αρχείο:EXCEL"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(230, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Label1"
        Me.Label1.Visible = False
        '
        'GunaPictureBox5
        '
        Me.GunaPictureBox5.BackgroundImage = CType(resources.GetObject("GunaPictureBox5.BackgroundImage"), System.Drawing.Image)
        Me.GunaPictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaPictureBox5.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox5.Location = New System.Drawing.Point(10, 11)
        Me.GunaPictureBox5.Name = "GunaPictureBox5"
        Me.GunaPictureBox5.Size = New System.Drawing.Size(30, 30)
        Me.GunaPictureBox5.TabIndex = 19
        Me.GunaPictureBox5.TabStop = False
        Me.GunaPictureBox5.Visible = False
        '
        'GunaPictureBox4
        '
        Me.GunaPictureBox4.BackgroundImage = CType(resources.GetObject("GunaPictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.GunaPictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaPictureBox4.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox4.Location = New System.Drawing.Point(10, 11)
        Me.GunaPictureBox4.Name = "GunaPictureBox4"
        Me.GunaPictureBox4.Size = New System.Drawing.Size(30, 30)
        Me.GunaPictureBox4.TabIndex = 18
        Me.GunaPictureBox4.TabStop = False
        Me.GunaPictureBox4.Visible = False
        '
        'GunaPictureBox3
        '
        Me.GunaPictureBox3.BackgroundImage = CType(resources.GetObject("GunaPictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.GunaPictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaPictureBox3.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox3.Location = New System.Drawing.Point(10, 11)
        Me.GunaPictureBox3.Name = "GunaPictureBox3"
        Me.GunaPictureBox3.Size = New System.Drawing.Size(30, 30)
        Me.GunaPictureBox3.TabIndex = 17
        Me.GunaPictureBox3.TabStop = False
        Me.GunaPictureBox3.Visible = False
        '
        'GunaPictureBox2
        '
        Me.GunaPictureBox2.BackgroundImage = CType(resources.GetObject("GunaPictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.GunaPictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaPictureBox2.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox2.Location = New System.Drawing.Point(10, 11)
        Me.GunaPictureBox2.Name = "GunaPictureBox2"
        Me.GunaPictureBox2.Size = New System.Drawing.Size(30, 30)
        Me.GunaPictureBox2.TabIndex = 16
        Me.GunaPictureBox2.TabStop = False
        Me.GunaPictureBox2.Visible = False
        '
        'GunaPictureBox1
        '
        Me.GunaPictureBox1.BackgroundImage = CType(resources.GetObject("GunaPictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.GunaPictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaPictureBox1.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox1.Location = New System.Drawing.Point(10, 11)
        Me.GunaPictureBox1.Name = "GunaPictureBox1"
        Me.GunaPictureBox1.Size = New System.Drawing.Size(30, 30)
        Me.GunaPictureBox1.TabIndex = 15
        Me.GunaPictureBox1.TabStop = False
        Me.GunaPictureBox1.Visible = False
        '
        'GunaSeparator1
        '
        Me.GunaSeparator1.LineColor = System.Drawing.Color.Silver
        Me.GunaSeparator1.Location = New System.Drawing.Point(3, 44)
        Me.GunaSeparator1.Name = "GunaSeparator1"
        Me.GunaSeparator1.Size = New System.Drawing.Size(1200, 10)
        Me.GunaSeparator1.TabIndex = 14
        '
        'GunaLabel2
        '
        Me.GunaLabel2.AutoSize = True
        Me.GunaLabel2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaLabel2.ForeColor = System.Drawing.Color.DarkRed
        Me.GunaLabel2.Location = New System.Drawing.Point(898, 20)
        Me.GunaLabel2.Name = "GunaLabel2"
        Me.GunaLabel2.Size = New System.Drawing.Size(98, 15)
        Me.GunaLabel2.TabIndex = 13
        Me.GunaLabel2.Text = "File Size = 3.3 MB"
        '
        'GunaLabel1
        '
        Me.GunaLabel1.AutoSize = True
        Me.GunaLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaLabel1.ForeColor = System.Drawing.Color.DarkRed
        Me.GunaLabel1.Location = New System.Drawing.Point(105, 20)
        Me.GunaLabel1.Name = "GunaLabel1"
        Me.GunaLabel1.Size = New System.Drawing.Size(58, 15)
        Me.GunaLabel1.TabIndex = 8
        Me.GunaLabel1.Text = "dotte.xlsx"
        '
        'GunaCircleButton2
        '
        Me.GunaCircleButton2.AnimationHoverSpeed = 0.07!
        Me.GunaCircleButton2.AnimationSpeed = 0.03!
        Me.GunaCircleButton2.BaseColor = System.Drawing.Color.Transparent
        Me.GunaCircleButton2.BorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaCircleButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaCircleButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaCircleButton2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaCircleButton2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(45, Byte), Integer))
        Me.GunaCircleButton2.Image = CType(resources.GetObject("GunaCircleButton2.Image"), System.Drawing.Image)
        Me.GunaCircleButton2.ImageSize = New System.Drawing.Size(16, 16)
        Me.GunaCircleButton2.Location = New System.Drawing.Point(1153, 10)
        Me.GunaCircleButton2.Name = "GunaCircleButton2"
        Me.GunaCircleButton2.OnHoverBaseColor = System.Drawing.Color.Gainsboro
        Me.GunaCircleButton2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaCircleButton2.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaCircleButton2.OnHoverImage = CType(resources.GetObject("GunaCircleButton2.OnHoverImage"), System.Drawing.Image)
        Me.GunaCircleButton2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaCircleButton2.Size = New System.Drawing.Size(30, 30)
        Me.GunaCircleButton2.TabIndex = 6
        '
        'UserControl1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.GunaLinePanel1)
        Me.Name = "UserControl1"
        Me.Size = New System.Drawing.Size(1203, 51)
        Me.GunaLinePanel1.ResumeLayout(False)
        Me.GunaLinePanel1.PerformLayout()
        CType(Me.GunaPictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GunaPictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GunaPictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GunaPictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GunaPictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GunaPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GunaLinePanel1 As Guna.UI.WinForms.GunaLinePanel
    Friend WithEvents GunaPictureBox6 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents GunaLabel4 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents GunaLabel3 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents Label1 As Label
    Friend WithEvents GunaPictureBox5 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents GunaPictureBox4 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents GunaPictureBox3 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents GunaPictureBox2 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents GunaPictureBox1 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents GunaSeparator1 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents GunaLabel2 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents GunaLabel1 As Guna.UI.WinForms.GunaLabel
    Friend WithEvents GunaCircleButton2 As Guna.UI.WinForms.GunaCircleButton
    Friend WithEvents SfToolTip1 As Syncfusion.Windows.Forms.SfToolTip
End Class
