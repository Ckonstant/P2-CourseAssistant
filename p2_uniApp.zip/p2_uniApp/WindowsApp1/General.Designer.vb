﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class General
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(General))
        Me.GunaSeparator2 = New Guna.UI.WinForms.GunaSeparator()
        Me.GunaProgressBar1 = New Guna.UI.WinForms.GunaProgressBar()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GunaAdvenceTileButton10 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton9 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton8 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton7 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton6 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton5 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton4 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton3 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton2 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.SfComboBox1 = New Syncfusion.WinForms.ListView.SfComboBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SfComboBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GunaSeparator2
        '
        Me.GunaSeparator2.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaSeparator2.Location = New System.Drawing.Point(-10, 543)
        Me.GunaSeparator2.Name = "GunaSeparator2"
        Me.GunaSeparator2.Size = New System.Drawing.Size(1287, 10)
        Me.GunaSeparator2.TabIndex = 122
        '
        'GunaProgressBar1
        '
        Me.GunaProgressBar1.BorderColor = System.Drawing.Color.Black
        Me.GunaProgressBar1.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaProgressBar1.IdleColor = System.Drawing.Color.Gainsboro
        Me.GunaProgressBar1.Location = New System.Drawing.Point(86, 578)
        Me.GunaProgressBar1.Name = "GunaProgressBar1"
        Me.GunaProgressBar1.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(95, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.GunaProgressBar1.ProgressMinColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(95, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.GunaProgressBar1.Size = New System.Drawing.Size(468, 5)
        Me.GunaProgressBar1.TabIndex = 113
        Me.GunaProgressBar1.Visible = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label14.Location = New System.Drawing.Point(934, 578)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(160, 16)
        Me.Label14.TabIndex = 112
        Me.Label14.Text = "Έλεγχος για ενημερώσεις"
        Me.Label14.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(91, Byte), Integer), CType(CType(95, Byte), Integer), CType(CType(199, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(80, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(474, 33)
        Me.Label1.TabIndex = 111
        Me.Label1.Text = "Αρχές Γλωσσών Προγραμματισμού"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(914, 565)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 123
        Me.Label2.Text = "Label2"
        Me.Label2.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(993, 565)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 124
        Me.Label3.Text = "Label3"
        Me.Label3.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(1055, 565)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 125
        Me.Label4.Text = "Label4"
        Me.Label4.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox2.Location = New System.Drawing.Point(1087, 18)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(45, 45)
        Me.PictureBox2.TabIndex = 127
        Me.PictureBox2.TabStop = False
        Me.PictureBox2.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Location = New System.Drawing.Point(1087, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(45, 45)
        Me.PictureBox1.TabIndex = 126
        Me.PictureBox1.TabStop = False
        '
        'GunaAdvenceTileButton10
        '
        Me.GunaAdvenceTileButton10.AllowDrop = True
        Me.GunaAdvenceTileButton10.Animated = True
        Me.GunaAdvenceTileButton10.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton10.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton10.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton10.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceTileButton10.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton10.BorderSize = 1
        Me.GunaAdvenceTileButton10.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton10.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton10.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton10.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton10.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton10.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton10.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton10.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton10.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton10.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton10.Image = CType(resources.GetObject("GunaAdvenceTileButton10.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton10.ImageSize = New System.Drawing.Size(50, 50)
        Me.GunaAdvenceTileButton10.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton10.Location = New System.Drawing.Point(20, 559)
        Me.GunaAdvenceTileButton10.Name = "GunaAdvenceTileButton10"
        Me.GunaAdvenceTileButton10.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton10.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton10.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton10.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton10.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton10.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton10.Radius = 2
        Me.GunaAdvenceTileButton10.Size = New System.Drawing.Size(60, 56)
        Me.GunaAdvenceTileButton10.TabIndex = 121
        Me.GunaAdvenceTileButton10.TextImageOffsetY = 5
        '
        'GunaAdvenceTileButton9
        '
        Me.GunaAdvenceTileButton9.AllowDrop = True
        Me.GunaAdvenceTileButton9.Animated = True
        Me.GunaAdvenceTileButton9.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton9.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton9.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton9.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton9.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton9.BorderSize = 1
        Me.GunaAdvenceTileButton9.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton9.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton9.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton9.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton9.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton9.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton9.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton9.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton9.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton9.ForeColor = System.Drawing.Color.Coral
        Me.GunaAdvenceTileButton9.Image = CType(resources.GetObject("GunaAdvenceTileButton9.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton9.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton9.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton9.Location = New System.Drawing.Point(331, 98)
        Me.GunaAdvenceTileButton9.Name = "GunaAdvenceTileButton9"
        Me.GunaAdvenceTileButton9.OnHoverBaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton9.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton9.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton9.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton9.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton9.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton9.Radius = 2
        Me.GunaAdvenceTileButton9.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton9.TabIndex = 120
        Me.GunaAdvenceTileButton9.Text = "Ο Βαθμός μου                 5/10"
        Me.GunaAdvenceTileButton9.TextImageOffsetY = 5
        '
        'GunaAdvenceTileButton8
        '
        Me.GunaAdvenceTileButton8.AllowDrop = True
        Me.GunaAdvenceTileButton8.Animated = True
        Me.GunaAdvenceTileButton8.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton8.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton8.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton8.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton8.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton8.BorderSize = 1
        Me.GunaAdvenceTileButton8.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton8.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton8.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton8.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton8.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton8.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton8.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton8.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton8.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton8.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton8.Image = CType(resources.GetObject("GunaAdvenceTileButton8.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton8.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton8.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton8.Location = New System.Drawing.Point(636, 331)
        Me.GunaAdvenceTileButton8.Name = "GunaAdvenceTileButton8"
        Me.GunaAdvenceTileButton8.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton8.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton8.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton8.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton8.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton8.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton8.Radius = 2
        Me.GunaAdvenceTileButton8.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton8.TabIndex = 119
        Me.GunaAdvenceTileButton8.Text = "Ιστοσελίδα Μαθήματος"
        Me.GunaAdvenceTileButton8.TextImageOffsetY = 5
        '
        'GunaAdvenceTileButton7
        '
        Me.GunaAdvenceTileButton7.AllowDrop = True
        Me.GunaAdvenceTileButton7.Animated = True
        Me.GunaAdvenceTileButton7.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton7.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton7.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton7.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton7.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton7.BorderSize = 1
        Me.GunaAdvenceTileButton7.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton7.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton7.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton7.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton7.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton7.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton7.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton7.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton7.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton7.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton7.Image = CType(resources.GetObject("GunaAdvenceTileButton7.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton7.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton7.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton7.Location = New System.Drawing.Point(20, 331)
        Me.GunaAdvenceTileButton7.Name = "GunaAdvenceTileButton7"
        Me.GunaAdvenceTileButton7.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton7.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton7.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton7.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton7.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton7.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton7.Radius = 2
        Me.GunaAdvenceTileButton7.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton7.TabIndex = 118
        Me.GunaAdvenceTileButton7.Text = "Διδάσκων Καθηγητής Παληος Λεωνιδας"
        Me.GunaAdvenceTileButton7.TextImageOffsetY = 5
        '
        'GunaAdvenceTileButton6
        '
        Me.GunaAdvenceTileButton6.AllowDrop = True
        Me.GunaAdvenceTileButton6.Animated = True
        Me.GunaAdvenceTileButton6.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton6.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton6.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton6.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton6.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton6.BorderSize = 1
        Me.GunaAdvenceTileButton6.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton6.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton6.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton6.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton6.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton6.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton6.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton6.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton6.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton6.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton6.Image = CType(resources.GetObject("GunaAdvenceTileButton6.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton6.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton6.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton6.Location = New System.Drawing.Point(331, 331)
        Me.GunaAdvenceTileButton6.Name = "GunaAdvenceTileButton6"
        Me.GunaAdvenceTileButton6.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton6.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton6.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton6.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton6.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton6.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton6.Radius = 2
        Me.GunaAdvenceTileButton6.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton6.TabIndex = 117
        Me.GunaAdvenceTileButton6.Text = "Google Drive Μαθήματος"
        Me.GunaAdvenceTileButton6.TextImageOffsetY = 5
        '
        'GunaAdvenceTileButton5
        '
        Me.GunaAdvenceTileButton5.AllowDrop = True
        Me.GunaAdvenceTileButton5.Animated = True
        Me.GunaAdvenceTileButton5.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton5.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton5.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton5.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton5.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton5.BorderSize = 1
        Me.GunaAdvenceTileButton5.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton5.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton5.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton5.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton5.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton5.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton5.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton5.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton5.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton5.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton5.Image = CType(resources.GetObject("GunaAdvenceTileButton5.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton5.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton5.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton5.Location = New System.Drawing.Point(943, 331)
        Me.GunaAdvenceTileButton5.Name = "GunaAdvenceTileButton5"
        Me.GunaAdvenceTileButton5.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton5.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton5.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton5.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton5.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton5.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton5.Radius = 2
        Me.GunaAdvenceTileButton5.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton5.TabIndex = 116
        Me.GunaAdvenceTileButton5.Text = "Discord Μαθήματος"
        Me.GunaAdvenceTileButton5.TextImageOffsetY = 5
        '
        'GunaAdvenceTileButton4
        '
        Me.GunaAdvenceTileButton4.AllowDrop = True
        Me.GunaAdvenceTileButton4.Animated = True
        Me.GunaAdvenceTileButton4.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton4.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton4.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton4.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton4.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton4.BorderSize = 1
        Me.GunaAdvenceTileButton4.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton4.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton4.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton4.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton4.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton4.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton4.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton4.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton4.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton4.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton4.Image = CType(resources.GetObject("GunaAdvenceTileButton4.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton4.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton4.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton4.Location = New System.Drawing.Point(636, 98)
        Me.GunaAdvenceTileButton4.Name = "GunaAdvenceTileButton4"
        Me.GunaAdvenceTileButton4.OnHoverBaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton4.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton4.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton4.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton4.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton4.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton4.Radius = 2
        Me.GunaAdvenceTileButton4.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton4.TabIndex = 115
        Me.GunaAdvenceTileButton4.Text = "Εξάμηνο Σπουδών : 1o"
        Me.GunaAdvenceTileButton4.TextImageOffsetY = 5
        '
        'GunaAdvenceTileButton3
        '
        Me.GunaAdvenceTileButton3.AllowDrop = True
        Me.GunaAdvenceTileButton3.Animated = True
        Me.GunaAdvenceTileButton3.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton3.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton3.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton3.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton3.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton3.BorderSize = 1
        Me.GunaAdvenceTileButton3.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton3.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton3.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton3.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton3.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton3.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton3.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton3.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton3.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton3.Image = CType(resources.GetObject("GunaAdvenceTileButton3.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton3.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton3.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton3.Location = New System.Drawing.Point(943, 98)
        Me.GunaAdvenceTileButton3.Name = "GunaAdvenceTileButton3"
        Me.GunaAdvenceTileButton3.OnHoverBaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton3.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton3.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton3.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton3.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton3.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton3.Radius = 2
        Me.GunaAdvenceTileButton3.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton3.TabIndex = 114
        Me.GunaAdvenceTileButton3.Text = "Εργαστήριο Μαθήματος   (ΝΑΙ)"
        Me.GunaAdvenceTileButton3.TextImageOffsetY = 5
        '
        'GunaAdvenceTileButton2
        '
        Me.GunaAdvenceTileButton2.AllowDrop = True
        Me.GunaAdvenceTileButton2.Animated = True
        Me.GunaAdvenceTileButton2.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton2.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton2.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton2.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton2.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton2.BorderSize = 1
        Me.GunaAdvenceTileButton2.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton2.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton2.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton2.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton2.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton2.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton2.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton2.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton2.Image = CType(resources.GetObject("GunaAdvenceTileButton2.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton2.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton2.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton2.Location = New System.Drawing.Point(20, 98)
        Me.GunaAdvenceTileButton2.Name = "GunaAdvenceTileButton2"
        Me.GunaAdvenceTileButton2.OnHoverBaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton2.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton2.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton2.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton2.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton2.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton2.Radius = 2
        Me.GunaAdvenceTileButton2.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton2.TabIndex = 110
        Me.GunaAdvenceTileButton2.Text = "Κωδικός Μαθήματος:MYY106"
        Me.GunaAdvenceTileButton2.TextImageOffsetY = 5
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox3.Location = New System.Drawing.Point(39, 16)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(35, 35)
        Me.PictureBox3.TabIndex = 130
        Me.PictureBox3.TabStop = False
        Me.PictureBox3.Visible = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox4.Location = New System.Drawing.Point(705, 578)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(30, 30)
        Me.PictureBox4.TabIndex = 133
        Me.PictureBox4.TabStop = False
        Me.PictureBox4.Visible = False
        '
        'SfComboBox1
        '
        Me.SfComboBox1.DropDownPosition = Syncfusion.WinForms.Core.Enums.PopupRelativeAlignment.Center
        Me.SfComboBox1.Location = New System.Drawing.Point(410, 258)
        Me.SfComboBox1.MaxDropDownItems = 8
        Me.SfComboBox1.Name = "SfComboBox1"
        Me.SfComboBox1.Size = New System.Drawing.Size(96, 28)
        Me.SfComboBox1.Style.DropDownButtonStyle.HoverBackColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.SfComboBox1.Style.EditorStyle.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.SfComboBox1.Style.ReadOnlyEditorStyle.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.SfComboBox1.Style.TokenStyle.CloseButtonBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SfComboBox1.Style.TokenStyle.Font = Nothing
        Me.SfComboBox1.TabIndex = 132
        Me.SfComboBox1.Visible = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImage = CType(resources.GetObject("PictureBox5.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox5.Location = New System.Drawing.Point(1021, 18)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(45, 45)
        Me.PictureBox5.TabIndex = 134
        Me.PictureBox5.TabStop = False
        Me.PictureBox5.Visible = False
        '
        'General
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(1280, 658)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.SfComboBox1)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GunaSeparator2)
        Me.Controls.Add(Me.GunaAdvenceTileButton10)
        Me.Controls.Add(Me.GunaAdvenceTileButton9)
        Me.Controls.Add(Me.GunaAdvenceTileButton8)
        Me.Controls.Add(Me.GunaAdvenceTileButton7)
        Me.Controls.Add(Me.GunaAdvenceTileButton6)
        Me.Controls.Add(Me.GunaAdvenceTileButton5)
        Me.Controls.Add(Me.GunaAdvenceTileButton4)
        Me.Controls.Add(Me.GunaAdvenceTileButton3)
        Me.Controls.Add(Me.GunaProgressBar1)
        Me.Controls.Add(Me.GunaAdvenceTileButton2)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "General"
        Me.Text = "General"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SfComboBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GunaSeparator2 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents GunaAdvenceTileButton10 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton9 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton8 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton7 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton6 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton5 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton4 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton3 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaProgressBar1 As Guna.UI.WinForms.GunaProgressBar
    Friend WithEvents GunaAdvenceTileButton2 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents Label14 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents SfComboBox1 As Syncfusion.WinForms.ListView.SfComboBox
    Friend WithEvents PictureBox5 As PictureBox
End Class
