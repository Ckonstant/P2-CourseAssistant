﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Animation1 As Guna.UI.Animation.Animation = New Guna.UI.Animation.Animation()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Dim Range1 As Syncfusion.Windows.Forms.Gauge.Range = New Syncfusion.Windows.Forms.Gauge.Range()
        Dim Range2 As Syncfusion.Windows.Forms.Gauge.Range = New Syncfusion.Windows.Forms.Gauge.Range()
        Dim Range3 As Syncfusion.Windows.Forms.Gauge.Range = New Syncfusion.Windows.Forms.Gauge.Range()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GunaTransition1 = New Guna.UI.WinForms.GunaTransition(Me.components)
        Me.GunaAnimateWindow1 = New Guna.UI.WinForms.GunaAnimateWindow(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1 = New WindowsApp1.PanelEx()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.GunaAdvenceButton1 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.nav_settings = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaSeparator2 = New Guna.UI.WinForms.GunaSeparator()
        Me.GunaSeparator1 = New Guna.UI.WinForms.GunaSeparator()
        Me.GunaGradient2Panel1 = New Guna.UI.WinForms.GunaGradient2Panel()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.GunaElipsePanel2 = New Guna.UI.WinForms.GunaElipsePanel()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.GunaCircleProgressBar7 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GunaElipsePanel3 = New Guna.UI.WinForms.GunaElipsePanel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GunaElipsePanel1 = New Guna.UI.WinForms.GunaElipsePanel()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GunaCircleProgressBar6 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBar5 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBar3 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBar1 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaCircleProgressBar2 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaProgressBar4 = New Guna.UI.WinForms.GunaProgressBar()
        Me.GunaProgressBar3 = New Guna.UI.WinForms.GunaProgressBar()
        Me.GunaProgressBar2 = New Guna.UI.WinForms.GunaProgressBar()
        Me.GunaProgressBar1 = New Guna.UI.WinForms.GunaProgressBar()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.RadialGauge3 = New Syncfusion.Windows.Forms.Gauge.RadialGauge()
        Me.RadialGauge2 = New Syncfusion.Windows.Forms.Gauge.RadialGauge()
        Me.RadialGauge1 = New Syncfusion.Windows.Forms.Gauge.RadialGauge()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GunaShadowPanel4 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.GunaCircleProgressBar4 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.GunaShadowPanel3 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.CartesianChart1 = New LiveCharts.WinForms.CartesianChart()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.GunaGradient2Panel1.SuspendLayout()
        Me.GunaElipsePanel2.SuspendLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GunaElipsePanel3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GunaElipsePanel1.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GunaShadowPanel4.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GunaCircleProgressBar4.SuspendLayout()
        Me.GunaShadowPanel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'GunaTransition1
        '
        Me.GunaTransition1.AnimationType = Guna.UI.Animation.AnimationType.VertSlide
        Me.GunaTransition1.Cursor = Nothing
        Animation1.AnimateOnlyDifferences = True
        Animation1.BlindCoeff = CType(resources.GetObject("Animation1.BlindCoeff"), System.Drawing.PointF)
        Animation1.LeafCoeff = 0!
        Animation1.MaxTime = 1.0!
        Animation1.MinTime = 0!
        Animation1.MosaicCoeff = CType(resources.GetObject("Animation1.MosaicCoeff"), System.Drawing.PointF)
        Animation1.MosaicShift = CType(resources.GetObject("Animation1.MosaicShift"), System.Drawing.PointF)
        Animation1.MosaicSize = 0
        Animation1.Padding = New System.Windows.Forms.Padding(0)
        Animation1.RotateCoeff = 0!
        Animation1.RotateLimit = 0!
        Animation1.ScaleCoeff = CType(resources.GetObject("Animation1.ScaleCoeff"), System.Drawing.PointF)
        Animation1.SlideCoeff = CType(resources.GetObject("Animation1.SlideCoeff"), System.Drawing.PointF)
        Animation1.TimeCoeff = 0!
        Animation1.TransparencyCoeff = 0!
        Me.GunaTransition1.DefaultAnimation = Animation1
        '
        'GunaAnimateWindow1
        '
        Me.GunaAnimateWindow1.AnimationType = Guna.UI.WinForms.GunaAnimateWindow.AnimateWindowType.AW_HOR_POSITIVE
        Me.GunaAnimateWindow1.Interval = 100
        Me.GunaAnimateWindow1.TargetControl = Nothing
        '
        'Timer2
        '
        Me.Timer2.Interval = 10
        '
        'Timer3
        '
        Me.Timer3.Interval = 10
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.GunaAdvenceButton1)
        Me.Panel1.Controls.Add(Me.nav_settings)
        Me.Panel1.Controls.Add(Me.GunaSeparator2)
        Me.Panel1.Controls.Add(Me.GunaSeparator1)
        Me.Panel1.Controls.Add(Me.GunaGradient2Panel1)
        Me.Panel1.Controls.Add(Me.GunaElipsePanel3)
        Me.Panel1.Controls.Add(Me.GunaElipsePanel1)
        Me.Panel1.Controls.Add(Me.GunaShadowPanel4)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.GunaTransition1.SetDecoration(Me.Panel1, Guna.UI.Animation.DecorationType.None)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1320, 1100)
        Me.Panel1.TabIndex = 0
        '
        'Panel2
        '
        Me.GunaTransition1.SetDecoration(Me.Panel2, Guna.UI.Animation.DecorationType.None)
        Me.Panel2.Location = New System.Drawing.Point(539, 1054)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(212, 34)
        Me.Panel2.TabIndex = 145
        '
        'GunaAdvenceButton1
        '
        Me.GunaAdvenceButton1.Animated = True
        Me.GunaAdvenceButton1.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton1.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton1.BaseColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton1.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton1.CheckedImage = CType(resources.GetObject("GunaAdvenceButton1.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton1.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceButton1, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.GunaAdvenceButton1.ForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton1.Image = CType(resources.GetObject("GunaAdvenceButton1.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton1.ImageSize = New System.Drawing.Size(30, 30)
        Me.GunaAdvenceButton1.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton1.Location = New System.Drawing.Point(598, 642)
        Me.GunaAdvenceButton1.Name = "GunaAdvenceButton1"
        Me.GunaAdvenceButton1.OnHoverBaseColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.OnHoverForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton1.OnHoverImage = CType(resources.GetObject("GunaAdvenceButton1.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceButton1.OnHoverLineColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.OnPressedDepth = 0
        Me.GunaAdvenceButton1.Radius = 10
        Me.GunaAdvenceButton1.Size = New System.Drawing.Size(28, 25)
        Me.GunaAdvenceButton1.TabIndex = 143
        Me.GunaAdvenceButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'nav_settings
        '
        Me.nav_settings.Animated = True
        Me.nav_settings.AnimationHoverSpeed = 0.07!
        Me.nav_settings.AnimationSpeed = 0.03!
        Me.nav_settings.BackColor = System.Drawing.Color.Transparent
        Me.nav_settings.BaseColor = System.Drawing.Color.Transparent
        Me.nav_settings.BorderColor = System.Drawing.Color.Black
        Me.nav_settings.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.nav_settings.CheckedBorderColor = System.Drawing.Color.Black
        Me.nav_settings.CheckedForeColor = System.Drawing.Color.Gray
        Me.nav_settings.CheckedImage = CType(resources.GetObject("nav_settings.CheckedImage"), System.Drawing.Image)
        Me.nav_settings.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.nav_settings.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition1.SetDecoration(Me.nav_settings, Guna.UI.Animation.DecorationType.None)
        Me.nav_settings.DialogResult = System.Windows.Forms.DialogResult.None
        Me.nav_settings.FocusedColor = System.Drawing.Color.Empty
        Me.nav_settings.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.nav_settings.ForeColor = System.Drawing.Color.Gray
        Me.nav_settings.Image = CType(resources.GetObject("nav_settings.Image"), System.Drawing.Image)
        Me.nav_settings.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nav_settings.ImageSize = New System.Drawing.Size(30, 30)
        Me.nav_settings.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.nav_settings.Location = New System.Drawing.Point(598, 642)
        Me.nav_settings.Name = "nav_settings"
        Me.nav_settings.OnHoverBaseColor = System.Drawing.Color.Transparent
        Me.nav_settings.OnHoverBorderColor = System.Drawing.Color.Black
        Me.nav_settings.OnHoverForeColor = System.Drawing.Color.Gray
        Me.nav_settings.OnHoverImage = CType(resources.GetObject("nav_settings.OnHoverImage"), System.Drawing.Image)
        Me.nav_settings.OnHoverLineColor = System.Drawing.Color.WhiteSmoke
        Me.nav_settings.OnPressedColor = System.Drawing.Color.Black
        Me.nav_settings.OnPressedDepth = 0
        Me.nav_settings.Radius = 10
        Me.nav_settings.Size = New System.Drawing.Size(28, 25)
        Me.nav_settings.TabIndex = 142
        Me.nav_settings.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nav_settings.Visible = False
        '
        'GunaSeparator2
        '
        Me.GunaTransition1.SetDecoration(Me.GunaSeparator2, Guna.UI.Animation.DecorationType.None)
        Me.GunaSeparator2.LineColor = System.Drawing.Color.Silver
        Me.GunaSeparator2.Location = New System.Drawing.Point(636, 650)
        Me.GunaSeparator2.Name = "GunaSeparator2"
        Me.GunaSeparator2.Size = New System.Drawing.Size(521, 10)
        Me.GunaSeparator2.TabIndex = 81
        '
        'GunaSeparator1
        '
        Me.GunaTransition1.SetDecoration(Me.GunaSeparator1, Guna.UI.Animation.DecorationType.None)
        Me.GunaSeparator1.LineColor = System.Drawing.Color.Silver
        Me.GunaSeparator1.Location = New System.Drawing.Point(72, 650)
        Me.GunaSeparator1.Name = "GunaSeparator1"
        Me.GunaSeparator1.Size = New System.Drawing.Size(521, 10)
        Me.GunaSeparator1.TabIndex = 80
        '
        'GunaGradient2Panel1
        '
        Me.GunaGradient2Panel1.BackColor = System.Drawing.Color.Transparent
        Me.GunaGradient2Panel1.Controls.Add(Me.FlowLayoutPanel1)
        Me.GunaGradient2Panel1.Controls.Add(Me.GunaElipsePanel2)
        Me.GunaTransition1.SetDecoration(Me.GunaGradient2Panel1, Guna.UI.Animation.DecorationType.None)
        Me.GunaGradient2Panel1.GradientColor1 = System.Drawing.Color.White
        Me.GunaGradient2Panel1.GradientColor2 = System.Drawing.Color.White
        Me.GunaGradient2Panel1.Location = New System.Drawing.Point(18, 673)
        Me.GunaGradient2Panel1.Name = "GunaGradient2Panel1"
        Me.GunaGradient2Panel1.Radius = 10
        Me.GunaGradient2Panel1.Size = New System.Drawing.Size(1165, 375)
        Me.GunaGradient2Panel1.TabIndex = 72
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.BackColor = System.Drawing.Color.White
        Me.GunaTransition1.SetDecoration(Me.FlowLayoutPanel1, Guna.UI.Animation.DecorationType.None)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(3, 41)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(1346, 318)
        Me.FlowLayoutPanel1.TabIndex = 69
        '
        'GunaElipsePanel2
        '
        Me.GunaElipsePanel2.BackColor = System.Drawing.Color.Transparent
        Me.GunaElipsePanel2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaElipsePanel2.Controls.Add(Me.PictureBox7)
        Me.GunaElipsePanel2.Controls.Add(Me.GunaCircleProgressBar7)
        Me.GunaElipsePanel2.Controls.Add(Me.Label16)
        Me.GunaElipsePanel2.Controls.Add(Me.PictureBox5)
        Me.GunaElipsePanel2.Controls.Add(Me.PictureBox6)
        Me.GunaElipsePanel2.Controls.Add(Me.Label1)
        Me.GunaTransition1.SetDecoration(Me.GunaElipsePanel2, Guna.UI.Animation.DecorationType.None)
        Me.GunaElipsePanel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.GunaElipsePanel2.Location = New System.Drawing.Point(0, 0)
        Me.GunaElipsePanel2.Name = "GunaElipsePanel2"
        Me.GunaElipsePanel2.Size = New System.Drawing.Size(1165, 35)
        Me.GunaElipsePanel2.TabIndex = 73
        '
        'PictureBox7
        '
        Me.PictureBox7.BackgroundImage = CType(resources.GetObject("PictureBox7.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition1.SetDecoration(Me.PictureBox7, Guna.UI.Animation.DecorationType.None)
        Me.PictureBox7.Location = New System.Drawing.Point(98, 4)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(27, 26)
        Me.PictureBox7.TabIndex = 130
        Me.PictureBox7.TabStop = False
        '
        'GunaCircleProgressBar7
        '
        Me.GunaCircleProgressBar7.Animated = True
        Me.GunaCircleProgressBar7.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar7.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaTransition1.SetDecoration(Me.GunaCircleProgressBar7, Guna.UI.Animation.DecorationType.None)
        Me.GunaCircleProgressBar7.IdleColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaCircleProgressBar7.IdleOffset = 0
        Me.GunaCircleProgressBar7.IdleThickness = 3
        Me.GunaCircleProgressBar7.Image = Nothing
        Me.GunaCircleProgressBar7.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar7.Location = New System.Drawing.Point(195, 5)
        Me.GunaCircleProgressBar7.Name = "GunaCircleProgressBar7"
        Me.GunaCircleProgressBar7.ProgressMaxColor = System.Drawing.Color.White
        Me.GunaCircleProgressBar7.ProgressMinColor = System.Drawing.Color.GhostWhite
        Me.GunaCircleProgressBar7.ProgressOffset = 0
        Me.GunaCircleProgressBar7.ProgressThickness = 3
        Me.GunaCircleProgressBar7.Size = New System.Drawing.Size(25, 25)
        Me.GunaCircleProgressBar7.TabIndex = 129
        Me.GunaCircleProgressBar7.Value = 50
        Me.GunaCircleProgressBar7.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label16, Guna.UI.Animation.DecorationType.None)
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(129, 7)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(44, 20)
        Me.Label16.TabIndex = 79
        Me.Label16.Text = "1/56"
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImage = CType(resources.GetObject("PictureBox5.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition1.SetDecoration(Me.PictureBox5, Guna.UI.Animation.DecorationType.None)
        Me.PictureBox5.Location = New System.Drawing.Point(56, 4)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(27, 26)
        Me.PictureBox5.TabIndex = 78
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackgroundImage = CType(resources.GetObject("PictureBox6.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition1.SetDecoration(Me.PictureBox6, Guna.UI.Animation.DecorationType.None)
        Me.PictureBox6.Location = New System.Drawing.Point(23, 4)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(27, 26)
        Me.PictureBox6.TabIndex = 77
        Me.PictureBox6.TabStop = False
        Me.PictureBox6.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label1, Guna.UI.Animation.DecorationType.None)
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(295, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(605, 20)
        Me.Label1.TabIndex = 49
        Me.Label1.Text = "Γενικά νέα / ανακοινώσεις του Τμήματος Μηχανικών Η/Υ και Πληροφορικής"
        '
        'GunaElipsePanel3
        '
        Me.GunaElipsePanel3.BackColor = System.Drawing.Color.Transparent
        Me.GunaElipsePanel3.BaseColor = System.Drawing.Color.White
        Me.GunaElipsePanel3.Controls.Add(Me.Label14)
        Me.GunaElipsePanel3.Controls.Add(Me.PictureBox1)
        Me.GunaTransition1.SetDecoration(Me.GunaElipsePanel3, Guna.UI.Animation.DecorationType.None)
        Me.GunaElipsePanel3.Location = New System.Drawing.Point(15, 17)
        Me.GunaElipsePanel3.Name = "GunaElipsePanel3"
        Me.GunaElipsePanel3.Radius = 10
        Me.GunaElipsePanel3.Size = New System.Drawing.Size(816, 217)
        Me.GunaElipsePanel3.TabIndex = 71
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label14, Guna.UI.Animation.DecorationType.None)
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label14.Location = New System.Drawing.Point(132, 16)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(678, 180)
        Me.Label14.TabIndex = 117
        Me.Label14.Text = resources.GetString("Label14.Text")
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaTransition1.SetDecoration(Me.PictureBox1, Guna.UI.Animation.DecorationType.None)
        Me.PictureBox1.Location = New System.Drawing.Point(14, 16)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(91, 84)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'GunaElipsePanel1
        '
        Me.GunaElipsePanel1.BackColor = System.Drawing.Color.Transparent
        Me.GunaElipsePanel1.BaseColor = System.Drawing.Color.White
        Me.GunaElipsePanel1.Controls.Add(Me.ListBox3)
        Me.GunaElipsePanel1.Controls.Add(Me.ListBox2)
        Me.GunaElipsePanel1.Controls.Add(Me.WebBrowser1)
        Me.GunaElipsePanel1.Controls.Add(Me.Label12)
        Me.GunaElipsePanel1.Controls.Add(Me.Label11)
        Me.GunaElipsePanel1.Controls.Add(Me.Label10)
        Me.GunaElipsePanel1.Controls.Add(Me.Label9)
        Me.GunaElipsePanel1.Controls.Add(Me.Label15)
        Me.GunaElipsePanel1.Controls.Add(Me.Label8)
        Me.GunaElipsePanel1.Controls.Add(Me.Label7)
        Me.GunaElipsePanel1.Controls.Add(Me.Label6)
        Me.GunaElipsePanel1.Controls.Add(Me.Label5)
        Me.GunaElipsePanel1.Controls.Add(Me.Label4)
        Me.GunaElipsePanel1.Controls.Add(Me.GunaCircleProgressBar6)
        Me.GunaElipsePanel1.Controls.Add(Me.GunaCircleProgressBar5)
        Me.GunaElipsePanel1.Controls.Add(Me.GunaCircleProgressBar3)
        Me.GunaElipsePanel1.Controls.Add(Me.GunaCircleProgressBar1)
        Me.GunaElipsePanel1.Controls.Add(Me.GunaCircleProgressBar2)
        Me.GunaElipsePanel1.Controls.Add(Me.GunaProgressBar4)
        Me.GunaElipsePanel1.Controls.Add(Me.GunaProgressBar3)
        Me.GunaElipsePanel1.Controls.Add(Me.GunaProgressBar2)
        Me.GunaElipsePanel1.Controls.Add(Me.GunaProgressBar1)
        Me.GunaElipsePanel1.Controls.Add(Me.PictureBox4)
        Me.GunaElipsePanel1.Controls.Add(Me.PictureBox3)
        Me.GunaElipsePanel1.Controls.Add(Me.PictureBox2)
        Me.GunaElipsePanel1.Controls.Add(Me.RadialGauge3)
        Me.GunaElipsePanel1.Controls.Add(Me.RadialGauge2)
        Me.GunaElipsePanel1.Controls.Add(Me.RadialGauge1)
        Me.GunaElipsePanel1.Controls.Add(Me.Label2)
        Me.GunaTransition1.SetDecoration(Me.GunaElipsePanel1, Guna.UI.Animation.DecorationType.None)
        Me.GunaElipsePanel1.Location = New System.Drawing.Point(15, 249)
        Me.GunaElipsePanel1.Name = "GunaElipsePanel1"
        Me.GunaElipsePanel1.Radius = 10
        Me.GunaElipsePanel1.Size = New System.Drawing.Size(800, 390)
        Me.GunaElipsePanel1.TabIndex = 67
        '
        'ListBox3
        '
        Me.GunaTransition1.SetDecoration(Me.ListBox3, Guna.UI.Animation.DecorationType.None)
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.Location = New System.Drawing.Point(738, 286)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(52, 17)
        Me.ListBox3.TabIndex = 74
        Me.ListBox3.Visible = False
        '
        'ListBox2
        '
        Me.GunaTransition1.SetDecoration(Me.ListBox2, Guna.UI.Animation.DecorationType.None)
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(738, 195)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(59, 30)
        Me.ListBox2.TabIndex = 73
        Me.ListBox2.Visible = False
        '
        'WebBrowser1
        '
        Me.GunaTransition1.SetDecoration(Me.WebBrowser1, Guna.UI.Animation.DecorationType.None)
        Me.WebBrowser1.Location = New System.Drawing.Point(738, 231)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.ScriptErrorsSuppressed = True
        Me.WebBrowser1.Size = New System.Drawing.Size(49, 24)
        Me.WebBrowser1.TabIndex = 73
        Me.WebBrowser1.Visible = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.GunaTransition1.SetDecoration(Me.Label12, Guna.UI.Animation.DecorationType.None)
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Gray
        Me.Label12.Location = New System.Drawing.Point(668, 281)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(37, 21)
        Me.Label12.TabIndex = 141
        Me.Label12.Text = "0 %"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.GunaTransition1.SetDecoration(Me.Label11, Guna.UI.Animation.DecorationType.None)
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Gray
        Me.Label11.Location = New System.Drawing.Point(522, 281)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(37, 21)
        Me.Label11.TabIndex = 140
        Me.Label11.Text = "0 %"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.GunaTransition1.SetDecoration(Me.Label10, Guna.UI.Animation.DecorationType.None)
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Gray
        Me.Label10.Location = New System.Drawing.Point(366, 281)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(59, 21)
        Me.Label10.TabIndex = 139
        Me.Label10.Text = "55.7 %"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.GunaTransition1.SetDecoration(Me.Label9, Guna.UI.Animation.DecorationType.None)
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Gray
        Me.Label9.Location = New System.Drawing.Point(221, 281)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(59, 21)
        Me.Label9.TabIndex = 138
        Me.Label9.Text = "21.2 %"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.GunaTransition1.SetDecoration(Me.Label15, Guna.UI.Animation.DecorationType.None)
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Gray
        Me.Label15.Location = New System.Drawing.Point(72, 281)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(55, 21)
        Me.Label15.TabIndex = 137
        Me.Label15.Text = "100 %"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label8, Guna.UI.Animation.DecorationType.None)
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(648, 350)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 20)
        Me.Label8.TabIndex = 136
        Me.Label8.Text = "5ο Έτος"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label7, Guna.UI.Animation.DecorationType.None)
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(506, 350)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 20)
        Me.Label7.TabIndex = 135
        Me.Label7.Text = "4ο Έτος"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label6, Guna.UI.Animation.DecorationType.None)
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(352, 350)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 20)
        Me.Label6.TabIndex = 134
        Me.Label6.Text = "3ο Έτος"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label5, Guna.UI.Animation.DecorationType.None)
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(205, 350)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 20)
        Me.Label5.TabIndex = 133
        Me.Label5.Text = "2ο Έτος"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label4, Guna.UI.Animation.DecorationType.None)
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(61, 350)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 20)
        Me.Label4.TabIndex = 132
        Me.Label4.Text = "1ο Έτος"
        '
        'GunaCircleProgressBar6
        '
        Me.GunaCircleProgressBar6.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar6.BaseColor = System.Drawing.Color.White
        Me.GunaTransition1.SetDecoration(Me.GunaCircleProgressBar6, Guna.UI.Animation.DecorationType.None)
        Me.GunaCircleProgressBar6.IdleColor = System.Drawing.Color.Gainsboro
        Me.GunaCircleProgressBar6.IdleOffset = 0
        Me.GunaCircleProgressBar6.IdleThickness = 5
        Me.GunaCircleProgressBar6.Image = Nothing
        Me.GunaCircleProgressBar6.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar6.Location = New System.Drawing.Point(81, 307)
        Me.GunaCircleProgressBar6.Name = "GunaCircleProgressBar6"
        Me.GunaCircleProgressBar6.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar6.ProgressMinColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar6.ProgressOffset = 0
        Me.GunaCircleProgressBar6.ProgressThickness = 5
        Me.GunaCircleProgressBar6.Size = New System.Drawing.Size(31, 31)
        Me.GunaCircleProgressBar6.TabIndex = 131
        Me.GunaCircleProgressBar6.Value = 100
        '
        'GunaCircleProgressBar5
        '
        Me.GunaCircleProgressBar5.Animated = True
        Me.GunaCircleProgressBar5.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar5.BaseColor = System.Drawing.Color.White
        Me.GunaTransition1.SetDecoration(Me.GunaCircleProgressBar5, Guna.UI.Animation.DecorationType.None)
        Me.GunaCircleProgressBar5.IdleColor = System.Drawing.Color.Gainsboro
        Me.GunaCircleProgressBar5.IdleOffset = 0
        Me.GunaCircleProgressBar5.IdleThickness = 5
        Me.GunaCircleProgressBar5.Image = Nothing
        Me.GunaCircleProgressBar5.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar5.Location = New System.Drawing.Point(674, 307)
        Me.GunaCircleProgressBar5.Name = "GunaCircleProgressBar5"
        Me.GunaCircleProgressBar5.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(127, Byte), Integer))
        Me.GunaCircleProgressBar5.ProgressMinColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(127, Byte), Integer))
        Me.GunaCircleProgressBar5.ProgressOffset = 0
        Me.GunaCircleProgressBar5.ProgressThickness = 5
        Me.GunaCircleProgressBar5.Size = New System.Drawing.Size(31, 31)
        Me.GunaCircleProgressBar5.TabIndex = 130
        '
        'GunaCircleProgressBar3
        '
        Me.GunaCircleProgressBar3.Animated = True
        Me.GunaCircleProgressBar3.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar3.BaseColor = System.Drawing.Color.White
        Me.GunaTransition1.SetDecoration(Me.GunaCircleProgressBar3, Guna.UI.Animation.DecorationType.None)
        Me.GunaCircleProgressBar3.IdleColor = System.Drawing.Color.Gainsboro
        Me.GunaCircleProgressBar3.IdleOffset = 0
        Me.GunaCircleProgressBar3.IdleThickness = 5
        Me.GunaCircleProgressBar3.Image = Nothing
        Me.GunaCircleProgressBar3.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar3.Location = New System.Drawing.Point(528, 307)
        Me.GunaCircleProgressBar3.Name = "GunaCircleProgressBar3"
        Me.GunaCircleProgressBar3.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(127, Byte), Integer))
        Me.GunaCircleProgressBar3.ProgressMinColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(127, Byte), Integer))
        Me.GunaCircleProgressBar3.ProgressOffset = 0
        Me.GunaCircleProgressBar3.ProgressThickness = 5
        Me.GunaCircleProgressBar3.Size = New System.Drawing.Size(31, 31)
        Me.GunaCircleProgressBar3.TabIndex = 129
        '
        'GunaCircleProgressBar1
        '
        Me.GunaCircleProgressBar1.Animated = True
        Me.GunaCircleProgressBar1.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar1.BaseColor = System.Drawing.Color.White
        Me.GunaTransition1.SetDecoration(Me.GunaCircleProgressBar1, Guna.UI.Animation.DecorationType.None)
        Me.GunaCircleProgressBar1.IdleColor = System.Drawing.Color.Gainsboro
        Me.GunaCircleProgressBar1.IdleOffset = 0
        Me.GunaCircleProgressBar1.IdleThickness = 5
        Me.GunaCircleProgressBar1.Image = Nothing
        Me.GunaCircleProgressBar1.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar1.Location = New System.Drawing.Point(378, 307)
        Me.GunaCircleProgressBar1.Name = "GunaCircleProgressBar1"
        Me.GunaCircleProgressBar1.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(127, Byte), Integer))
        Me.GunaCircleProgressBar1.ProgressMinColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(84, Byte), Integer), CType(CType(127, Byte), Integer))
        Me.GunaCircleProgressBar1.ProgressOffset = 0
        Me.GunaCircleProgressBar1.ProgressThickness = 5
        Me.GunaCircleProgressBar1.Size = New System.Drawing.Size(31, 31)
        Me.GunaCircleProgressBar1.TabIndex = 128
        Me.GunaCircleProgressBar1.Value = 50
        '
        'GunaCircleProgressBar2
        '
        Me.GunaCircleProgressBar2.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar2.BaseColor = System.Drawing.Color.White
        Me.GunaTransition1.SetDecoration(Me.GunaCircleProgressBar2, Guna.UI.Animation.DecorationType.None)
        Me.GunaCircleProgressBar2.IdleColor = System.Drawing.Color.Gainsboro
        Me.GunaCircleProgressBar2.IdleOffset = 0
        Me.GunaCircleProgressBar2.IdleThickness = 5
        Me.GunaCircleProgressBar2.Image = Nothing
        Me.GunaCircleProgressBar2.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar2.Location = New System.Drawing.Point(231, 307)
        Me.GunaCircleProgressBar2.Name = "GunaCircleProgressBar2"
        Me.GunaCircleProgressBar2.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar2.ProgressMinColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaCircleProgressBar2.ProgressOffset = 0
        Me.GunaCircleProgressBar2.ProgressThickness = 5
        Me.GunaCircleProgressBar2.Size = New System.Drawing.Size(31, 31)
        Me.GunaCircleProgressBar2.TabIndex = 127
        Me.GunaCircleProgressBar2.Value = 100
        '
        'GunaProgressBar4
        '
        Me.GunaProgressBar4.BorderColor = System.Drawing.Color.Black
        Me.GunaProgressBar4.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaTransition1.SetDecoration(Me.GunaProgressBar4, Guna.UI.Animation.DecorationType.None)
        Me.GunaProgressBar4.IdleColor = System.Drawing.Color.Gainsboro
        Me.GunaProgressBar4.Location = New System.Drawing.Point(551, 319)
        Me.GunaProgressBar4.Name = "GunaProgressBar4"
        Me.GunaProgressBar4.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaProgressBar4.ProgressMinColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaProgressBar4.Size = New System.Drawing.Size(122, 7)
        Me.GunaProgressBar4.TabIndex = 126
        '
        'GunaProgressBar3
        '
        Me.GunaProgressBar3.BorderColor = System.Drawing.Color.Black
        Me.GunaProgressBar3.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaTransition1.SetDecoration(Me.GunaProgressBar3, Guna.UI.Animation.DecorationType.None)
        Me.GunaProgressBar3.IdleColor = System.Drawing.Color.Gainsboro
        Me.GunaProgressBar3.Location = New System.Drawing.Point(405, 319)
        Me.GunaProgressBar3.Name = "GunaProgressBar3"
        Me.GunaProgressBar3.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaProgressBar3.ProgressMinColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaProgressBar3.Size = New System.Drawing.Size(122, 7)
        Me.GunaProgressBar3.TabIndex = 125
        '
        'GunaProgressBar2
        '
        Me.GunaProgressBar2.BorderColor = System.Drawing.Color.Black
        Me.GunaProgressBar2.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaTransition1.SetDecoration(Me.GunaProgressBar2, Guna.UI.Animation.DecorationType.None)
        Me.GunaProgressBar2.IdleColor = System.Drawing.Color.Gainsboro
        Me.GunaProgressBar2.Location = New System.Drawing.Point(254, 319)
        Me.GunaProgressBar2.Name = "GunaProgressBar2"
        Me.GunaProgressBar2.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaProgressBar2.ProgressMinColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaProgressBar2.Size = New System.Drawing.Size(122, 7)
        Me.GunaProgressBar2.TabIndex = 124
        Me.GunaProgressBar2.Value = 100
        '
        'GunaProgressBar1
        '
        Me.GunaProgressBar1.BorderColor = System.Drawing.Color.Black
        Me.GunaProgressBar1.ColorStyle = Guna.UI.WinForms.ColorStyle.[Default]
        Me.GunaTransition1.SetDecoration(Me.GunaProgressBar1, Guna.UI.Animation.DecorationType.None)
        Me.GunaProgressBar1.IdleColor = System.Drawing.Color.Gainsboro
        Me.GunaProgressBar1.Location = New System.Drawing.Point(113, 319)
        Me.GunaProgressBar1.Name = "GunaProgressBar1"
        Me.GunaProgressBar1.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(116, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaProgressBar1.ProgressMinColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaProgressBar1.Size = New System.Drawing.Size(115, 7)
        Me.GunaProgressBar1.TabIndex = 123
        Me.GunaProgressBar1.Value = 100
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaTransition1.SetDecoration(Me.PictureBox4, Guna.UI.Animation.DecorationType.None)
        Me.PictureBox4.Location = New System.Drawing.Point(602, 117)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(41, 40)
        Me.PictureBox4.TabIndex = 122
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaTransition1.SetDecoration(Me.PictureBox3, Guna.UI.Animation.DecorationType.None)
        Me.PictureBox3.Location = New System.Drawing.Point(353, 117)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(41, 40)
        Me.PictureBox3.TabIndex = 121
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.GunaTransition1.SetDecoration(Me.PictureBox2, Guna.UI.Animation.DecorationType.None)
        Me.PictureBox2.Location = New System.Drawing.Point(111, 117)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(41, 40)
        Me.PictureBox2.TabIndex = 120
        Me.PictureBox2.TabStop = False
        '
        'RadialGauge3
        '
        Me.RadialGauge3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RadialGauge3.ArcThickness = 2.0!
        Me.RadialGauge3.BackgroundGradientEndColor = System.Drawing.Color.Transparent
        Me.RadialGauge3.BackgroundGradientStartColor = System.Drawing.Color.Transparent
        Me.GunaTransition1.SetDecoration(Me.RadialGauge3, Guna.UI.Animation.DecorationType.None)
        Me.RadialGauge3.EnableCustomNeedles = False
        Me.RadialGauge3.FillColor = System.Drawing.Color.DarkGray
        Me.RadialGauge3.FrameThickness = 12
        Me.RadialGauge3.GaugeLabel = "Συνολικό Μέγεθος (MB)"
        Me.RadialGauge3.GaugeLableColor = System.Drawing.Color.FromArgb(CType(CType(172, Byte), Integer), CType(CType(124, Byte), Integer), CType(CType(113, Byte), Integer))
        Me.RadialGauge3.GaugeLableFont = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadialGauge3.GaugeValueColor = System.Drawing.Color.FromArgb(CType(CType(172, Byte), Integer), CType(CType(124, Byte), Integer), CType(CType(113, Byte), Integer))
        Me.RadialGauge3.GaugeValueFont = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.RadialGauge3.InnerFrameGradientEndColor = System.Drawing.Color.Transparent
        Me.RadialGauge3.InnerFrameGradientStartColor = System.Drawing.Color.Transparent
        Me.RadialGauge3.Location = New System.Drawing.Point(524, 56)
        Me.RadialGauge3.MajorDifference = 1.0!
        Me.RadialGauge3.MajorTickMarkHeight = 0
        Me.RadialGauge3.Margin = New System.Windows.Forms.Padding(4)
        Me.RadialGauge3.MaximumValue = 7000.0!
        Me.RadialGauge3.MinimumSize = New System.Drawing.Size(125, 125)
        Me.RadialGauge3.MinorInnerLinesHeight = 0
        Me.RadialGauge3.MinorTickMarkHeight = 0
        Me.RadialGauge3.Name = "RadialGauge3"
        Me.RadialGauge3.OuterFrameGradientEndColor = System.Drawing.Color.Transparent
        Me.RadialGauge3.OuterFrameGradientStartColor = System.Drawing.Color.Transparent
        Range1.Color = System.Drawing.Color.FromArgb(CType(CType(172, Byte), Integer), CType(CType(124, Byte), Integer), CType(CType(113, Byte), Integer))
        Range1.EndValue = 1000.0!
        Range1.Height = 5
        Range1.InRange = True
        Range1.Name = "GaugeRange1"
        Range1.RangePlacement = Syncfusion.Windows.Forms.Gauge.TickPlacement.OutSide
        Range1.StartValue = 0!
        Me.RadialGauge3.Ranges.Add(Range1)
        Me.RadialGauge3.ShowBackgroundFrame = False
        Me.RadialGauge3.ShowGaugeValue = True
        Me.RadialGauge3.ShowNeedle = False
        Me.RadialGauge3.ShowScaleLabel = False
        Me.RadialGauge3.ShowTicks = True
        Me.RadialGauge3.Size = New System.Drawing.Size(194, 194)
        Me.RadialGauge3.TabIndex = 119
        Me.RadialGauge3.Value = 4.0!
        '
        'RadialGauge2
        '
        Me.RadialGauge2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RadialGauge2.ArcThickness = 2.0!
        Me.RadialGauge2.BackgroundGradientEndColor = System.Drawing.Color.Transparent
        Me.RadialGauge2.BackgroundGradientStartColor = System.Drawing.Color.Transparent
        Me.GunaTransition1.SetDecoration(Me.RadialGauge2, Guna.UI.Animation.DecorationType.None)
        Me.RadialGauge2.EnableCustomNeedles = False
        Me.RadialGauge2.FillColor = System.Drawing.Color.DarkGray
        Me.RadialGauge2.FrameThickness = 12
        Me.RadialGauge2.GaugeLabel = "Αγαπημένα"
        Me.RadialGauge2.GaugeLableColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.RadialGauge2.GaugeLableFont = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadialGauge2.GaugeValueColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.RadialGauge2.GaugeValueFont = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.RadialGauge2.InnerFrameGradientEndColor = System.Drawing.Color.Transparent
        Me.RadialGauge2.InnerFrameGradientStartColor = System.Drawing.Color.Transparent
        Me.RadialGauge2.Location = New System.Drawing.Point(272, 56)
        Me.RadialGauge2.MajorDifference = 1.0!
        Me.RadialGauge2.MajorTickMarkHeight = 0
        Me.RadialGauge2.Margin = New System.Windows.Forms.Padding(4)
        Me.RadialGauge2.MaximumValue = 47.0!
        Me.RadialGauge2.MinimumSize = New System.Drawing.Size(125, 125)
        Me.RadialGauge2.MinorInnerLinesHeight = 0
        Me.RadialGauge2.MinorTickMarkHeight = 0
        Me.RadialGauge2.Name = "RadialGauge2"
        Me.RadialGauge2.OuterFrameGradientEndColor = System.Drawing.Color.Transparent
        Me.RadialGauge2.OuterFrameGradientStartColor = System.Drawing.Color.Transparent
        Range2.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Range2.EndValue = 5.0!
        Range2.Height = 5
        Range2.InRange = False
        Range2.Name = "GaugeRange1"
        Range2.RangePlacement = Syncfusion.Windows.Forms.Gauge.TickPlacement.OutSide
        Range2.StartValue = 0!
        Me.RadialGauge2.Ranges.Add(Range2)
        Me.RadialGauge2.ShowBackgroundFrame = False
        Me.RadialGauge2.ShowGaugeValue = True
        Me.RadialGauge2.ShowNeedle = False
        Me.RadialGauge2.ShowScaleLabel = False
        Me.RadialGauge2.ShowTicks = True
        Me.RadialGauge2.Size = New System.Drawing.Size(194, 194)
        Me.RadialGauge2.TabIndex = 118
        Me.RadialGauge2.Value = 25.0!
        '
        'RadialGauge1
        '
        Me.RadialGauge1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RadialGauge1.ArcThickness = 2.0!
        Me.RadialGauge1.BackgroundGradientEndColor = System.Drawing.Color.Transparent
        Me.RadialGauge1.BackgroundGradientStartColor = System.Drawing.Color.Transparent
        Me.GunaTransition1.SetDecoration(Me.RadialGauge1, Guna.UI.Animation.DecorationType.None)
        Me.RadialGauge1.EnableCustomNeedles = False
        Me.RadialGauge1.FillColor = System.Drawing.Color.DarkGray
        Me.RadialGauge1.FrameThickness = 12
        Me.RadialGauge1.GaugeLabel = "Κατεβασμένα"
        Me.RadialGauge1.GaugeLableColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.RadialGauge1.GaugeLableFont = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadialGauge1.GaugeValueColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.RadialGauge1.GaugeValueFont = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.RadialGauge1.InnerFrameGradientEndColor = System.Drawing.Color.Transparent
        Me.RadialGauge1.InnerFrameGradientStartColor = System.Drawing.Color.Transparent
        Me.RadialGauge1.Location = New System.Drawing.Point(33, 56)
        Me.RadialGauge1.MajorDifference = 1.0!
        Me.RadialGauge1.MajorTickMarkHeight = 0
        Me.RadialGauge1.Margin = New System.Windows.Forms.Padding(4)
        Me.RadialGauge1.MaximumValue = 47.0!
        Me.RadialGauge1.MinimumSize = New System.Drawing.Size(125, 125)
        Me.RadialGauge1.MinorInnerLinesHeight = 0
        Me.RadialGauge1.MinorTickMarkHeight = 0
        Me.RadialGauge1.Name = "RadialGauge1"
        Me.RadialGauge1.OuterFrameGradientEndColor = System.Drawing.Color.Transparent
        Me.RadialGauge1.OuterFrameGradientStartColor = System.Drawing.Color.Transparent
        Range3.Color = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Range3.EndValue = 30.0!
        Range3.Height = 5
        Range3.InRange = True
        Range3.Name = "GaugeRange1"
        Range3.RangePlacement = Syncfusion.Windows.Forms.Gauge.TickPlacement.OutSide
        Range3.StartValue = 0!
        Me.RadialGauge1.Ranges.Add(Range3)
        Me.RadialGauge1.ShowBackgroundFrame = False
        Me.RadialGauge1.ShowGaugeValue = True
        Me.RadialGauge1.ShowNeedle = False
        Me.RadialGauge1.ShowScaleLabel = False
        Me.RadialGauge1.ShowTicks = True
        Me.RadialGauge1.Size = New System.Drawing.Size(194, 194)
        Me.RadialGauge1.TabIndex = 117
        Me.RadialGauge1.Value = 25.0!
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label2, Guna.UI.Animation.DecorationType.None)
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(298, 18)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(313, 24)
        Me.Label2.TabIndex = 116
        Me.Label2.Text = "ΕΙΔΙΚΑ ΣΤΑΤΙΣΤΙΚΑ ΜΑΘΗΜΑΤΩΝ"
        '
        'GunaShadowPanel4
        '
        Me.GunaShadowPanel4.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel4.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel4.Controls.Add(Me.PictureBox10)
        Me.GunaShadowPanel4.Controls.Add(Me.PictureBox9)
        Me.GunaShadowPanel4.Controls.Add(Me.PictureBox8)
        Me.GunaShadowPanel4.Controls.Add(Me.Label34)
        Me.GunaShadowPanel4.Controls.Add(Me.Label35)
        Me.GunaShadowPanel4.Controls.Add(Me.Label36)
        Me.GunaShadowPanel4.Controls.Add(Me.Label37)
        Me.GunaShadowPanel4.Controls.Add(Me.Label38)
        Me.GunaShadowPanel4.Controls.Add(Me.Label39)
        Me.GunaShadowPanel4.Controls.Add(Me.Label40)
        Me.GunaShadowPanel4.Controls.Add(Me.Label41)
        Me.GunaShadowPanel4.Controls.Add(Me.Label42)
        Me.GunaShadowPanel4.Controls.Add(Me.Label43)
        Me.GunaShadowPanel4.Controls.Add(Me.GunaCircleProgressBar4)
        Me.GunaTransition1.SetDecoration(Me.GunaShadowPanel4, Guna.UI.Animation.DecorationType.None)
        Me.GunaShadowPanel4.Location = New System.Drawing.Point(837, 18)
        Me.GunaShadowPanel4.Name = "GunaShadowPanel4"
        Me.GunaShadowPanel4.Radius = 5
        Me.GunaShadowPanel4.ShadowColor = System.Drawing.Color.DimGray
        Me.GunaShadowPanel4.ShadowShift = 4
        Me.GunaShadowPanel4.Size = New System.Drawing.Size(327, 626)
        Me.GunaShadowPanel4.TabIndex = 65
        '
        'PictureBox10
        '
        Me.PictureBox10.BackgroundImage = CType(resources.GetObject("PictureBox10.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaTransition1.SetDecoration(Me.PictureBox10, Guna.UI.Animation.DecorationType.None)
        Me.PictureBox10.Location = New System.Drawing.Point(236, 517)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(36, 36)
        Me.PictureBox10.TabIndex = 62
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.BackgroundImage = CType(resources.GetObject("PictureBox9.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaTransition1.SetDecoration(Me.PictureBox9, Guna.UI.Animation.DecorationType.None)
        Me.PictureBox9.Location = New System.Drawing.Point(236, 453)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(36, 36)
        Me.PictureBox9.TabIndex = 61
        Me.PictureBox9.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackgroundImage = CType(resources.GetObject("PictureBox8.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaTransition1.SetDecoration(Me.PictureBox8, Guna.UI.Animation.DecorationType.None)
        Me.PictureBox8.Location = New System.Drawing.Point(236, 390)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(36, 36)
        Me.PictureBox8.TabIndex = 60
        Me.PictureBox8.TabStop = False
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label34, Guna.UI.Animation.DecorationType.None)
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label34.Location = New System.Drawing.Point(52, 36)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(249, 48)
        Me.Label34.TabIndex = 59
        Me.Label34.Text = "ΣΤΑΤΙΣΤΙΚΑ ΜΑΘΗΜΑΤΩΝ" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "             ΣΥΝΟΛΙΚΑ"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label35, Guna.UI.Animation.DecorationType.None)
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label35.Location = New System.Drawing.Point(232, 525)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(39, 20)
        Me.Label35.TabIndex = 58
        Me.Label35.Text = "110"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label36, Guna.UI.Animation.DecorationType.None)
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label36.Location = New System.Drawing.Point(232, 461)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(29, 20)
        Me.Label36.TabIndex = 57
        Me.Label36.Text = "37"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label37, Guna.UI.Animation.DecorationType.None)
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label37.Location = New System.Drawing.Point(232, 395)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(29, 20)
        Me.Label37.TabIndex = 56
        Me.Label37.Text = "47"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label38, Guna.UI.Animation.DecorationType.None)
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label38.Location = New System.Drawing.Point(16, 565)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(136, 16)
        Me.Label38.TabIndex = 55
        Me.Label38.Text = "Γενικός Μέσος Όρος"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label39, Guna.UI.Animation.DecorationType.None)
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label39.Location = New System.Drawing.Point(16, 491)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(205, 16)
        Me.Label39.TabIndex = 54
        Me.Label39.Text = "Πλήθος Περασμένων Μαθημάτων"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label40, Guna.UI.Animation.DecorationType.None)
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label40.Location = New System.Drawing.Point(16, 427)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(207, 16)
        Me.Label40.TabIndex = 53
        Me.Label40.Text = "Πλήθος Μαθημάτων Προπτυχιακά"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label41, Guna.UI.Animation.DecorationType.None)
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label41.Location = New System.Drawing.Point(15, 525)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(155, 20)
        Me.Label41.TabIndex = 52
        Me.Label41.Text = "Μ.Ο(Μέσος Όρος)"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label42, Guna.UI.Animation.DecorationType.None)
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label42.Location = New System.Drawing.Point(15, 461)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(98, 20)
        Me.Label42.TabIndex = 51
        Me.Label42.Text = "Περασμένα"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label43, Guna.UI.Animation.DecorationType.None)
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label43.Location = New System.Drawing.Point(15, 395)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(74, 20)
        Me.Label43.TabIndex = 50
        Me.Label43.Text = "Σύνολο "
        '
        'GunaCircleProgressBar4
        '
        Me.GunaCircleProgressBar4.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar4.BaseColor = System.Drawing.Color.White
        Me.GunaCircleProgressBar4.Controls.Add(Me.GunaShadowPanel3)
        Me.GunaCircleProgressBar4.Controls.Add(Me.Label44)
        Me.GunaTransition1.SetDecoration(Me.GunaCircleProgressBar4, Guna.UI.Animation.DecorationType.None)
        Me.GunaCircleProgressBar4.IdleColor = System.Drawing.Color.Gainsboro
        Me.GunaCircleProgressBar4.IdleOffset = 20
        Me.GunaCircleProgressBar4.IdleThickness = 11
        Me.GunaCircleProgressBar4.Image = Nothing
        Me.GunaCircleProgressBar4.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar4.LineEndCap = System.Drawing.Drawing2D.LineCap.Round
        Me.GunaCircleProgressBar4.LineStartCap = System.Drawing.Drawing2D.LineCap.Round
        Me.GunaCircleProgressBar4.Location = New System.Drawing.Point(41, 115)
        Me.GunaCircleProgressBar4.Maximum = 47
        Me.GunaCircleProgressBar4.Name = "GunaCircleProgressBar4"
        Me.GunaCircleProgressBar4.ProgressMaxColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaCircleProgressBar4.ProgressMinColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaCircleProgressBar4.ProgressOffset = 20
        Me.GunaCircleProgressBar4.ProgressThickness = 11
        Me.GunaCircleProgressBar4.Size = New System.Drawing.Size(232, 228)
        Me.GunaCircleProgressBar4.TabIndex = 0
        Me.GunaCircleProgressBar4.Value = 37
        '
        'GunaShadowPanel3
        '
        Me.GunaShadowPanel3.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel3.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel3.Controls.Add(Me.Label3)
        Me.GunaShadowPanel3.Controls.Add(Me.ListBox1)
        Me.GunaShadowPanel3.Controls.Add(Me.CartesianChart1)
        Me.GunaTransition1.SetDecoration(Me.GunaShadowPanel3, Guna.UI.Animation.DecorationType.None)
        Me.GunaShadowPanel3.Location = New System.Drawing.Point(123, 228)
        Me.GunaShadowPanel3.Name = "GunaShadowPanel3"
        Me.GunaShadowPanel3.Radius = 5
        Me.GunaShadowPanel3.ShadowColor = System.Drawing.Color.DimGray
        Me.GunaShadowPanel3.ShadowShift = 4
        Me.GunaShadowPanel3.Size = New System.Drawing.Size(34, 27)
        Me.GunaShadowPanel3.TabIndex = 68
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label3, Guna.UI.Animation.DecorationType.None)
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(189, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(476, 24)
        Me.Label3.TabIndex = 59
        Me.Label3.Text = "ΑΝΑΛΥΤΙΚΑ ΣΤΑΤΙΣΤΙΚΑ ΣΥΝΟΛΙΚΩΝ ΜΑΘΗΜΑΤΩΝ"
        '
        'ListBox1
        '
        Me.GunaTransition1.SetDecoration(Me.ListBox1, Guna.UI.Animation.DecorationType.None)
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(558, 170)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(200, 199)
        Me.ListBox1.TabIndex = 63
        '
        'CartesianChart1
        '
        Me.GunaTransition1.SetDecoration(Me.CartesianChart1, Guna.UI.Animation.DecorationType.None)
        Me.CartesianChart1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.CartesianChart1.Location = New System.Drawing.Point(0, 0)
        Me.CartesianChart1.Name = "CartesianChart1"
        Me.CartesianChart1.Size = New System.Drawing.Size(34, 27)
        Me.CartesianChart1.TabIndex = 62
        Me.CartesianChart1.Text = "CartesianChart1"
        Me.CartesianChart1.Visible = False
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label44, Guna.UI.Animation.DecorationType.None)
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label44.Location = New System.Drawing.Point(57, 95)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(129, 50)
        Me.Label44.TabIndex = 49
        Me.Label44.Text = "   37/47" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Περασμένα"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label13, Guna.UI.Animation.DecorationType.None)
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label13.Location = New System.Drawing.Point(518, 676)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(173, 24)
        Me.Label13.TabIndex = 144
        Me.Label13.Text = "Νεα/Ανακοινώσεις"
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(1320, 1100)
        Me.Controls.Add(Me.Panel1)
        Me.GunaTransition1.SetDecoration(Me, Guna.UI.Animation.DecorationType.None)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form4"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form4"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GunaGradient2Panel1.ResumeLayout(False)
        Me.GunaElipsePanel2.ResumeLayout(False)
        Me.GunaElipsePanel2.PerformLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GunaElipsePanel3.ResumeLayout(False)
        Me.GunaElipsePanel3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GunaElipsePanel1.ResumeLayout(False)
        Me.GunaElipsePanel1.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GunaShadowPanel4.ResumeLayout(False)
        Me.GunaShadowPanel4.PerformLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GunaCircleProgressBar4.ResumeLayout(False)
        Me.GunaCircleProgressBar4.PerformLayout()
        Me.GunaShadowPanel3.ResumeLayout(False)
        Me.GunaShadowPanel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Panel1 As PanelEx
    Friend WithEvents GunaShadowPanel4 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents GunaCircleProgressBar4 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents Label44 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents CartesianChart1 As LiveCharts.WinForms.CartesianChart
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents GunaShadowPanel3 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents GunaElipsePanel1 As Guna.UI.WinForms.GunaElipsePanel
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents GunaCircleProgressBar6 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBar5 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBar3 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBar1 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaCircleProgressBar2 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaProgressBar4 As Guna.UI.WinForms.GunaProgressBar
    Friend WithEvents GunaProgressBar3 As Guna.UI.WinForms.GunaProgressBar
    Friend WithEvents GunaProgressBar2 As Guna.UI.WinForms.GunaProgressBar
    Friend WithEvents GunaProgressBar1 As Guna.UI.WinForms.GunaProgressBar
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Private WithEvents RadialGauge3 As Syncfusion.Windows.Forms.Gauge.RadialGauge
    Private WithEvents RadialGauge2 As Syncfusion.Windows.Forms.Gauge.RadialGauge
    Private WithEvents RadialGauge1 As Syncfusion.Windows.Forms.Gauge.RadialGauge
    Friend WithEvents Label2 As Label
    Friend WithEvents GunaElipsePanel3 As Guna.UI.WinForms.GunaElipsePanel
    Friend WithEvents Label14 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents GunaGradient2Panel1 As Guna.UI.WinForms.GunaGradient2Panel
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents WebBrowser1 As WebBrowser
    Friend WithEvents ListBox3 As ListBox
    Friend WithEvents GunaElipsePanel2 As Guna.UI.WinForms.GunaElipsePanel
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Label16 As Label
    Friend WithEvents GunaCircleProgressBar7 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents GunaTransition1 As Guna.UI.WinForms.GunaTransition
    Friend WithEvents GunaSeparator2 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents GunaSeparator1 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents nav_settings As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaAdvenceButton1 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Label13 As Label
    Friend WithEvents GunaAnimateWindow1 As Guna.UI.WinForms.GunaAnimateWindow
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Timer3 As Timer
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents Panel2 As Panel
End Class
