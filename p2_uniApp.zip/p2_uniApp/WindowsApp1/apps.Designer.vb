﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class apps
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(apps))
        Me.GunaShadowPanel2 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton1 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaShadowPanel1 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton2 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaShadowPanel3 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton3 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaShadowPanel4 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton4 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaShadowPanel5 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton5 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaShadowPanel6 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton6 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaShadowPanel7 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton7 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaShadowPanel8 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton8 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaShadowPanel9 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton9 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaShadowPanel10 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton10 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaShadowPanel11 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton11 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaShadowPanel2.SuspendLayout()
        Me.GunaShadowPanel1.SuspendLayout()
        Me.GunaShadowPanel3.SuspendLayout()
        Me.GunaShadowPanel4.SuspendLayout()
        Me.GunaShadowPanel5.SuspendLayout()
        Me.GunaShadowPanel6.SuspendLayout()
        Me.GunaShadowPanel7.SuspendLayout()
        Me.GunaShadowPanel8.SuspendLayout()
        Me.GunaShadowPanel9.SuspendLayout()
        Me.GunaShadowPanel10.SuspendLayout()
        Me.GunaShadowPanel11.SuspendLayout()
        Me.SuspendLayout()
        '
        'GunaShadowPanel2
        '
        Me.GunaShadowPanel2.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel2.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel2.Controls.Add(Me.GunaAdvenceTileButton1)
        Me.GunaShadowPanel2.Location = New System.Drawing.Point(33, 12)
        Me.GunaShadowPanel2.Name = "GunaShadowPanel2"
        Me.GunaShadowPanel2.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel2.ShadowShift = 1
        Me.GunaShadowPanel2.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel2.Size = New System.Drawing.Size(269, 210)
        Me.GunaShadowPanel2.TabIndex = 42
        '
        'GunaAdvenceTileButton1
        '
        Me.GunaAdvenceTileButton1.AllowDrop = True
        Me.GunaAdvenceTileButton1.Animated = True
        Me.GunaAdvenceTileButton1.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton1.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton1.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton1.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton1.BorderSize = 1
        Me.GunaAdvenceTileButton1.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton1.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton1.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton1.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton1.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton1.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton1.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton1.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton1.Image = CType(resources.GetObject("GunaAdvenceTileButton1.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton1.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton1.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton1.Location = New System.Drawing.Point(3, 4)
        Me.GunaAdvenceTileButton1.Name = "GunaAdvenceTileButton1"
        Me.GunaAdvenceTileButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton1.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton1.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton1.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton1.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton1.Radius = 2
        Me.GunaAdvenceTileButton1.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton1.TabIndex = 2
        Me.GunaAdvenceTileButton1.Text = "Office 365"
        Me.GunaAdvenceTileButton1.TextImageOffsetY = 5
        '
        'GunaShadowPanel1
        '
        Me.GunaShadowPanel1.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel1.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel1.Controls.Add(Me.GunaAdvenceTileButton2)
        Me.GunaShadowPanel1.Location = New System.Drawing.Point(318, 12)
        Me.GunaShadowPanel1.Name = "GunaShadowPanel1"
        Me.GunaShadowPanel1.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel1.ShadowShift = 1
        Me.GunaShadowPanel1.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel1.Size = New System.Drawing.Size(269, 210)
        Me.GunaShadowPanel1.TabIndex = 43
        '
        'GunaAdvenceTileButton2
        '
        Me.GunaAdvenceTileButton2.AllowDrop = True
        Me.GunaAdvenceTileButton2.Animated = True
        Me.GunaAdvenceTileButton2.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton2.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton2.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton2.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton2.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton2.BorderSize = 1
        Me.GunaAdvenceTileButton2.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton2.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton2.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton2.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton2.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton2.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton2.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton2.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton2.Image = CType(resources.GetObject("GunaAdvenceTileButton2.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton2.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton2.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton2.Location = New System.Drawing.Point(3, 4)
        Me.GunaAdvenceTileButton2.Name = "GunaAdvenceTileButton2"
        Me.GunaAdvenceTileButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton2.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton2.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton2.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton2.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton2.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton2.Radius = 2
        Me.GunaAdvenceTileButton2.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton2.TabIndex = 2
        Me.GunaAdvenceTileButton2.Text = "Word"
        Me.GunaAdvenceTileButton2.TextImageOffsetY = 5
        '
        'GunaShadowPanel3
        '
        Me.GunaShadowPanel3.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel3.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel3.Controls.Add(Me.GunaAdvenceTileButton3)
        Me.GunaShadowPanel3.Location = New System.Drawing.Point(611, 12)
        Me.GunaShadowPanel3.Name = "GunaShadowPanel3"
        Me.GunaShadowPanel3.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel3.ShadowShift = 1
        Me.GunaShadowPanel3.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel3.Size = New System.Drawing.Size(269, 210)
        Me.GunaShadowPanel3.TabIndex = 43
        '
        'GunaAdvenceTileButton3
        '
        Me.GunaAdvenceTileButton3.AllowDrop = True
        Me.GunaAdvenceTileButton3.Animated = True
        Me.GunaAdvenceTileButton3.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton3.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton3.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton3.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton3.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton3.BorderSize = 1
        Me.GunaAdvenceTileButton3.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton3.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton3.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton3.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton3.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton3.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton3.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton3.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton3.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton3.Image = CType(resources.GetObject("GunaAdvenceTileButton3.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton3.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton3.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton3.Location = New System.Drawing.Point(3, 4)
        Me.GunaAdvenceTileButton3.Name = "GunaAdvenceTileButton3"
        Me.GunaAdvenceTileButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton3.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton3.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton3.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton3.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton3.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton3.Radius = 2
        Me.GunaAdvenceTileButton3.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton3.TabIndex = 2
        Me.GunaAdvenceTileButton3.Text = "Power Point"
        Me.GunaAdvenceTileButton3.TextImageOffsetY = 5
        '
        'GunaShadowPanel4
        '
        Me.GunaShadowPanel4.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel4.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel4.Controls.Add(Me.GunaAdvenceTileButton4)
        Me.GunaShadowPanel4.Location = New System.Drawing.Point(902, 12)
        Me.GunaShadowPanel4.Name = "GunaShadowPanel4"
        Me.GunaShadowPanel4.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel4.ShadowShift = 1
        Me.GunaShadowPanel4.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel4.Size = New System.Drawing.Size(269, 210)
        Me.GunaShadowPanel4.TabIndex = 44
        '
        'GunaAdvenceTileButton4
        '
        Me.GunaAdvenceTileButton4.AllowDrop = True
        Me.GunaAdvenceTileButton4.Animated = True
        Me.GunaAdvenceTileButton4.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton4.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton4.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton4.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton4.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton4.BorderSize = 1
        Me.GunaAdvenceTileButton4.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton4.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton4.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton4.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton4.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton4.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton4.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton4.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton4.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton4.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton4.Image = CType(resources.GetObject("GunaAdvenceTileButton4.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton4.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton4.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton4.Location = New System.Drawing.Point(3, 4)
        Me.GunaAdvenceTileButton4.Name = "GunaAdvenceTileButton4"
        Me.GunaAdvenceTileButton4.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton4.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton4.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton4.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton4.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton4.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton4.Radius = 2
        Me.GunaAdvenceTileButton4.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton4.TabIndex = 2
        Me.GunaAdvenceTileButton4.Text = "Discord Server"
        Me.GunaAdvenceTileButton4.TextImageOffsetY = 5
        '
        'GunaShadowPanel5
        '
        Me.GunaShadowPanel5.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel5.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel5.Controls.Add(Me.GunaAdvenceTileButton5)
        Me.GunaShadowPanel5.Location = New System.Drawing.Point(33, 254)
        Me.GunaShadowPanel5.Name = "GunaShadowPanel5"
        Me.GunaShadowPanel5.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel5.ShadowShift = 1
        Me.GunaShadowPanel5.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel5.Size = New System.Drawing.Size(269, 210)
        Me.GunaShadowPanel5.TabIndex = 45
        '
        'GunaAdvenceTileButton5
        '
        Me.GunaAdvenceTileButton5.AllowDrop = True
        Me.GunaAdvenceTileButton5.Animated = True
        Me.GunaAdvenceTileButton5.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton5.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton5.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton5.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton5.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton5.BorderSize = 1
        Me.GunaAdvenceTileButton5.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton5.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton5.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton5.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton5.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton5.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton5.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton5.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton5.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton5.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton5.Image = CType(resources.GetObject("GunaAdvenceTileButton5.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton5.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton5.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton5.Location = New System.Drawing.Point(3, 4)
        Me.GunaAdvenceTileButton5.Name = "GunaAdvenceTileButton5"
        Me.GunaAdvenceTileButton5.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton5.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton5.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton5.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton5.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton5.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton5.Radius = 2
        Me.GunaAdvenceTileButton5.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton5.TabIndex = 2
        Me.GunaAdvenceTileButton5.Text = "Microsoft Teams"
        Me.GunaAdvenceTileButton5.TextImageOffsetY = 5
        '
        'GunaShadowPanel6
        '
        Me.GunaShadowPanel6.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel6.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel6.Controls.Add(Me.GunaAdvenceTileButton6)
        Me.GunaShadowPanel6.Location = New System.Drawing.Point(318, 254)
        Me.GunaShadowPanel6.Name = "GunaShadowPanel6"
        Me.GunaShadowPanel6.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel6.ShadowShift = 1
        Me.GunaShadowPanel6.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel6.Size = New System.Drawing.Size(269, 210)
        Me.GunaShadowPanel6.TabIndex = 43
        '
        'GunaAdvenceTileButton6
        '
        Me.GunaAdvenceTileButton6.AllowDrop = True
        Me.GunaAdvenceTileButton6.Animated = True
        Me.GunaAdvenceTileButton6.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton6.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton6.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton6.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton6.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton6.BorderSize = 1
        Me.GunaAdvenceTileButton6.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton6.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton6.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton6.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton6.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton6.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton6.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton6.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton6.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton6.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton6.Image = CType(resources.GetObject("GunaAdvenceTileButton6.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton6.ImageSize = New System.Drawing.Size(130, 130)
        Me.GunaAdvenceTileButton6.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton6.Location = New System.Drawing.Point(3, 4)
        Me.GunaAdvenceTileButton6.Name = "GunaAdvenceTileButton6"
        Me.GunaAdvenceTileButton6.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton6.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton6.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton6.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton6.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton6.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton6.Radius = 2
        Me.GunaAdvenceTileButton6.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton6.TabIndex = 2
        Me.GunaAdvenceTileButton6.Text = "Wolfram Alpha"
        Me.GunaAdvenceTileButton6.TextImageOffsetY = 6
        '
        'GunaShadowPanel7
        '
        Me.GunaShadowPanel7.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel7.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel7.Controls.Add(Me.GunaAdvenceTileButton7)
        Me.GunaShadowPanel7.Location = New System.Drawing.Point(611, 254)
        Me.GunaShadowPanel7.Name = "GunaShadowPanel7"
        Me.GunaShadowPanel7.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel7.ShadowShift = 1
        Me.GunaShadowPanel7.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel7.Size = New System.Drawing.Size(269, 210)
        Me.GunaShadowPanel7.TabIndex = 46
        '
        'GunaAdvenceTileButton7
        '
        Me.GunaAdvenceTileButton7.AllowDrop = True
        Me.GunaAdvenceTileButton7.Animated = True
        Me.GunaAdvenceTileButton7.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton7.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton7.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton7.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton7.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton7.BorderSize = 1
        Me.GunaAdvenceTileButton7.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton7.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton7.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton7.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton7.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton7.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton7.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton7.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton7.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton7.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton7.Image = CType(resources.GetObject("GunaAdvenceTileButton7.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton7.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton7.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton7.Location = New System.Drawing.Point(3, 4)
        Me.GunaAdvenceTileButton7.Name = "GunaAdvenceTileButton7"
        Me.GunaAdvenceTileButton7.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton7.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton7.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton7.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton7.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton7.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton7.Radius = 2
        Me.GunaAdvenceTileButton7.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton7.TabIndex = 2
        Me.GunaAdvenceTileButton7.Text = "CS Drive"
        Me.GunaAdvenceTileButton7.TextImageOffsetY = 5
        '
        'GunaShadowPanel8
        '
        Me.GunaShadowPanel8.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel8.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel8.Controls.Add(Me.GunaAdvenceTileButton8)
        Me.GunaShadowPanel8.Location = New System.Drawing.Point(902, 254)
        Me.GunaShadowPanel8.Name = "GunaShadowPanel8"
        Me.GunaShadowPanel8.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel8.ShadowShift = 1
        Me.GunaShadowPanel8.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel8.Size = New System.Drawing.Size(269, 210)
        Me.GunaShadowPanel8.TabIndex = 47
        '
        'GunaAdvenceTileButton8
        '
        Me.GunaAdvenceTileButton8.AllowDrop = True
        Me.GunaAdvenceTileButton8.Animated = True
        Me.GunaAdvenceTileButton8.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton8.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton8.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton8.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton8.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton8.BorderSize = 1
        Me.GunaAdvenceTileButton8.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton8.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton8.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton8.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton8.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton8.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton8.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton8.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton8.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton8.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton8.Image = CType(resources.GetObject("GunaAdvenceTileButton8.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton8.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton8.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton8.Location = New System.Drawing.Point(3, 4)
        Me.GunaAdvenceTileButton8.Name = "GunaAdvenceTileButton8"
        Me.GunaAdvenceTileButton8.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton8.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton8.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton8.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton8.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton8.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton8.Radius = 2
        Me.GunaAdvenceTileButton8.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton8.TabIndex = 2
        Me.GunaAdvenceTileButton8.Text = "Outlook Mail"
        Me.GunaAdvenceTileButton8.TextImageOffsetY = 5
        '
        'GunaShadowPanel9
        '
        Me.GunaShadowPanel9.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel9.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel9.Controls.Add(Me.GunaAdvenceTileButton9)
        Me.GunaShadowPanel9.Location = New System.Drawing.Point(33, 488)
        Me.GunaShadowPanel9.Name = "GunaShadowPanel9"
        Me.GunaShadowPanel9.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel9.ShadowShift = 1
        Me.GunaShadowPanel9.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel9.Size = New System.Drawing.Size(269, 210)
        Me.GunaShadowPanel9.TabIndex = 49
        '
        'GunaAdvenceTileButton9
        '
        Me.GunaAdvenceTileButton9.AllowDrop = True
        Me.GunaAdvenceTileButton9.Animated = True
        Me.GunaAdvenceTileButton9.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton9.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton9.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton9.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton9.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton9.BorderSize = 1
        Me.GunaAdvenceTileButton9.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton9.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton9.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton9.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton9.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton9.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton9.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton9.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton9.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton9.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton9.Image = CType(resources.GetObject("GunaAdvenceTileButton9.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton9.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton9.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton9.Location = New System.Drawing.Point(3, 4)
        Me.GunaAdvenceTileButton9.Name = "GunaAdvenceTileButton9"
        Me.GunaAdvenceTileButton9.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton9.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton9.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton9.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton9.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton9.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton9.Radius = 2
        Me.GunaAdvenceTileButton9.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton9.TabIndex = 2
        Me.GunaAdvenceTileButton9.Text = "Ecourse UOI"
        Me.GunaAdvenceTileButton9.TextImageOffsetY = 5
        '
        'GunaShadowPanel10
        '
        Me.GunaShadowPanel10.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel10.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel10.Controls.Add(Me.GunaAdvenceTileButton10)
        Me.GunaShadowPanel10.Location = New System.Drawing.Point(318, 488)
        Me.GunaShadowPanel10.Name = "GunaShadowPanel10"
        Me.GunaShadowPanel10.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel10.ShadowShift = 1
        Me.GunaShadowPanel10.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel10.Size = New System.Drawing.Size(269, 210)
        Me.GunaShadowPanel10.TabIndex = 48
        '
        'GunaAdvenceTileButton10
        '
        Me.GunaAdvenceTileButton10.AllowDrop = True
        Me.GunaAdvenceTileButton10.Animated = True
        Me.GunaAdvenceTileButton10.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton10.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton10.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton10.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton10.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton10.BorderSize = 1
        Me.GunaAdvenceTileButton10.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton10.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton10.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton10.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton10.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton10.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton10.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton10.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton10.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton10.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton10.Image = CType(resources.GetObject("GunaAdvenceTileButton10.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton10.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton10.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton10.Location = New System.Drawing.Point(3, 4)
        Me.GunaAdvenceTileButton10.Name = "GunaAdvenceTileButton10"
        Me.GunaAdvenceTileButton10.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton10.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton10.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton10.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton10.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton10.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton10.Radius = 2
        Me.GunaAdvenceTileButton10.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton10.TabIndex = 2
        Me.GunaAdvenceTileButton10.Text = "Adobe Pack"
        Me.GunaAdvenceTileButton10.TextImageOffsetY = 6
        '
        'GunaShadowPanel11
        '
        Me.GunaShadowPanel11.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel11.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel11.Controls.Add(Me.GunaAdvenceTileButton11)
        Me.GunaShadowPanel11.Location = New System.Drawing.Point(611, 488)
        Me.GunaShadowPanel11.Name = "GunaShadowPanel11"
        Me.GunaShadowPanel11.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel11.ShadowShift = 1
        Me.GunaShadowPanel11.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel11.Size = New System.Drawing.Size(269, 210)
        Me.GunaShadowPanel11.TabIndex = 50
        '
        'GunaAdvenceTileButton11
        '
        Me.GunaAdvenceTileButton11.AllowDrop = True
        Me.GunaAdvenceTileButton11.Animated = True
        Me.GunaAdvenceTileButton11.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton11.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton11.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton11.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton11.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton11.BorderSize = 1
        Me.GunaAdvenceTileButton11.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton11.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton11.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton11.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton11.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton11.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton11.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton11.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton11.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton11.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton11.Image = CType(resources.GetObject("GunaAdvenceTileButton11.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton11.ImageSize = New System.Drawing.Size(100, 100)
        Me.GunaAdvenceTileButton11.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton11.Location = New System.Drawing.Point(3, 4)
        Me.GunaAdvenceTileButton11.Name = "GunaAdvenceTileButton11"
        Me.GunaAdvenceTileButton11.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton11.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton11.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton11.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton11.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton11.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton11.Radius = 2
        Me.GunaAdvenceTileButton11.Size = New System.Drawing.Size(264, 202)
        Me.GunaAdvenceTileButton11.TabIndex = 2
        Me.GunaAdvenceTileButton11.Text = "Excel"
        Me.GunaAdvenceTileButton11.TextImageOffsetY = 6
        '
        'apps
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1279, 720)
        Me.Controls.Add(Me.GunaShadowPanel11)
        Me.Controls.Add(Me.GunaShadowPanel9)
        Me.Controls.Add(Me.GunaShadowPanel10)
        Me.Controls.Add(Me.GunaShadowPanel2)
        Me.Controls.Add(Me.GunaShadowPanel1)
        Me.Controls.Add(Me.GunaShadowPanel3)
        Me.Controls.Add(Me.GunaShadowPanel4)
        Me.Controls.Add(Me.GunaShadowPanel5)
        Me.Controls.Add(Me.GunaShadowPanel6)
        Me.Controls.Add(Me.GunaShadowPanel7)
        Me.Controls.Add(Me.GunaShadowPanel8)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "apps"
        Me.Text = "apps"
        Me.GunaShadowPanel2.ResumeLayout(False)
        Me.GunaShadowPanel1.ResumeLayout(False)
        Me.GunaShadowPanel3.ResumeLayout(False)
        Me.GunaShadowPanel4.ResumeLayout(False)
        Me.GunaShadowPanel5.ResumeLayout(False)
        Me.GunaShadowPanel6.ResumeLayout(False)
        Me.GunaShadowPanel7.ResumeLayout(False)
        Me.GunaShadowPanel8.ResumeLayout(False)
        Me.GunaShadowPanel9.ResumeLayout(False)
        Me.GunaShadowPanel10.ResumeLayout(False)
        Me.GunaShadowPanel11.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GunaShadowPanel2 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton1 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaShadowPanel1 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton2 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaShadowPanel3 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton3 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaShadowPanel4 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton4 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaShadowPanel5 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton5 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaShadowPanel6 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton6 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaShadowPanel7 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton7 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaShadowPanel8 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton8 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaShadowPanel9 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton9 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaShadowPanel10 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton10 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaShadowPanel11 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton11 As Guna.UI.WinForms.GunaAdvenceTileButton
End Class
