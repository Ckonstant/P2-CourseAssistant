﻿Public Class downloadMenu
    Private Sub GunaAdvenceButton3_Click(sender As Object, e As EventArgs) Handles GunaAdvenceButton3.Click

    End Sub

    Private Sub downloadMenu_Load(sender As Object, e As EventArgs) Handles Me.Load
        Me.Location = New Point(MousePosition)
    End Sub
End Class