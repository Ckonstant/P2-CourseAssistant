﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim GridBaseStyle1 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle2 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle3 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle4 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim Animation2 As Guna.UI.Animation.Animation = New Guna.UI.Animation.Animation()
        Dim Animation1 As Guna.UI.Animation.Animation = New Guna.UI.Animation.Animation()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GridControl1 = New Syncfusion.Windows.Forms.Grid.GridControl()
        Me.GunaPanel2 = New Guna.UI.WinForms.GunaPanel()
        Me.GunaPictureBox4 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaCircleProgressBar7 = New Guna.UI.WinForms.GunaCircleProgressBar()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GunaPictureBox2 = New Guna.UI.WinForms.GunaPictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GunaPictureBox3 = New Guna.UI.WinForms.GunaPictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GunaPictureBox1 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaControlBox3 = New Guna.UI.WinForms.GunaControlBox()
        Me.GunaControlBox1 = New Guna.UI.WinForms.GunaControlBox()
        Me.GunaControlBox2 = New Guna.UI.WinForms.GunaControlBox()
        Me.GunaTransition1 = New Guna.UI.WinForms.GunaTransition(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GunaPanel8 = New Guna.UI.WinForms.GunaPanel()
        Me.nav_settings = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaAdvenceButton7 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaAdvenceTileButton9 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceButton6 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaAdvenceTileButton5 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceButton5 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaButton22 = New Guna.UI.WinForms.GunaButton()
        Me.GunaAdvenceButton1 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaAdvenceButton4 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaAdvenceTileButton7 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceButton3 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaAdvenceTileButton8 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton3 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton4 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton1 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaAdvenceTileButton2 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaButton31 = New Guna.UI.WinForms.GunaButton()
        Me.GunaButton23 = New Guna.UI.WinForms.GunaButton()
        Me.GunaButton27 = New Guna.UI.WinForms.GunaButton()
        Me.GunaAdvenceTileButton6 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.GunaTransition2 = New Guna.UI.WinForms.GunaTransition(Me.components)
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GunaPanel2.SuspendLayout()
        CType(Me.GunaPictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GunaPictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GunaPictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GunaPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GunaPanel8.SuspendLayout()
        Me.SuspendLayout()
        '
        'GridControl1
        '
        GridBaseStyle1.Name = "Header"
        GridBaseStyle1.StyleInfo.Borders.Bottom = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle1.StyleInfo.Borders.Left = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle1.StyleInfo.Borders.Right = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle1.StyleInfo.Borders.Top = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle1.StyleInfo.CellType = "Header"
        GridBaseStyle1.StyleInfo.Font.Bold = True
        GridBaseStyle1.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(Syncfusion.Drawing.GradientStyle.Vertical, System.Drawing.Color.FromArgb(CType(CType(203, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(184, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(238, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(216, Byte), Integer)))
        GridBaseStyle1.StyleInfo.VerticalAlignment = Syncfusion.Windows.Forms.Grid.GridVerticalAlignment.Middle
        GridBaseStyle2.Name = "Standard"
        GridBaseStyle2.StyleInfo.Font.Facename = "Tahoma"
        GridBaseStyle2.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Window)
        GridBaseStyle3.Name = "Column Header"
        GridBaseStyle3.StyleInfo.BaseStyle = "Header"
        GridBaseStyle3.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Center
        GridBaseStyle4.Name = "Row Header"
        GridBaseStyle4.StyleInfo.BaseStyle = "Header"
        GridBaseStyle4.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Left
        GridBaseStyle4.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(Syncfusion.Drawing.GradientStyle.Horizontal, System.Drawing.Color.FromArgb(CType(CType(203, Byte), Integer), CType(CType(199, Byte), Integer), CType(CType(184, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(238, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(216, Byte), Integer)))
        Me.GridControl1.BaseStylesMap.AddRange(New Syncfusion.Windows.Forms.Grid.GridBaseStyle() {GridBaseStyle1, GridBaseStyle2, GridBaseStyle3, GridBaseStyle4})
        Me.GridControl1.ColWidthEntries.AddRange(New Syncfusion.Windows.Forms.Grid.GridColWidth() {New Syncfusion.Windows.Forms.Grid.GridColWidth(0, 35)})
        Me.GunaTransition2.SetDecoration(Me.GridControl1, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GridControl1, Guna.UI.Animation.DecorationType.None)
        Me.GridControl1.Location = New System.Drawing.Point(0, 0)
        Me.GridControl1.Name = "GridControl1"
        Me.GridControl1.RowHeightEntries.AddRange(New Syncfusion.Windows.Forms.Grid.GridRowHeight() {New Syncfusion.Windows.Forms.Grid.GridRowHeight(0, 25)})
        Me.GridControl1.SerializeCellsBehavior = Syncfusion.Windows.Forms.Grid.GridSerializeCellsBehavior.SerializeIntoCode
        Me.GridControl1.Size = New System.Drawing.Size(130, 80)
        Me.GridControl1.SmartSizeBox = False
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonBorderColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonDisabledBackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonDisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonHoverBackColor = System.Drawing.Color.FromArgb(CType(CType(114, Byte), Integer), CType(CType(114, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonHoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonPressedBackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ArrowButtonPressedBorderColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ScrollBarBackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbBorderColor = System.Drawing.Color.FromArgb(CType(CType(171, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(171, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbDisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbDisabledColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbHoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(171, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(171, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbHoverColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(197, Byte), Integer), CType(CType(197, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbPressedBorderColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.GridControl1.ThemeStyle.HorizontalScrollBarStyle.ThumbPressedColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(197, Byte), Integer), CType(CType(197, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonBorderColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonDisabledBackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonDisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonHoverBackColor = System.Drawing.Color.FromArgb(CType(CType(114, Byte), Integer), CType(CType(114, Byte), Integer), CType(CType(114, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonHoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(94, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonPressedBackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ArrowButtonPressedBorderColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ScrollBarBackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ThumbBorderColor = System.Drawing.Color.FromArgb(CType(CType(171, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(171, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ThumbColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ThumbDisabledBorderColor = System.Drawing.Color.FromArgb(CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer), CType(CType(210, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ThumbDisabledColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ThumbHoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(171, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(171, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ThumbHoverColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(197, Byte), Integer), CType(CType(197, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ThumbPressedBorderColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.GridControl1.ThemeStyle.VerticalScrollBarStyle.ThumbPressedColor = System.Drawing.Color.FromArgb(CType(CType(197, Byte), Integer), CType(CType(197, Byte), Integer), CType(CType(197, Byte), Integer))
        '
        'GunaPanel2
        '
        Me.GunaPanel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaPanel2.Controls.Add(Me.GunaPictureBox4)
        Me.GunaPanel2.Controls.Add(Me.GunaCircleProgressBar7)
        Me.GunaPanel2.Controls.Add(Me.Label4)
        Me.GunaPanel2.Controls.Add(Me.Label3)
        Me.GunaPanel2.Controls.Add(Me.GunaPictureBox2)
        Me.GunaPanel2.Controls.Add(Me.Label2)
        Me.GunaPanel2.Controls.Add(Me.GunaPictureBox3)
        Me.GunaPanel2.Controls.Add(Me.Label1)
        Me.GunaPanel2.Controls.Add(Me.GunaPictureBox1)
        Me.GunaPanel2.Controls.Add(Me.GunaControlBox3)
        Me.GunaPanel2.Controls.Add(Me.GunaControlBox1)
        Me.GunaPanel2.Controls.Add(Me.GunaControlBox2)
        Me.GunaTransition2.SetDecoration(Me.GunaPanel2, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaPanel2, Guna.UI.Animation.DecorationType.None)
        Me.GunaPanel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.GunaPanel2.Location = New System.Drawing.Point(0, 0)
        Me.GunaPanel2.Name = "GunaPanel2"
        Me.GunaPanel2.Size = New System.Drawing.Size(1357, 48)
        Me.GunaPanel2.TabIndex = 35
        '
        'GunaPictureBox4
        '
        Me.GunaPictureBox4.BackgroundImage = CType(resources.GetObject("GunaPictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.GunaPictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaPictureBox4.BaseColor = System.Drawing.Color.White
        Me.GunaTransition2.SetDecoration(Me.GunaPictureBox4, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaPictureBox4, Guna.UI.Animation.DecorationType.None)
        Me.GunaPictureBox4.Location = New System.Drawing.Point(1175, 2)
        Me.GunaPictureBox4.Name = "GunaPictureBox4"
        Me.GunaPictureBox4.Size = New System.Drawing.Size(30, 30)
        Me.GunaPictureBox4.TabIndex = 131
        Me.GunaPictureBox4.TabStop = False
        Me.GunaPictureBox4.Visible = False
        '
        'GunaCircleProgressBar7
        '
        Me.GunaCircleProgressBar7.Animated = True
        Me.GunaCircleProgressBar7.AnimationSpeed = 0.6!
        Me.GunaCircleProgressBar7.BaseColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaTransition2.SetDecoration(Me.GunaCircleProgressBar7, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaCircleProgressBar7, Guna.UI.Animation.DecorationType.None)
        Me.GunaCircleProgressBar7.IdleColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaCircleProgressBar7.IdleOffset = 0
        Me.GunaCircleProgressBar7.IdleThickness = 3
        Me.GunaCircleProgressBar7.Image = Nothing
        Me.GunaCircleProgressBar7.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaCircleProgressBar7.Location = New System.Drawing.Point(470, 9)
        Me.GunaCircleProgressBar7.Name = "GunaCircleProgressBar7"
        Me.GunaCircleProgressBar7.ProgressMaxColor = System.Drawing.Color.White
        Me.GunaCircleProgressBar7.ProgressMinColor = System.Drawing.Color.GhostWhite
        Me.GunaCircleProgressBar7.ProgressOffset = 0
        Me.GunaCircleProgressBar7.ProgressThickness = 3
        Me.GunaCircleProgressBar7.Size = New System.Drawing.Size(25, 25)
        Me.GunaCircleProgressBar7.TabIndex = 130
        Me.GunaCircleProgressBar7.Value = 50
        Me.GunaCircleProgressBar7.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label4, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition2.SetDecoration(Me.Label4, Guna.UI.Animation.DecorationType.None)
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label4.Location = New System.Drawing.Point(66, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 13)
        Me.Label4.TabIndex = 83
        Me.Label4.Text = "time"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label3, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition2.SetDecoration(Me.Label3, Guna.UI.Animation.DecorationType.None)
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(1100, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 15)
        Me.Label3.TabIndex = 82
        Me.Label3.Text = "betatester"
        '
        'GunaPictureBox2
        '
        Me.GunaPictureBox2.BackgroundImage = CType(resources.GetObject("GunaPictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.GunaPictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaPictureBox2.BaseColor = System.Drawing.Color.White
        Me.GunaTransition2.SetDecoration(Me.GunaPictureBox2, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaPictureBox2, Guna.UI.Animation.DecorationType.None)
        Me.GunaPictureBox2.Location = New System.Drawing.Point(1112, 4)
        Me.GunaPictureBox2.Name = "GunaPictureBox2"
        Me.GunaPictureBox2.Size = New System.Drawing.Size(30, 30)
        Me.GunaPictureBox2.TabIndex = 81
        Me.GunaPictureBox2.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label2, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition2.SetDecoration(Me.Label2, Guna.UI.Animation.DecorationType.None)
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(1166, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 15)
        Me.Label2.TabIndex = 80
        Me.Label2.Text = "Σύνδεση"
        '
        'GunaPictureBox3
        '
        Me.GunaPictureBox3.BackgroundImage = CType(resources.GetObject("GunaPictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.GunaPictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaPictureBox3.BaseColor = System.Drawing.Color.White
        Me.GunaTransition2.SetDecoration(Me.GunaPictureBox3, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaPictureBox3, Guna.UI.Animation.DecorationType.None)
        Me.GunaPictureBox3.Location = New System.Drawing.Point(1175, 2)
        Me.GunaPictureBox3.Name = "GunaPictureBox3"
        Me.GunaPictureBox3.Size = New System.Drawing.Size(30, 30)
        Me.GunaPictureBox3.TabIndex = 79
        Me.GunaPictureBox3.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.GunaTransition1.SetDecoration(Me.Label1, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition2.SetDecoration(Me.Label1, Guna.UI.Animation.DecorationType.None)
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(62, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(402, 24)
        Me.Label1.TabIndex = 77
        Me.Label1.Text = "University of Ioannina (Computer Science)"
        '
        'GunaPictureBox1
        '
        Me.GunaPictureBox1.BackgroundImage = CType(resources.GetObject("GunaPictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.GunaPictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaPictureBox1.BaseColor = System.Drawing.Color.White
        Me.GunaTransition2.SetDecoration(Me.GunaPictureBox1, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaPictureBox1, Guna.UI.Animation.DecorationType.None)
        Me.GunaPictureBox1.Location = New System.Drawing.Point(3, 0)
        Me.GunaPictureBox1.Name = "GunaPictureBox1"
        Me.GunaPictureBox1.Size = New System.Drawing.Size(42, 46)
        Me.GunaPictureBox1.TabIndex = 76
        Me.GunaPictureBox1.TabStop = False
        '
        'GunaControlBox3
        '
        Me.GunaControlBox3.AnimationHoverSpeed = 0.07!
        Me.GunaControlBox3.AnimationSpeed = 0.03!
        Me.GunaControlBox3.BackColor = System.Drawing.Color.Transparent
        Me.GunaControlBox3.ControlBoxType = Guna.UI.WinForms.FormControlBoxType.MinimizeBox
        Me.GunaControlBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaControlBox3, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaControlBox3, Guna.UI.Animation.DecorationType.None)
        Me.GunaControlBox3.Dock = System.Windows.Forms.DockStyle.Right
        Me.GunaControlBox3.IconColor = System.Drawing.Color.White
        Me.GunaControlBox3.IconSize = 15.0!
        Me.GunaControlBox3.Location = New System.Drawing.Point(1227, 0)
        Me.GunaControlBox3.Name = "GunaControlBox3"
        Me.GunaControlBox3.OnHoverBackColor = System.Drawing.Color.FromArgb(CType(CType(103, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(183, Byte), Integer))
        Me.GunaControlBox3.OnHoverIconColor = System.Drawing.Color.White
        Me.GunaControlBox3.OnPressedColor = System.Drawing.Color.Black
        Me.GunaControlBox3.Size = New System.Drawing.Size(42, 48)
        Me.GunaControlBox3.TabIndex = 18
        '
        'GunaControlBox1
        '
        Me.GunaControlBox1.AnimationHoverSpeed = 0.07!
        Me.GunaControlBox1.AnimationSpeed = 0.03!
        Me.GunaControlBox1.BackColor = System.Drawing.Color.Transparent
        Me.GunaControlBox1.ControlBoxType = Guna.UI.WinForms.FormControlBoxType.MaximizeBox
        Me.GunaControlBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaControlBox1, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaControlBox1, Guna.UI.Animation.DecorationType.None)
        Me.GunaControlBox1.Dock = System.Windows.Forms.DockStyle.Right
        Me.GunaControlBox1.IconColor = System.Drawing.Color.White
        Me.GunaControlBox1.IconSize = 15.0!
        Me.GunaControlBox1.Location = New System.Drawing.Point(1269, 0)
        Me.GunaControlBox1.Name = "GunaControlBox1"
        Me.GunaControlBox1.OnHoverBackColor = System.Drawing.Color.FromArgb(CType(CType(103, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(183, Byte), Integer))
        Me.GunaControlBox1.OnHoverIconColor = System.Drawing.Color.White
        Me.GunaControlBox1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaControlBox1.Size = New System.Drawing.Size(43, 48)
        Me.GunaControlBox1.TabIndex = 10
        '
        'GunaControlBox2
        '
        Me.GunaControlBox2.AnimationHoverSpeed = 0.07!
        Me.GunaControlBox2.AnimationSpeed = 0.03!
        Me.GunaControlBox2.BackColor = System.Drawing.Color.Transparent
        Me.GunaControlBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaControlBox2, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaControlBox2, Guna.UI.Animation.DecorationType.None)
        Me.GunaControlBox2.Dock = System.Windows.Forms.DockStyle.Right
        Me.GunaControlBox2.IconColor = System.Drawing.Color.White
        Me.GunaControlBox2.IconSize = 15.0!
        Me.GunaControlBox2.Location = New System.Drawing.Point(1312, 0)
        Me.GunaControlBox2.Name = "GunaControlBox2"
        Me.GunaControlBox2.OnHoverBackColor = System.Drawing.Color.Red
        Me.GunaControlBox2.OnHoverIconColor = System.Drawing.Color.White
        Me.GunaControlBox2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaControlBox2.Size = New System.Drawing.Size(45, 48)
        Me.GunaControlBox2.TabIndex = 17
        '
        'GunaTransition1
        '
        Me.GunaTransition1.AnimationType = Guna.UI.Animation.AnimationType.HorizSlide
        Me.GunaTransition1.Cursor = Nothing
        Animation2.AnimateOnlyDifferences = True
        Animation2.BlindCoeff = CType(resources.GetObject("Animation2.BlindCoeff"), System.Drawing.PointF)
        Animation2.LeafCoeff = 0!
        Animation2.MaxTime = 1.0!
        Animation2.MinTime = 0!
        Animation2.MosaicCoeff = CType(resources.GetObject("Animation2.MosaicCoeff"), System.Drawing.PointF)
        Animation2.MosaicShift = CType(resources.GetObject("Animation2.MosaicShift"), System.Drawing.PointF)
        Animation2.MosaicSize = 0
        Animation2.Padding = New System.Windows.Forms.Padding(0)
        Animation2.RotateCoeff = 0!
        Animation2.RotateLimit = 0!
        Animation2.ScaleCoeff = CType(resources.GetObject("Animation2.ScaleCoeff"), System.Drawing.PointF)
        Animation2.SlideCoeff = CType(resources.GetObject("Animation2.SlideCoeff"), System.Drawing.PointF)
        Animation2.TimeCoeff = 0!
        Animation2.TransparencyCoeff = 0!
        Me.GunaTransition1.DefaultAnimation = Animation2
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.GunaTransition2.SetDecoration(Me.Panel1, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.Panel1, Guna.UI.Animation.DecorationType.None)
        Me.Panel1.Location = New System.Drawing.Point(78, 48)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1279, 720)
        Me.Panel1.TabIndex = 36
        '
        'GunaPanel8
        '
        Me.GunaPanel8.BackColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaPanel8.Controls.Add(Me.nav_settings)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceButton7)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceTileButton9)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceButton6)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceTileButton5)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceButton5)
        Me.GunaPanel8.Controls.Add(Me.GunaButton22)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceButton1)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceButton4)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceTileButton7)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceButton3)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceTileButton8)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceTileButton3)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceTileButton4)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceTileButton1)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceTileButton2)
        Me.GunaPanel8.Controls.Add(Me.GunaButton31)
        Me.GunaPanel8.Controls.Add(Me.GunaButton23)
        Me.GunaPanel8.Controls.Add(Me.GunaButton27)
        Me.GunaPanel8.Controls.Add(Me.GunaAdvenceTileButton6)
        Me.GunaTransition2.SetDecoration(Me.GunaPanel8, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaPanel8, Guna.UI.Animation.DecorationType.None)
        Me.GunaPanel8.Dock = System.Windows.Forms.DockStyle.Left
        Me.GunaPanel8.Location = New System.Drawing.Point(0, 48)
        Me.GunaPanel8.Name = "GunaPanel8"
        Me.GunaPanel8.Size = New System.Drawing.Size(78, 720)
        Me.GunaPanel8.TabIndex = 48
        '
        'nav_settings
        '
        Me.nav_settings.Animated = True
        Me.nav_settings.AnimationHoverSpeed = 0.07!
        Me.nav_settings.AnimationSpeed = 0.03!
        Me.nav_settings.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.nav_settings.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.nav_settings.BorderColor = System.Drawing.Color.Black
        Me.nav_settings.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.nav_settings.Checked = True
        Me.nav_settings.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.nav_settings.CheckedBorderColor = System.Drawing.Color.Black
        Me.nav_settings.CheckedForeColor = System.Drawing.Color.Gray
        Me.nav_settings.CheckedImage = CType(resources.GetObject("nav_settings.CheckedImage"), System.Drawing.Image)
        Me.nav_settings.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.nav_settings.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.nav_settings, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.nav_settings, Guna.UI.Animation.DecorationType.None)
        Me.nav_settings.DialogResult = System.Windows.Forms.DialogResult.None
        Me.nav_settings.FocusedColor = System.Drawing.Color.Empty
        Me.nav_settings.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.nav_settings.ForeColor = System.Drawing.Color.Gray
        Me.nav_settings.Image = CType(resources.GetObject("nav_settings.Image"), System.Drawing.Image)
        Me.nav_settings.ImageSize = New System.Drawing.Size(20, 20)
        Me.nav_settings.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.nav_settings.LineLeft = 3
        Me.nav_settings.Location = New System.Drawing.Point(0, 53)
        Me.nav_settings.Name = "nav_settings"
        Me.nav_settings.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.nav_settings.OnHoverBorderColor = System.Drawing.Color.Black
        Me.nav_settings.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.nav_settings.OnHoverImage = CType(resources.GetObject("nav_settings.OnHoverImage"), System.Drawing.Image)
        Me.nav_settings.OnHoverLineColor = System.Drawing.Color.WhiteSmoke
        Me.nav_settings.OnPressedColor = System.Drawing.Color.Black
        Me.nav_settings.OnPressedDepth = 0
        Me.nav_settings.Size = New System.Drawing.Size(193, 41)
        Me.nav_settings.TabIndex = 4
        Me.nav_settings.Text = "Αρχική "
        Me.nav_settings.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.nav_settings.Visible = False
        '
        'GunaAdvenceButton7
        '
        Me.GunaAdvenceButton7.Animated = True
        Me.GunaAdvenceButton7.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton7.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton7.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.GunaAdvenceButton7.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton7.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton7.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceButton7.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton7.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton7.CheckedForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton7.CheckedImage = CType(resources.GetObject("GunaAdvenceButton7.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton7.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceButton7, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceButton7, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceButton7.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton7.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton7.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.GunaAdvenceButton7.ForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton7.Image = CType(resources.GetObject("GunaAdvenceButton7.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton7.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton7.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton7.LineLeft = 3
        Me.GunaAdvenceButton7.Location = New System.Drawing.Point(0, 347)
        Me.GunaAdvenceButton7.Name = "GunaAdvenceButton7"
        Me.GunaAdvenceButton7.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton7.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton7.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton7.OnHoverImage = CType(resources.GetObject("GunaAdvenceButton7.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceButton7.OnHoverLineColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton7.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton7.OnPressedDepth = 0
        Me.GunaAdvenceButton7.Size = New System.Drawing.Size(193, 41)
        Me.GunaAdvenceButton7.TabIndex = 44
        Me.GunaAdvenceButton7.Text = "Επικοινωνία"
        Me.GunaAdvenceButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton7.Visible = False
        '
        'GunaAdvenceTileButton9
        '
        Me.GunaAdvenceTileButton9.Animated = True
        Me.GunaAdvenceTileButton9.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton9.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton9.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton9.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton9.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton9.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton9.CheckedForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton9.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton9.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton9.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceTileButton9, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceTileButton9, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceTileButton9.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton9.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton9.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GunaAdvenceTileButton9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GunaAdvenceTileButton9.Image = CType(resources.GetObject("GunaAdvenceTileButton9.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton9.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceTileButton9.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton9.LineLeft = 3
        Me.GunaAdvenceTileButton9.Location = New System.Drawing.Point(-1, 666)
        Me.GunaAdvenceTileButton9.Name = "GunaAdvenceTileButton9"
        Me.GunaAdvenceTileButton9.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton9.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton9.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton9.OnHoverImage = CType(resources.GetObject("GunaAdvenceTileButton9.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton9.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton9.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton9.Size = New System.Drawing.Size(81, 54)
        Me.GunaAdvenceTileButton9.TabIndex = 99
        Me.GunaAdvenceTileButton9.Text = "Αποσύνδεση"
        '
        'GunaAdvenceButton6
        '
        Me.GunaAdvenceButton6.Animated = True
        Me.GunaAdvenceButton6.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton6.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton6.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.GunaAdvenceButton6.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton6.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton6.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceButton6.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton6.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton6.CheckedForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton6.CheckedImage = CType(resources.GetObject("GunaAdvenceButton6.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton6.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceButton6, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceButton6, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceButton6.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton6.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.GunaAdvenceButton6.ForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton6.Image = CType(resources.GetObject("GunaAdvenceButton6.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton6.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton6.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton6.LineLeft = 3
        Me.GunaAdvenceButton6.Location = New System.Drawing.Point(0, 291)
        Me.GunaAdvenceButton6.Name = "GunaAdvenceButton6"
        Me.GunaAdvenceButton6.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton6.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton6.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton6.OnHoverImage = CType(resources.GetObject("GunaAdvenceButton6.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceButton6.OnHoverLineColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton6.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton6.OnPressedDepth = 0
        Me.GunaAdvenceButton6.Size = New System.Drawing.Size(193, 41)
        Me.GunaAdvenceButton6.TabIndex = 42
        Me.GunaAdvenceButton6.Text = "Μαθήματα"
        Me.GunaAdvenceButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton6.Visible = False
        '
        'GunaAdvenceTileButton5
        '
        Me.GunaAdvenceTileButton5.Animated = True
        Me.GunaAdvenceTileButton5.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton5.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton5.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton5.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton5.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton5.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton5.CheckedForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton5.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton5.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton5.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceTileButton5, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceTileButton5, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceTileButton5.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton5.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton5.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GunaAdvenceTileButton5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GunaAdvenceTileButton5.Image = CType(resources.GetObject("GunaAdvenceTileButton5.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton5.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceTileButton5.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton5.LineLeft = 3
        Me.GunaAdvenceTileButton5.Location = New System.Drawing.Point(-1, 608)
        Me.GunaAdvenceTileButton5.Name = "GunaAdvenceTileButton5"
        Me.GunaAdvenceTileButton5.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton5.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton5.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton5.OnHoverImage = CType(resources.GetObject("GunaAdvenceTileButton5.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton5.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton5.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton5.Size = New System.Drawing.Size(81, 54)
        Me.GunaAdvenceTileButton5.TabIndex = 97
        Me.GunaAdvenceTileButton5.Text = "About"
        '
        'GunaAdvenceButton5
        '
        Me.GunaAdvenceButton5.Animated = True
        Me.GunaAdvenceButton5.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton5.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton5.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.GunaAdvenceButton5.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton5.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton5.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceButton5.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton5.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton5.CheckedForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton5.CheckedImage = CType(resources.GetObject("GunaAdvenceButton5.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton5.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceButton5, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceButton5, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceButton5.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton5.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.GunaAdvenceButton5.ForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton5.Image = CType(resources.GetObject("GunaAdvenceButton5.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton5.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton5.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton5.LineLeft = 3
        Me.GunaAdvenceButton5.Location = New System.Drawing.Point(0, 241)
        Me.GunaAdvenceButton5.Name = "GunaAdvenceButton5"
        Me.GunaAdvenceButton5.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton5.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton5.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton5.OnHoverImage = CType(resources.GetObject("GunaAdvenceButton5.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceButton5.OnHoverLineColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton5.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton5.OnPressedDepth = 0
        Me.GunaAdvenceButton5.Size = New System.Drawing.Size(193, 41)
        Me.GunaAdvenceButton5.TabIndex = 41
        Me.GunaAdvenceButton5.Text = "Ρυθμίσεις"
        Me.GunaAdvenceButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton5.Visible = False
        '
        'GunaButton22
        '
        Me.GunaButton22.Animated = True
        Me.GunaButton22.AnimationHoverSpeed = 0.07!
        Me.GunaButton22.AnimationSpeed = 0.03!
        Me.GunaButton22.BackColor = System.Drawing.Color.Turquoise
        Me.GunaButton22.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaButton22.BorderColor = System.Drawing.Color.Transparent
        Me.GunaButton22.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaButton22, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaButton22, Guna.UI.Animation.DecorationType.None)
        Me.GunaButton22.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton22.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton22.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaButton22.ForeColor = System.Drawing.Color.Gray
        Me.GunaButton22.Image = CType(resources.GetObject("GunaButton22.Image"), System.Drawing.Image)
        Me.GunaButton22.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton22.Location = New System.Drawing.Point(151, 3)
        Me.GunaButton22.Name = "GunaButton22"
        Me.GunaButton22.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaButton22.OnHoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(87, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.GunaButton22.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaButton22.OnHoverImage = CType(resources.GetObject("GunaButton22.OnHoverImage"), System.Drawing.Image)
        Me.GunaButton22.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton22.Size = New System.Drawing.Size(42, 44)
        Me.GunaButton22.TabIndex = 43
        Me.GunaButton22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaAdvenceButton1
        '
        Me.GunaAdvenceButton1.Animated = True
        Me.GunaAdvenceButton1.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton1.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.GunaAdvenceButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceButton1.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton1.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton1.CheckedImage = CType(resources.GetObject("GunaAdvenceButton1.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton1.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceButton1, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceButton1, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.GunaAdvenceButton1.ForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton1.Image = CType(resources.GetObject("GunaAdvenceButton1.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton1.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton1.LineLeft = 3
        Me.GunaAdvenceButton1.Location = New System.Drawing.Point(0, 100)
        Me.GunaAdvenceButton1.Name = "GunaAdvenceButton1"
        Me.GunaAdvenceButton1.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton1.OnHoverImage = CType(resources.GetObject("GunaAdvenceButton1.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceButton1.OnHoverLineColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.OnPressedDepth = 0
        Me.GunaAdvenceButton1.Size = New System.Drawing.Size(193, 41)
        Me.GunaAdvenceButton1.TabIndex = 38
        Me.GunaAdvenceButton1.Text = "Ημερολόγιο"
        Me.GunaAdvenceButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton1.Visible = False
        '
        'GunaAdvenceButton4
        '
        Me.GunaAdvenceButton4.Animated = True
        Me.GunaAdvenceButton4.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton4.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton4.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.GunaAdvenceButton4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton4.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceButton4.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton4.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.CheckedForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton4.CheckedImage = CType(resources.GetObject("GunaAdvenceButton4.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton4.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceButton4, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceButton4, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceButton4.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton4.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.GunaAdvenceButton4.ForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton4.Image = CType(resources.GetObject("GunaAdvenceButton4.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton4.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton4.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton4.LineLeft = 3
        Me.GunaAdvenceButton4.Location = New System.Drawing.Point(0, 194)
        Me.GunaAdvenceButton4.Name = "GunaAdvenceButton4"
        Me.GunaAdvenceButton4.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton4.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton4.OnHoverImage = CType(resources.GetObject("GunaAdvenceButton4.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceButton4.OnHoverLineColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton4.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.OnPressedDepth = 0
        Me.GunaAdvenceButton4.Size = New System.Drawing.Size(193, 41)
        Me.GunaAdvenceButton4.TabIndex = 40
        Me.GunaAdvenceButton4.Text = "Αγαπημένα"
        Me.GunaAdvenceButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton4.Visible = False
        '
        'GunaAdvenceTileButton7
        '
        Me.GunaAdvenceTileButton7.Animated = True
        Me.GunaAdvenceTileButton7.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton7.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton7.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton7.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton7.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceTileButton7.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton7.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton7.CheckedForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton7.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton7.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton7.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceTileButton7, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceTileButton7, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceTileButton7.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton7.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton7.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GunaAdvenceTileButton7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GunaAdvenceTileButton7.Image = CType(resources.GetObject("GunaAdvenceTileButton7.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton7.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceTileButton7.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton7.LineLeft = 4
        Me.GunaAdvenceTileButton7.Location = New System.Drawing.Point(-1, 295)
        Me.GunaAdvenceTileButton7.Name = "GunaAdvenceTileButton7"
        Me.GunaAdvenceTileButton7.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton7.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton7.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton7.OnHoverImage = CType(resources.GetObject("GunaAdvenceTileButton7.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton7.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton7.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton7.Size = New System.Drawing.Size(81, 54)
        Me.GunaAdvenceTileButton7.TabIndex = 95
        Me.GunaAdvenceTileButton7.Text = "Ρυθμίσεις"
        '
        'GunaAdvenceButton3
        '
        Me.GunaAdvenceButton3.Animated = True
        Me.GunaAdvenceButton3.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton3.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(68, Byte), Integer))
        Me.GunaAdvenceButton3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton3.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceButton3.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton3.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.CheckedForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton3.CheckedImage = CType(resources.GetObject("GunaAdvenceButton3.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton3.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceButton3, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceButton3, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceButton3.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.GunaAdvenceButton3.ForeColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton3.Image = CType(resources.GetObject("GunaAdvenceButton3.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton3.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton3.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceButton3.LineLeft = 3
        Me.GunaAdvenceButton3.Location = New System.Drawing.Point(0, 147)
        Me.GunaAdvenceButton3.Name = "GunaAdvenceButton3"
        Me.GunaAdvenceButton3.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton3.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceButton3.OnHoverImage = CType(resources.GetObject("GunaAdvenceButton3.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceButton3.OnHoverLineColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton3.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.OnPressedDepth = 0
        Me.GunaAdvenceButton3.Size = New System.Drawing.Size(193, 41)
        Me.GunaAdvenceButton3.TabIndex = 39
        Me.GunaAdvenceButton3.Text = "Εφαρμογές"
        Me.GunaAdvenceButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaAdvenceButton3.Visible = False
        '
        'GunaAdvenceTileButton8
        '
        Me.GunaAdvenceTileButton8.Animated = True
        Me.GunaAdvenceTileButton8.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton8.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton8.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton8.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton8.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceTileButton8.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton8.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton8.CheckedForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton8.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton8.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton8.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceTileButton8, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceTileButton8, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceTileButton8.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton8.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton8.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GunaAdvenceTileButton8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GunaAdvenceTileButton8.Image = CType(resources.GetObject("GunaAdvenceTileButton8.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton8.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceTileButton8.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton8.LineLeft = 4
        Me.GunaAdvenceTileButton8.Location = New System.Drawing.Point(-1, 415)
        Me.GunaAdvenceTileButton8.Name = "GunaAdvenceTileButton8"
        Me.GunaAdvenceTileButton8.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton8.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton8.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton8.OnHoverImage = CType(resources.GetObject("GunaAdvenceTileButton8.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton8.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton8.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton8.Size = New System.Drawing.Size(81, 54)
        Me.GunaAdvenceTileButton8.TabIndex = 96
        Me.GunaAdvenceTileButton8.Text = "Επικοινωνία"
        '
        'GunaAdvenceTileButton3
        '
        Me.GunaAdvenceTileButton3.Animated = True
        Me.GunaAdvenceTileButton3.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton3.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton3.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton3.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceTileButton3.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton3.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton3.CheckedForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton3.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton3.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton3.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceTileButton3, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceTileButton3, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceTileButton3.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton3.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GunaAdvenceTileButton3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GunaAdvenceTileButton3.Image = CType(resources.GetObject("GunaAdvenceTileButton3.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton3.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceTileButton3.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton3.LineLeft = 4
        Me.GunaAdvenceTileButton3.Location = New System.Drawing.Point(-1, 355)
        Me.GunaAdvenceTileButton3.Name = "GunaAdvenceTileButton3"
        Me.GunaAdvenceTileButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton3.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton3.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton3.OnHoverImage = CType(resources.GetObject("GunaAdvenceTileButton3.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton3.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton3.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton3.Size = New System.Drawing.Size(81, 54)
        Me.GunaAdvenceTileButton3.TabIndex = 93
        Me.GunaAdvenceTileButton3.Text = "Μαθήματα"
        '
        'GunaAdvenceTileButton4
        '
        Me.GunaAdvenceTileButton4.Animated = True
        Me.GunaAdvenceTileButton4.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton4.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton4.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton4.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceTileButton4.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton4.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton4.CheckedForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton4.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton4.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton4.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceTileButton4, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceTileButton4, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceTileButton4.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton4.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton4.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GunaAdvenceTileButton4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GunaAdvenceTileButton4.Image = CType(resources.GetObject("GunaAdvenceTileButton4.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton4.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceTileButton4.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton4.LineLeft = 4
        Me.GunaAdvenceTileButton4.Location = New System.Drawing.Point(-1, 235)
        Me.GunaAdvenceTileButton4.Name = "GunaAdvenceTileButton4"
        Me.GunaAdvenceTileButton4.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton4.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton4.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton4.OnHoverImage = CType(resources.GetObject("GunaAdvenceTileButton4.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton4.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton4.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton4.Size = New System.Drawing.Size(81, 54)
        Me.GunaAdvenceTileButton4.TabIndex = 94
        Me.GunaAdvenceTileButton4.Text = "Αγαπημένα"
        '
        'GunaAdvenceTileButton1
        '
        Me.GunaAdvenceTileButton1.Animated = True
        Me.GunaAdvenceTileButton1.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton1.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton1.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceTileButton1.Checked = True
        Me.GunaAdvenceTileButton1.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton1.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton1.CheckedForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton1.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton1.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton1.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceTileButton1, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceTileButton1, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceTileButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GunaAdvenceTileButton1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GunaAdvenceTileButton1.Image = CType(resources.GetObject("GunaAdvenceTileButton1.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceTileButton1.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton1.LineLeft = 4
        Me.GunaAdvenceTileButton1.Location = New System.Drawing.Point(-1, 55)
        Me.GunaAdvenceTileButton1.Name = "GunaAdvenceTileButton1"
        Me.GunaAdvenceTileButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton1.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton1.OnHoverImage = CType(resources.GetObject("GunaAdvenceTileButton1.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton1.Size = New System.Drawing.Size(81, 54)
        Me.GunaAdvenceTileButton1.TabIndex = 91
        Me.GunaAdvenceTileButton1.Text = "Αρχική"
        '
        'GunaAdvenceTileButton2
        '
        Me.GunaAdvenceTileButton2.Animated = True
        Me.GunaAdvenceTileButton2.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton2.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton2.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton2.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceTileButton2.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton2.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton2.CheckedForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton2.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton2.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton2.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceTileButton2, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceTileButton2, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceTileButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GunaAdvenceTileButton2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GunaAdvenceTileButton2.Image = CType(resources.GetObject("GunaAdvenceTileButton2.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton2.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceTileButton2.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton2.LineLeft = 4
        Me.GunaAdvenceTileButton2.Location = New System.Drawing.Point(-1, 115)
        Me.GunaAdvenceTileButton2.Name = "GunaAdvenceTileButton2"
        Me.GunaAdvenceTileButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton2.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton2.OnHoverImage = CType(resources.GetObject("GunaAdvenceTileButton2.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton2.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton2.Size = New System.Drawing.Size(81, 54)
        Me.GunaAdvenceTileButton2.TabIndex = 92
        Me.GunaAdvenceTileButton2.Text = "Ημερολογιο"
        '
        'GunaButton31
        '
        Me.GunaButton31.Animated = True
        Me.GunaButton31.AnimationHoverSpeed = 0.07!
        Me.GunaButton31.AnimationSpeed = 0.03!
        Me.GunaButton31.BackColor = System.Drawing.Color.Turquoise
        Me.GunaButton31.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaButton31.BorderColor = System.Drawing.Color.Transparent
        Me.GunaButton31.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaButton31, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaButton31, Guna.UI.Animation.DecorationType.None)
        Me.GunaButton31.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton31.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton31.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaButton31.ForeColor = System.Drawing.Color.Gray
        Me.GunaButton31.Image = CType(resources.GetObject("GunaButton31.Image"), System.Drawing.Image)
        Me.GunaButton31.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton31.Location = New System.Drawing.Point(-1, 677)
        Me.GunaButton31.Name = "GunaButton31"
        Me.GunaButton31.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaButton31.OnHoverBorderColor = System.Drawing.Color.WhiteSmoke
        Me.GunaButton31.OnHoverForeColor = System.Drawing.Color.Gray
        Me.GunaButton31.OnHoverImage = CType(resources.GetObject("GunaButton31.OnHoverImage"), System.Drawing.Image)
        Me.GunaButton31.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton31.Size = New System.Drawing.Size(196, 41)
        Me.GunaButton31.TabIndex = 37
        Me.GunaButton31.Text = "Αποσύνδεση Χρήστη"
        Me.GunaButton31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaButton31.Visible = False
        '
        'GunaButton23
        '
        Me.GunaButton23.Animated = True
        Me.GunaButton23.AnimationHoverSpeed = 0.07!
        Me.GunaButton23.AnimationSpeed = 0.03!
        Me.GunaButton23.BackColor = System.Drawing.Color.Turquoise
        Me.GunaButton23.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaButton23.BorderColor = System.Drawing.Color.Transparent
        Me.GunaButton23.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaButton23, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaButton23, Guna.UI.Animation.DecorationType.None)
        Me.GunaButton23.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton23.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton23.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaButton23.ForeColor = System.Drawing.Color.Gray
        Me.GunaButton23.Image = CType(resources.GetObject("GunaButton23.Image"), System.Drawing.Image)
        Me.GunaButton23.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton23.Location = New System.Drawing.Point(0, 3)
        Me.GunaButton23.Name = "GunaButton23"
        Me.GunaButton23.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaButton23.OnHoverBorderColor = System.Drawing.Color.FromArgb(CType(CType(253, Byte), Integer), CType(CType(87, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.GunaButton23.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaButton23.OnHoverImage = CType(resources.GetObject("GunaButton23.OnHoverImage"), System.Drawing.Image)
        Me.GunaButton23.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton23.Size = New System.Drawing.Size(42, 44)
        Me.GunaButton23.TabIndex = 35
        Me.GunaButton23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GunaButton27
        '
        Me.GunaButton27.Animated = True
        Me.GunaButton27.AnimationHoverSpeed = 0.07!
        Me.GunaButton27.AnimationSpeed = 0.03!
        Me.GunaButton27.BackColor = System.Drawing.Color.Turquoise
        Me.GunaButton27.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaButton27.BorderColor = System.Drawing.Color.Transparent
        Me.GunaButton27.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaButton27, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaButton27, Guna.UI.Animation.DecorationType.None)
        Me.GunaButton27.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton27.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton27.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaButton27.ForeColor = System.Drawing.Color.Gray
        Me.GunaButton27.Image = CType(resources.GetObject("GunaButton27.Image"), System.Drawing.Image)
        Me.GunaButton27.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton27.Location = New System.Drawing.Point(-1, 633)
        Me.GunaButton27.Name = "GunaButton27"
        Me.GunaButton27.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaButton27.OnHoverBorderColor = System.Drawing.Color.WhiteSmoke
        Me.GunaButton27.OnHoverForeColor = System.Drawing.Color.Gray
        Me.GunaButton27.OnHoverImage = CType(resources.GetObject("GunaButton27.OnHoverImage"), System.Drawing.Image)
        Me.GunaButton27.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton27.Size = New System.Drawing.Size(196, 41)
        Me.GunaButton27.TabIndex = 30
        Me.GunaButton27.Text = "About"
        Me.GunaButton27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.GunaButton27.Visible = False
        '
        'GunaAdvenceTileButton6
        '
        Me.GunaAdvenceTileButton6.Animated = True
        Me.GunaAdvenceTileButton6.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton6.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton6.BaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton6.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton6.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton
        Me.GunaAdvenceTileButton6.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton6.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton6.CheckedForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton6.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton6.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton6.CheckedLineColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaTransition2.SetDecoration(Me.GunaAdvenceTileButton6, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me.GunaAdvenceTileButton6, Guna.UI.Animation.DecorationType.None)
        Me.GunaAdvenceTileButton6.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton6.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton6.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GunaAdvenceTileButton6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GunaAdvenceTileButton6.Image = CType(resources.GetObject("GunaAdvenceTileButton6.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton6.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceTileButton6.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaAdvenceTileButton6.LineLeft = 4
        Me.GunaAdvenceTileButton6.Location = New System.Drawing.Point(0, 175)
        Me.GunaAdvenceTileButton6.Name = "GunaAdvenceTileButton6"
        Me.GunaAdvenceTileButton6.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton6.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton6.OnHoverForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.GunaAdvenceTileButton6.OnHoverImage = CType(resources.GetObject("GunaAdvenceTileButton6.OnHoverImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton6.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer), CType(CType(242, Byte), Integer))
        Me.GunaAdvenceTileButton6.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton6.Size = New System.Drawing.Size(81, 54)
        Me.GunaAdvenceTileButton6.TabIndex = 98
        Me.GunaAdvenceTileButton6.Text = "Εφαρμογές"
        '
        'Timer1
        '
        Me.Timer1.Interval = 2
        '
        'Timer2
        '
        Me.Timer2.Interval = 2
        '
        'Timer3
        '
        Me.Timer3.Interval = 5000
        '
        'GunaTransition2
        '
        Me.GunaTransition2.AnimationType = Guna.UI.Animation.AnimationType.HorizSlide
        Me.GunaTransition2.Cursor = Nothing
        Animation1.AnimateOnlyDifferences = True
        Animation1.BlindCoeff = CType(resources.GetObject("Animation1.BlindCoeff"), System.Drawing.PointF)
        Animation1.LeafCoeff = 0!
        Animation1.MaxTime = 1.0!
        Animation1.MinTime = 0!
        Animation1.MosaicCoeff = CType(resources.GetObject("Animation1.MosaicCoeff"), System.Drawing.PointF)
        Animation1.MosaicShift = CType(resources.GetObject("Animation1.MosaicShift"), System.Drawing.PointF)
        Animation1.MosaicSize = 0
        Animation1.Padding = New System.Windows.Forms.Padding(0)
        Animation1.RotateCoeff = 0!
        Animation1.RotateLimit = 0!
        Animation1.ScaleCoeff = CType(resources.GetObject("Animation1.ScaleCoeff"), System.Drawing.PointF)
        Animation1.SlideCoeff = CType(resources.GetObject("Animation1.SlideCoeff"), System.Drawing.PointF)
        Animation1.TimeCoeff = 0!
        Animation1.TransparencyCoeff = 0!
        Me.GunaTransition2.DefaultAnimation = Animation1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(1357, 768)
        Me.Controls.Add(Me.GunaPanel8)
        Me.Controls.Add(Me.GunaPanel2)
        Me.Controls.Add(Me.Panel1)
        Me.GunaTransition2.SetDecoration(Me, Guna.UI.Animation.DecorationType.None)
        Me.GunaTransition1.SetDecoration(Me, Guna.UI.Animation.DecorationType.None)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GunaPanel2.ResumeLayout(False)
        Me.GunaPanel2.PerformLayout()
        CType(Me.GunaPictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GunaPictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GunaPictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GunaPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GunaPanel8.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GridControl1 As Syncfusion.Windows.Forms.Grid.GridControl
    Friend WithEvents GunaPanel2 As Guna.UI.WinForms.GunaPanel
    Friend WithEvents GunaControlBox3 As Guna.UI.WinForms.GunaControlBox
    Friend WithEvents GunaControlBox2 As Guna.UI.WinForms.GunaControlBox
    Friend WithEvents GunaControlBox1 As Guna.UI.WinForms.GunaControlBox
    Friend WithEvents GunaTransition1 As Guna.UI.WinForms.GunaTransition
    Friend WithEvents Panel1 As Panel
    Friend WithEvents GunaPanel8 As Guna.UI.WinForms.GunaPanel
    Friend WithEvents GunaButton22 As Guna.UI.WinForms.GunaButton
    Friend WithEvents GunaAdvenceButton6 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaAdvenceButton5 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaAdvenceButton4 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaAdvenceButton3 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaAdvenceButton1 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents nav_settings As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaButton31 As Guna.UI.WinForms.GunaButton
    Friend WithEvents GunaButton23 As Guna.UI.WinForms.GunaButton
    Friend WithEvents GunaButton27 As Guna.UI.WinForms.GunaButton
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents GunaAdvenceButton7 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaPictureBox3 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents GunaPictureBox1 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents GunaPictureBox2 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents GunaAdvenceTileButton9 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton5 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton6 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton7 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton8 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton3 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton4 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton1 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaAdvenceTileButton2 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaCircleProgressBar7 As Guna.UI.WinForms.GunaCircleProgressBar
    Friend WithEvents GunaPictureBox4 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents Timer3 As Timer
    Friend WithEvents GunaTransition2 As Guna.UI.WinForms.GunaTransition
End Class
