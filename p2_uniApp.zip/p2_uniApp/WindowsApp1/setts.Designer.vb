﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class setts
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(setts))
        Me.GunaPanel16 = New Guna.UI.WinForms.GunaPanel()
        Me.GunaButton8 = New Guna.UI.WinForms.GunaButton()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GunaPictureBox3 = New Guna.UI.WinForms.GunaPictureBox()
        Me.GunaShadowPanel4 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.GunaWinSwitch4 = New Guna.UI.WinForms.GunaWinSwitch()
        Me.GunaComboBox1 = New Guna.UI.WinForms.GunaComboBox()
        Me.GunaSeparator5 = New Guna.UI.WinForms.GunaSeparator()
        Me.GunaSeparator4 = New Guna.UI.WinForms.GunaSeparator()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GunaWinSwitch3 = New Guna.UI.WinForms.GunaWinSwitch()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GunaWinSwitch2 = New Guna.UI.WinForms.GunaWinSwitch()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GunaSeparator2 = New Guna.UI.WinForms.GunaSeparator()
        Me.GunaWinSwitch1 = New Guna.UI.WinForms.GunaWinSwitch()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.GunaShadowPanel1 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.GunaWinSwitch7 = New Guna.UI.WinForms.GunaWinSwitch()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.GunaSeparator7 = New Guna.UI.WinForms.GunaSeparator()
        Me.GunaAdvenceButton1 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.GunaSeparator6 = New Guna.UI.WinForms.GunaSeparator()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GunaWinSwitch6 = New Guna.UI.WinForms.GunaWinSwitch()
        Me.GunaAdvenceButton3 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GunaWinSwitch5 = New Guna.UI.WinForms.GunaWinSwitch()
        Me.GunaSeparator1 = New Guna.UI.WinForms.GunaSeparator()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GunaShadowPanel5 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.GunaAdvenceTileButton1 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaVSeparator1 = New Guna.UI.WinForms.GunaVSeparator()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.GunaAdvenceTileButton10 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaSeparator8 = New Guna.UI.WinForms.GunaSeparator()
        Me.GunaLineTextBox1 = New Guna.UI.WinForms.GunaLineTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GunaWinSwitch8 = New Guna.UI.WinForms.GunaWinSwitch()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.GunaWinSwitch10 = New Guna.UI.WinForms.GunaWinSwitch()
        Me.GunaSeparator3 = New Guna.UI.WinForms.GunaSeparator()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GradientPanel1 = New Syncfusion.Windows.Forms.Tools.GradientPanel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GunaPanel16.SuspendLayout()
        CType(Me.GunaPictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GunaShadowPanel4.SuspendLayout()
        Me.GunaShadowPanel1.SuspendLayout()
        Me.GunaShadowPanel5.SuspendLayout()
        CType(Me.GradientPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GradientPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GunaPanel16
        '
        Me.GunaPanel16.BackColor = System.Drawing.Color.White
        Me.GunaPanel16.Controls.Add(Me.GunaButton8)
        Me.GunaPanel16.Controls.Add(Me.Label13)
        Me.GunaPanel16.Controls.Add(Me.GunaPictureBox3)
        Me.GunaPanel16.Dock = System.Windows.Forms.DockStyle.Top
        Me.GunaPanel16.Location = New System.Drawing.Point(0, 0)
        Me.GunaPanel16.Name = "GunaPanel16"
        Me.GunaPanel16.Size = New System.Drawing.Size(1279, 60)
        Me.GunaPanel16.TabIndex = 134
        '
        'GunaButton8
        '
        Me.GunaButton8.AnimationHoverSpeed = 0.07!
        Me.GunaButton8.AnimationSpeed = 0.03!
        Me.GunaButton8.BackColor = System.Drawing.Color.Transparent
        Me.GunaButton8.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.GunaButton8.BorderColor = System.Drawing.Color.Black
        Me.GunaButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaButton8.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaButton8.FocusedColor = System.Drawing.Color.Empty
        Me.GunaButton8.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaButton8.ForeColor = System.Drawing.Color.White
        Me.GunaButton8.Image = CType(resources.GetObject("GunaButton8.Image"), System.Drawing.Image)
        Me.GunaButton8.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaButton8.Location = New System.Drawing.Point(1217, 14)
        Me.GunaButton8.Name = "GunaButton8"
        Me.GunaButton8.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.GunaButton8.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaButton8.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaButton8.OnHoverImage = Nothing
        Me.GunaButton8.OnPressedColor = System.Drawing.Color.Black
        Me.GunaButton8.Radius = 4
        Me.GunaButton8.Size = New System.Drawing.Size(39, 32)
        Me.GunaButton8.TabIndex = 47
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(80, Byte), Integer), CType(CType(108, Byte), Integer))
        Me.Label13.Location = New System.Drawing.Point(84, 14)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(241, 25)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Ρυθμίσεις Εφαρμογής"
        '
        'GunaPictureBox3
        '
        Me.GunaPictureBox3.BackgroundImage = CType(resources.GetObject("GunaPictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.GunaPictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GunaPictureBox3.BaseColor = System.Drawing.Color.White
        Me.GunaPictureBox3.Location = New System.Drawing.Point(18, 7)
        Me.GunaPictureBox3.Name = "GunaPictureBox3"
        Me.GunaPictureBox3.Size = New System.Drawing.Size(40, 43)
        Me.GunaPictureBox3.TabIndex = 8
        Me.GunaPictureBox3.TabStop = False
        '
        'GunaShadowPanel4
        '
        Me.GunaShadowPanel4.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel4.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel4.Controls.Add(Me.Label22)
        Me.GunaShadowPanel4.Controls.Add(Me.Label15)
        Me.GunaShadowPanel4.Controls.Add(Me.Label14)
        Me.GunaShadowPanel4.Controls.Add(Me.Label12)
        Me.GunaShadowPanel4.Controls.Add(Me.GunaWinSwitch4)
        Me.GunaShadowPanel4.Controls.Add(Me.GunaComboBox1)
        Me.GunaShadowPanel4.Controls.Add(Me.GunaSeparator5)
        Me.GunaShadowPanel4.Controls.Add(Me.GunaSeparator4)
        Me.GunaShadowPanel4.Controls.Add(Me.Label11)
        Me.GunaShadowPanel4.Controls.Add(Me.Label10)
        Me.GunaShadowPanel4.Controls.Add(Me.GunaWinSwitch3)
        Me.GunaShadowPanel4.Controls.Add(Me.Label9)
        Me.GunaShadowPanel4.Controls.Add(Me.GunaWinSwitch2)
        Me.GunaShadowPanel4.Controls.Add(Me.Label3)
        Me.GunaShadowPanel4.Controls.Add(Me.GunaSeparator2)
        Me.GunaShadowPanel4.Controls.Add(Me.GunaWinSwitch1)
        Me.GunaShadowPanel4.Controls.Add(Me.Label34)
        Me.GunaShadowPanel4.Location = New System.Drawing.Point(43, 152)
        Me.GunaShadowPanel4.Name = "GunaShadowPanel4"
        Me.GunaShadowPanel4.Radius = 5
        Me.GunaShadowPanel4.ShadowColor = System.Drawing.Color.DimGray
        Me.GunaShadowPanel4.ShadowShift = 4
        Me.GunaShadowPanel4.Size = New System.Drawing.Size(332, 545)
        Me.GunaShadowPanel4.TabIndex = 135
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label22.Location = New System.Drawing.Point(33, 508)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(200, 15)
        Me.Label22.TabIndex = 154
        Me.Label22.Text = "*Διαθέσιμη Γλώσσα μόνο η ελληνική"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label15.Location = New System.Drawing.Point(182, 450)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(66, 20)
        Me.Label15.TabIndex = 153
        Me.Label15.Text = "Ανοικτό"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label14.Location = New System.Drawing.Point(49, 450)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(64, 20)
        Me.Label14.TabIndex = 152
        Me.Label14.Text = "Σκούρο"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label12.Location = New System.Drawing.Point(93, 405)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(116, 20)
        Me.Label12.TabIndex = 151
        Me.Label12.Text = "Θέμα Γραφικών"
        '
        'GunaWinSwitch4
        '
        Me.GunaWinSwitch4.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaWinSwitch4.Checked = True
        Me.GunaWinSwitch4.CheckedOffColor = System.Drawing.Color.DarkGray
        Me.GunaWinSwitch4.CheckedOnColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaWinSwitch4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaWinSwitch4.FillColor = System.Drawing.Color.White
        Me.GunaWinSwitch4.Location = New System.Drawing.Point(125, 450)
        Me.GunaWinSwitch4.Name = "GunaWinSwitch4"
        Me.GunaWinSwitch4.Size = New System.Drawing.Size(40, 22)
        Me.GunaWinSwitch4.TabIndex = 150
        '
        'GunaComboBox1
        '
        Me.GunaComboBox1.BackColor = System.Drawing.Color.Transparent
        Me.GunaComboBox1.BaseColor = System.Drawing.Color.White
        Me.GunaComboBox1.BorderColor = System.Drawing.Color.Silver
        Me.GunaComboBox1.DisplayMember = "0"
        Me.GunaComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.GunaComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.GunaComboBox1.Enabled = False
        Me.GunaComboBox1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaComboBox1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.GunaComboBox1.ForeColor = System.Drawing.Color.Black
        Me.GunaComboBox1.FormattingEnabled = True
        Me.GunaComboBox1.Items.AddRange(New Object() {"Ελληνικά (GRE)", "Αγγλικά (US)"})
        Me.GunaComboBox1.Location = New System.Drawing.Point(70, 343)
        Me.GunaComboBox1.Name = "GunaComboBox1"
        Me.GunaComboBox1.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaComboBox1.OnHoverItemForeColor = System.Drawing.Color.White
        Me.GunaComboBox1.Radius = 2
        Me.GunaComboBox1.Size = New System.Drawing.Size(176, 26)
        Me.GunaComboBox1.StartIndex = 0
        Me.GunaComboBox1.TabIndex = 149
        '
        'GunaSeparator5
        '
        Me.GunaSeparator5.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaSeparator5.Location = New System.Drawing.Point(37, 383)
        Me.GunaSeparator5.Name = "GunaSeparator5"
        Me.GunaSeparator5.Size = New System.Drawing.Size(245, 10)
        Me.GunaSeparator5.TabIndex = 148
        '
        'GunaSeparator4
        '
        Me.GunaSeparator4.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaSeparator4.Location = New System.Drawing.Point(37, 267)
        Me.GunaSeparator4.Name = "GunaSeparator4"
        Me.GunaSeparator4.Size = New System.Drawing.Size(245, 10)
        Me.GunaSeparator4.TabIndex = 146
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label11.Location = New System.Drawing.Point(93, 299)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(141, 20)
        Me.Label11.TabIndex = 145
        Me.Label11.Text = "Επιλογή Γλώσσας*"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(19, 210)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(164, 20)
        Me.Label10.TabIndex = 144
        Me.Label10.Text = "Κλείδωμα Παραθύρου"
        '
        'GunaWinSwitch3
        '
        Me.GunaWinSwitch3.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaWinSwitch3.CheckedOffColor = System.Drawing.Color.DarkGray
        Me.GunaWinSwitch3.CheckedOnColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaWinSwitch3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaWinSwitch3.Enabled = False
        Me.GunaWinSwitch3.FillColor = System.Drawing.Color.White
        Me.GunaWinSwitch3.Location = New System.Drawing.Point(242, 210)
        Me.GunaWinSwitch3.Name = "GunaWinSwitch3"
        Me.GunaWinSwitch3.Size = New System.Drawing.Size(40, 22)
        Me.GunaWinSwitch3.TabIndex = 143
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label9.Location = New System.Drawing.Point(19, 161)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(145, 20)
        Me.Label9.TabIndex = 142
        Me.Label9.Text = "Maximize Εμφάνιση"
        '
        'GunaWinSwitch2
        '
        Me.GunaWinSwitch2.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaWinSwitch2.CheckedOffColor = System.Drawing.Color.DarkGray
        Me.GunaWinSwitch2.CheckedOnColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaWinSwitch2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaWinSwitch2.FillColor = System.Drawing.Color.White
        Me.GunaWinSwitch2.Location = New System.Drawing.Point(242, 161)
        Me.GunaWinSwitch2.Name = "GunaWinSwitch2"
        Me.GunaWinSwitch2.Size = New System.Drawing.Size(40, 22)
        Me.GunaWinSwitch2.TabIndex = 141
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(19, 115)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(141, 20)
        Me.Label3.TabIndex = 140
        Me.Label3.Text = "Minimize Εμφάνιση"
        '
        'GunaSeparator2
        '
        Me.GunaSeparator2.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaSeparator2.Location = New System.Drawing.Point(37, 63)
        Me.GunaSeparator2.Name = "GunaSeparator2"
        Me.GunaSeparator2.Size = New System.Drawing.Size(245, 10)
        Me.GunaSeparator2.TabIndex = 139
        '
        'GunaWinSwitch1
        '
        Me.GunaWinSwitch1.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaWinSwitch1.CheckedOffColor = System.Drawing.Color.DarkGray
        Me.GunaWinSwitch1.CheckedOnColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaWinSwitch1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaWinSwitch1.FillColor = System.Drawing.Color.White
        Me.GunaWinSwitch1.Location = New System.Drawing.Point(242, 115)
        Me.GunaWinSwitch1.Name = "GunaWinSwitch1"
        Me.GunaWinSwitch1.Size = New System.Drawing.Size(40, 22)
        Me.GunaWinSwitch1.TabIndex = 62
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label34.Location = New System.Drawing.Point(66, 25)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(200, 24)
        Me.Label34.TabIndex = 59
        Me.Label34.Text = "Ρυθμίσεις Εφαρμογής"
        '
        'GunaShadowPanel1
        '
        Me.GunaShadowPanel1.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel1.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel1.Controls.Add(Me.Label18)
        Me.GunaShadowPanel1.Controls.Add(Me.GunaWinSwitch7)
        Me.GunaShadowPanel1.Controls.Add(Me.Label17)
        Me.GunaShadowPanel1.Controls.Add(Me.Label16)
        Me.GunaShadowPanel1.Controls.Add(Me.GunaSeparator7)
        Me.GunaShadowPanel1.Controls.Add(Me.GunaAdvenceButton1)
        Me.GunaShadowPanel1.Controls.Add(Me.GunaSeparator6)
        Me.GunaShadowPanel1.Controls.Add(Me.Label4)
        Me.GunaShadowPanel1.Controls.Add(Me.GunaWinSwitch6)
        Me.GunaShadowPanel1.Controls.Add(Me.GunaAdvenceButton3)
        Me.GunaShadowPanel1.Controls.Add(Me.Label2)
        Me.GunaShadowPanel1.Controls.Add(Me.GunaWinSwitch5)
        Me.GunaShadowPanel1.Controls.Add(Me.GunaSeparator1)
        Me.GunaShadowPanel1.Controls.Add(Me.Label1)
        Me.GunaShadowPanel1.Location = New System.Drawing.Point(454, 152)
        Me.GunaShadowPanel1.Name = "GunaShadowPanel1"
        Me.GunaShadowPanel1.Radius = 5
        Me.GunaShadowPanel1.ShadowColor = System.Drawing.Color.DimGray
        Me.GunaShadowPanel1.ShadowShift = 4
        Me.GunaShadowPanel1.Size = New System.Drawing.Size(332, 545)
        Me.GunaShadowPanel1.TabIndex = 136
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.Label18.Location = New System.Drawing.Point(47, 323)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(249, 20)
        Me.Label18.TabIndex = 156
        Me.Label18.Text = "(Δεν γίνεται ΚΑΙ αυτόματη λήψη)*"
        '
        'GunaWinSwitch7
        '
        Me.GunaWinSwitch7.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaWinSwitch7.CheckedOffColor = System.Drawing.Color.DarkGray
        Me.GunaWinSwitch7.CheckedOnColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaWinSwitch7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaWinSwitch7.FillColor = System.Drawing.Color.White
        Me.GunaWinSwitch7.Location = New System.Drawing.Point(149, 280)
        Me.GunaWinSwitch7.Name = "GunaWinSwitch7"
        Me.GunaWinSwitch7.Size = New System.Drawing.Size(40, 22)
        Me.GunaWinSwitch7.TabIndex = 155
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label17.Location = New System.Drawing.Point(68, 223)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(193, 40)
        Me.Label17.TabIndex = 154
        Me.Label17.Text = "     Αυτόματος έλεγχος " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "νέων Πακέτων Μαθημάτων"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label16.Location = New System.Drawing.Point(97, 394)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(135, 20)
        Me.Label16.TabIndex = 153
        Me.Label16.Text = "Διαγραφή Αρχείων"
        '
        'GunaSeparator7
        '
        Me.GunaSeparator7.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaSeparator7.Location = New System.Drawing.Point(41, 372)
        Me.GunaSeparator7.Name = "GunaSeparator7"
        Me.GunaSeparator7.Size = New System.Drawing.Size(245, 10)
        Me.GunaSeparator7.TabIndex = 152
        '
        'GunaAdvenceButton1
        '
        Me.GunaAdvenceButton1.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton1.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.GunaAdvenceButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton1.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.CheckedImage = CType(resources.GetObject("GunaAdvenceButton1.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton1.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaAdvenceButton1.ForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.Image = CType(resources.GetObject("GunaAdvenceButton1.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton1.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton1.Location = New System.Drawing.Point(41, 439)
        Me.GunaAdvenceButton1.Name = "GunaAdvenceButton1"
        Me.GunaAdvenceButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.GunaAdvenceButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.OnHoverImage = Nothing
        Me.GunaAdvenceButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.Radius = 3
        Me.GunaAdvenceButton1.Size = New System.Drawing.Size(255, 31)
        Me.GunaAdvenceButton1.TabIndex = 148
        Me.GunaAdvenceButton1.Text = "Διαγραφή Λίστα Αγαπημένων"
        '
        'GunaSeparator6
        '
        Me.GunaSeparator6.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaSeparator6.Location = New System.Drawing.Point(47, 210)
        Me.GunaSeparator6.Name = "GunaSeparator6"
        Me.GunaSeparator6.Size = New System.Drawing.Size(245, 10)
        Me.GunaSeparator6.TabIndex = 147
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(19, 163)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(230, 20)
        Me.Label4.TabIndex = 145
        Me.Label4.Text = "Απόκρυψη Προσωπικών Αρχείων"
        '
        'GunaWinSwitch6
        '
        Me.GunaWinSwitch6.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaWinSwitch6.CheckedOffColor = System.Drawing.Color.DarkGray
        Me.GunaWinSwitch6.CheckedOnColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaWinSwitch6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaWinSwitch6.FillColor = System.Drawing.Color.White
        Me.GunaWinSwitch6.Location = New System.Drawing.Point(252, 161)
        Me.GunaWinSwitch6.Name = "GunaWinSwitch6"
        Me.GunaWinSwitch6.Size = New System.Drawing.Size(40, 22)
        Me.GunaWinSwitch6.TabIndex = 144
        '
        'GunaAdvenceButton3
        '
        Me.GunaAdvenceButton3.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton3.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton3.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.GunaAdvenceButton3.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton3.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton3.CheckedImage = CType(resources.GetObject("GunaAdvenceButton3.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton3.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton3.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.GunaAdvenceButton3.ForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton3.Image = CType(resources.GetObject("GunaAdvenceButton3.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton3.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton3.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton3.Location = New System.Drawing.Point(41, 484)
        Me.GunaAdvenceButton3.Name = "GunaAdvenceButton3"
        Me.GunaAdvenceButton3.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(144, Byte), Integer))
        Me.GunaAdvenceButton3.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.OnHoverForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton3.OnHoverImage = Nothing
        Me.GunaAdvenceButton3.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton3.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.Radius = 3
        Me.GunaAdvenceButton3.Size = New System.Drawing.Size(255, 31)
        Me.GunaAdvenceButton3.TabIndex = 143
        Me.GunaAdvenceButton3.Text = "Διαγραφή όλων των Μαθημάτων"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(25, 115)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(140, 20)
        Me.Label2.TabIndex = 142
        Me.Label2.Text = "Απόκρυψη Βαθμών"
        '
        'GunaWinSwitch5
        '
        Me.GunaWinSwitch5.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaWinSwitch5.CheckedOffColor = System.Drawing.Color.DarkGray
        Me.GunaWinSwitch5.CheckedOnColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaWinSwitch5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaWinSwitch5.FillColor = System.Drawing.Color.White
        Me.GunaWinSwitch5.Location = New System.Drawing.Point(252, 115)
        Me.GunaWinSwitch5.Name = "GunaWinSwitch5"
        Me.GunaWinSwitch5.Size = New System.Drawing.Size(40, 22)
        Me.GunaWinSwitch5.TabIndex = 141
        '
        'GunaSeparator1
        '
        Me.GunaSeparator1.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaSeparator1.Location = New System.Drawing.Point(41, 63)
        Me.GunaSeparator1.Name = "GunaSeparator1"
        Me.GunaSeparator1.Size = New System.Drawing.Size(245, 10)
        Me.GunaSeparator1.TabIndex = 140
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(25, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(284, 24)
        Me.Label1.TabIndex = 59
        Me.Label1.Text = "Ρυθμίσεις Αρχείων Μαθημάτων"
        '
        'GunaShadowPanel5
        '
        Me.GunaShadowPanel5.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel5.BaseColor = System.Drawing.Color.White
        Me.GunaShadowPanel5.Controls.Add(Me.Label23)
        Me.GunaShadowPanel5.Controls.Add(Me.Label21)
        Me.GunaShadowPanel5.Controls.Add(Me.GunaAdvenceTileButton1)
        Me.GunaShadowPanel5.Controls.Add(Me.GunaVSeparator1)
        Me.GunaShadowPanel5.Controls.Add(Me.Label20)
        Me.GunaShadowPanel5.Controls.Add(Me.GunaAdvenceTileButton10)
        Me.GunaShadowPanel5.Controls.Add(Me.GunaSeparator8)
        Me.GunaShadowPanel5.Controls.Add(Me.GunaLineTextBox1)
        Me.GunaShadowPanel5.Controls.Add(Me.Label6)
        Me.GunaShadowPanel5.Controls.Add(Me.GunaWinSwitch8)
        Me.GunaShadowPanel5.Controls.Add(Me.Label7)
        Me.GunaShadowPanel5.Controls.Add(Me.Label19)
        Me.GunaShadowPanel5.Controls.Add(Me.GunaWinSwitch10)
        Me.GunaShadowPanel5.Controls.Add(Me.GunaSeparator3)
        Me.GunaShadowPanel5.Controls.Add(Me.Label5)
        Me.GunaShadowPanel5.Location = New System.Drawing.Point(854, 152)
        Me.GunaShadowPanel5.Name = "GunaShadowPanel5"
        Me.GunaShadowPanel5.Radius = 5
        Me.GunaShadowPanel5.ShadowColor = System.Drawing.Color.DimGray
        Me.GunaShadowPanel5.ShadowShift = 4
        Me.GunaShadowPanel5.Size = New System.Drawing.Size(332, 545)
        Me.GunaShadowPanel5.TabIndex = 137
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label23.Location = New System.Drawing.Point(37, 508)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(198, 15)
        Me.Label23.TabIndex = 158
        Me.Label23.Text = "*Μη Διαθέσιμοι Λογαριασμοί (Beta)"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label21.Location = New System.Drawing.Point(181, 389)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(124, 20)
        Me.Label21.TabIndex = 157
        Me.Label21.Text = "Απεγκατάσταση"
        '
        'GunaAdvenceTileButton1
        '
        Me.GunaAdvenceTileButton1.AllowDrop = True
        Me.GunaAdvenceTileButton1.Animated = True
        Me.GunaAdvenceTileButton1.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton1.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton1.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceTileButton1.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton1.BorderSize = 1
        Me.GunaAdvenceTileButton1.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton1.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton1.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton1.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton1.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton1.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton1.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton1.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton1.Image = CType(resources.GetObject("GunaAdvenceTileButton1.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton1.ImageSize = New System.Drawing.Size(50, 50)
        Me.GunaAdvenceTileButton1.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton1.Location = New System.Drawing.Point(215, 416)
        Me.GunaAdvenceTileButton1.Name = "GunaAdvenceTileButton1"
        Me.GunaAdvenceTileButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton1.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton1.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton1.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton1.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton1.Radius = 2
        Me.GunaAdvenceTileButton1.Size = New System.Drawing.Size(60, 56)
        Me.GunaAdvenceTileButton1.TabIndex = 156
        Me.GunaAdvenceTileButton1.TextImageOffsetY = 5
        '
        'GunaVSeparator1
        '
        Me.GunaVSeparator1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.GunaVSeparator1.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaVSeparator1.Location = New System.Drawing.Point(151, 383)
        Me.GunaVSeparator1.Name = "GunaVSeparator1"
        Me.GunaVSeparator1.Size = New System.Drawing.Size(10, 94)
        Me.GunaVSeparator1.TabIndex = 155
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label20.Location = New System.Drawing.Point(22, 389)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(89, 20)
        Me.Label20.TabIndex = 154
        Me.Label20.Text = "Ενημέρωση"
        '
        'GunaAdvenceTileButton10
        '
        Me.GunaAdvenceTileButton10.AllowDrop = True
        Me.GunaAdvenceTileButton10.Animated = True
        Me.GunaAdvenceTileButton10.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton10.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton10.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton10.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceTileButton10.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton10.BorderSize = 1
        Me.GunaAdvenceTileButton10.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton10.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton10.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton10.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton10.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton10.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton10.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton10.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton10.Font = New System.Drawing.Font("Segoe UI Light", 15.75!)
        Me.GunaAdvenceTileButton10.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton10.Image = CType(resources.GetObject("GunaAdvenceTileButton10.Image"), System.Drawing.Image)
        Me.GunaAdvenceTileButton10.ImageSize = New System.Drawing.Size(50, 50)
        Me.GunaAdvenceTileButton10.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton10.Location = New System.Drawing.Point(40, 416)
        Me.GunaAdvenceTileButton10.Name = "GunaAdvenceTileButton10"
        Me.GunaAdvenceTileButton10.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton10.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton10.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton10.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton10.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton10.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton10.Radius = 2
        Me.GunaAdvenceTileButton10.Size = New System.Drawing.Size(60, 56)
        Me.GunaAdvenceTileButton10.TabIndex = 153
        Me.GunaAdvenceTileButton10.TextImageOffsetY = 5
        '
        'GunaSeparator8
        '
        Me.GunaSeparator8.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaSeparator8.Location = New System.Drawing.Point(40, 372)
        Me.GunaSeparator8.Name = "GunaSeparator8"
        Me.GunaSeparator8.Size = New System.Drawing.Size(245, 10)
        Me.GunaSeparator8.TabIndex = 152
        '
        'GunaLineTextBox1
        '
        Me.GunaLineTextBox1.BackColor = System.Drawing.Color.White
        Me.GunaLineTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaLineTextBox1.FocusedLineColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaLineTextBox1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaLineTextBox1.ForeColor = System.Drawing.Color.Green
        Me.GunaLineTextBox1.LineColor = System.Drawing.Color.Gainsboro
        Me.GunaLineTextBox1.Location = New System.Drawing.Point(89, 313)
        Me.GunaLineTextBox1.Name = "GunaLineTextBox1"
        Me.GunaLineTextBox1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaLineTextBox1.ReadOnly = True
        Me.GunaLineTextBox1.Size = New System.Drawing.Size(160, 30)
        Me.GunaLineTextBox1.TabIndex = 151
        Me.GunaLineTextBox1.Text = "betatester"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(42, 165)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(187, 20)
        Me.Label6.TabIndex = 150
        Me.Label6.Text = "Αυτόματες Ενημερώσεις"
        '
        'GunaWinSwitch8
        '
        Me.GunaWinSwitch8.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaWinSwitch8.CheckedOffColor = System.Drawing.Color.DarkGray
        Me.GunaWinSwitch8.CheckedOnColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaWinSwitch8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaWinSwitch8.Enabled = False
        Me.GunaWinSwitch8.FillColor = System.Drawing.Color.White
        Me.GunaWinSwitch8.Location = New System.Drawing.Point(265, 163)
        Me.GunaWinSwitch8.Name = "GunaWinSwitch8"
        Me.GunaWinSwitch8.Size = New System.Drawing.Size(40, 22)
        Me.GunaWinSwitch8.TabIndex = 149
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(104, 280)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(116, 20)
        Me.Label7.TabIndex = 148
        Me.Label7.Text = "Όνομα Χρήστη"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label19.Location = New System.Drawing.Point(42, 115)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(189, 20)
        Me.Label19.TabIndex = 146
        Me.Label19.Text = "Απόκρυψη όνομα Χρήστη"
        '
        'GunaWinSwitch10
        '
        Me.GunaWinSwitch10.BaseColor = System.Drawing.SystemColors.Control
        Me.GunaWinSwitch10.CheckedOffColor = System.Drawing.Color.DarkGray
        Me.GunaWinSwitch10.CheckedOnColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaWinSwitch10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaWinSwitch10.FillColor = System.Drawing.Color.White
        Me.GunaWinSwitch10.Location = New System.Drawing.Point(265, 115)
        Me.GunaWinSwitch10.Name = "GunaWinSwitch10"
        Me.GunaWinSwitch10.Size = New System.Drawing.Size(40, 22)
        Me.GunaWinSwitch10.TabIndex = 145
        '
        'GunaSeparator3
        '
        Me.GunaSeparator3.LineColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.GunaSeparator3.Location = New System.Drawing.Point(46, 253)
        Me.GunaSeparator3.Name = "GunaSeparator3"
        Me.GunaSeparator3.Size = New System.Drawing.Size(245, 10)
        Me.GunaSeparator3.TabIndex = 140
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(117, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(47, 25)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(238, 24)
        Me.Label5.TabIndex = 59
        Me.Label5.Text = "Ρυθμίσεις Προφίλ Χρήστη"
        '
        'GradientPanel1
        '
        Me.GradientPanel1.AllowDrop = True
        Me.GradientPanel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(251, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.GradientPanel1.Border3DStyle = System.Windows.Forms.Border3DStyle.Adjust
        Me.GradientPanel1.BorderSingle = System.Windows.Forms.ButtonBorderStyle.Dotted
        Me.GradientPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.GradientPanel1.Controls.Add(Me.Label8)
        Me.GradientPanel1.Location = New System.Drawing.Point(0, 61)
        Me.GradientPanel1.Name = "GradientPanel1"
        Me.GradientPanel1.Size = New System.Drawing.Size(1279, 67)
        Me.GradientPanel1.TabIndex = 138
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(102, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(144, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(958, 25)
        Me.Label8.TabIndex = 118
        Me.Label8.Text = "Για κάθε ρύθμιση που αλλάζετε καλό ειναι να γίνεται ένα Restart της εφαρμογής για" &
    " την ομαλή λειτουργεία της"
        '
        'setts
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1279, 722)
        Me.Controls.Add(Me.GradientPanel1)
        Me.Controls.Add(Me.GunaShadowPanel5)
        Me.Controls.Add(Me.GunaShadowPanel1)
        Me.Controls.Add(Me.GunaShadowPanel4)
        Me.Controls.Add(Me.GunaPanel16)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "setts"
        Me.Text = "setts"
        Me.GunaPanel16.ResumeLayout(False)
        Me.GunaPanel16.PerformLayout()
        CType(Me.GunaPictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GunaShadowPanel4.ResumeLayout(False)
        Me.GunaShadowPanel4.PerformLayout()
        Me.GunaShadowPanel1.ResumeLayout(False)
        Me.GunaShadowPanel1.PerformLayout()
        Me.GunaShadowPanel5.ResumeLayout(False)
        Me.GunaShadowPanel5.PerformLayout()
        CType(Me.GradientPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GradientPanel1.ResumeLayout(False)
        Me.GradientPanel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GunaPanel16 As Guna.UI.WinForms.GunaPanel
    Friend WithEvents GunaButton8 As Guna.UI.WinForms.GunaButton
    Friend WithEvents Label13 As Label
    Friend WithEvents GunaPictureBox3 As Guna.UI.WinForms.GunaPictureBox
    Friend WithEvents GunaShadowPanel4 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label34 As Label
    Friend WithEvents GunaShadowPanel1 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents GunaShadowPanel5 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents Label5 As Label
    Friend WithEvents GradientPanel1 As Syncfusion.Windows.Forms.Tools.GradientPanel
    Friend WithEvents Label8 As Label
    Friend WithEvents GunaWinSwitch1 As Guna.UI.WinForms.GunaWinSwitch
    Friend WithEvents Label3 As Label
    Friend WithEvents GunaSeparator2 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents GunaSeparator1 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents GunaSeparator3 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents Label10 As Label
    Friend WithEvents GunaWinSwitch3 As Guna.UI.WinForms.GunaWinSwitch
    Friend WithEvents Label9 As Label
    Friend WithEvents GunaWinSwitch2 As Guna.UI.WinForms.GunaWinSwitch
    Friend WithEvents GunaComboBox1 As Guna.UI.WinForms.GunaComboBox
    Friend WithEvents GunaSeparator5 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents GunaSeparator4 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents Label11 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents GunaWinSwitch4 As Guna.UI.WinForms.GunaWinSwitch
    Friend WithEvents Label2 As Label
    Friend WithEvents GunaWinSwitch5 As Guna.UI.WinForms.GunaWinSwitch
    Friend WithEvents Label16 As Label
    Friend WithEvents GunaSeparator7 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents GunaAdvenceButton1 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents GunaSeparator6 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents Label4 As Label
    Friend WithEvents GunaWinSwitch6 As Guna.UI.WinForms.GunaWinSwitch
    Friend WithEvents GunaAdvenceButton3 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Label18 As Label
    Friend WithEvents GunaWinSwitch7 As Guna.UI.WinForms.GunaWinSwitch
    Friend WithEvents Label17 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents GunaWinSwitch8 As Guna.UI.WinForms.GunaWinSwitch
    Friend WithEvents Label7 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents GunaWinSwitch10 As Guna.UI.WinForms.GunaWinSwitch
    Friend WithEvents GunaSeparator8 As Guna.UI.WinForms.GunaSeparator
    Friend WithEvents GunaLineTextBox1 As Guna.UI.WinForms.GunaLineTextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents GunaAdvenceTileButton1 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaVSeparator1 As Guna.UI.WinForms.GunaVSeparator
    Friend WithEvents Label20 As Label
    Friend WithEvents GunaAdvenceTileButton10 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
End Class
