﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GunaAdvenceButton1 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.GunaAdvenceButton2 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.GunaAdvenceButton3 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.FlowLayoutPanel4 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.GunaAdvenceButton4 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.FlowLayoutPanel5 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.GunaAdvenceButton5 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.FlowLayoutPanel6 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.GunaAdvenceButton6 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.FlowLayoutPanel7 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.GunaAdvenceButton7 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.FlowLayoutPanel8 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.GunaAdvenceButton8 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.FlowLayoutPanel9 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.GunaAdvenceButton9 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.FlowLayoutPanel10 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.GunaAdvenceButton10 = New Guna.UI.WinForms.GunaAdvenceButton()
        Me.FlowLayoutPanel11 = New System.Windows.Forms.FlowLayoutPanel()
        Me.GunaShadowPanel2 = New Guna.UI.WinForms.GunaShadowPanel()
        Me.GunaAdvenceTileButton1 = New Guna.UI.WinForms.GunaAdvenceTileButton()
        Me.GunaTextBox9 = New Guna.UI.WinForms.GunaTextBox()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.GunaShadowPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel1)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel2)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel2)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel3)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel3)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel4)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel4)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel5)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel5)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel6)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel6)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel7)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel7)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel8)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel8)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel9)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel9)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel10)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel10)
        Me.FlowLayoutPanel1.Controls.Add(Me.FlowLayoutPanel11)
        Me.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(0, 39)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(1167, 661)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel1.Controls.Add(Me.GunaAdvenceButton1)
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1152, 29)
        Me.Panel1.TabIndex = 0
        '
        'GunaAdvenceButton1
        '
        Me.GunaAdvenceButton1.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton1.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton1.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton1.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton1.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton1.CheckedImage = CType(resources.GetObject("GunaAdvenceButton1.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton1.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaAdvenceButton1.ForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton1.Image = CType(resources.GetObject("GunaAdvenceButton1.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton1.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton1.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton1.Location = New System.Drawing.Point(10, 4)
        Me.GunaAdvenceButton1.Name = "GunaAdvenceButton1"
        Me.GunaAdvenceButton1.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton1.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.OnHoverForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton1.OnHoverImage = Nothing
        Me.GunaAdvenceButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton1.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton1.Radius = 3
        Me.GunaAdvenceButton1.Size = New System.Drawing.Size(131, 22)
        Me.GunaAdvenceButton1.TabIndex = 129
        Me.GunaAdvenceButton1.Text = "1ο Εξάμηνο"
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.AutoSize = True
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(1161, 3)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(0, 0)
        Me.FlowLayoutPanel2.TabIndex = 1
        Me.FlowLayoutPanel2.Visible = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel2.Controls.Add(Me.GunaAdvenceButton2)
        Me.Panel2.Location = New System.Drawing.Point(3, 38)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1152, 29)
        Me.Panel2.TabIndex = 2
        '
        'GunaAdvenceButton2
        '
        Me.GunaAdvenceButton2.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton2.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton2.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton2.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton2.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton2.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton2.CheckedImage = CType(resources.GetObject("GunaAdvenceButton2.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton2.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton2.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton2.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaAdvenceButton2.ForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton2.Image = CType(resources.GetObject("GunaAdvenceButton2.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton2.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton2.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton2.Location = New System.Drawing.Point(10, 4)
        Me.GunaAdvenceButton2.Name = "GunaAdvenceButton2"
        Me.GunaAdvenceButton2.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton2.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.OnHoverForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton2.OnHoverImage = Nothing
        Me.GunaAdvenceButton2.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton2.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton2.Radius = 3
        Me.GunaAdvenceButton2.Size = New System.Drawing.Size(131, 22)
        Me.GunaAdvenceButton2.TabIndex = 129
        Me.GunaAdvenceButton2.Text = "2ο Εξάμηνο"
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.AutoSize = True
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(1161, 38)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(0, 0)
        Me.FlowLayoutPanel3.TabIndex = 3
        Me.FlowLayoutPanel3.Visible = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel3.Controls.Add(Me.GunaAdvenceButton3)
        Me.Panel3.Location = New System.Drawing.Point(3, 73)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1152, 29)
        Me.Panel3.TabIndex = 4
        '
        'GunaAdvenceButton3
        '
        Me.GunaAdvenceButton3.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton3.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton3.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton3.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton3.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton3.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton3.CheckedImage = CType(resources.GetObject("GunaAdvenceButton3.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton3.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton3.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton3.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton3.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaAdvenceButton3.ForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton3.Image = CType(resources.GetObject("GunaAdvenceButton3.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton3.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton3.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton3.Location = New System.Drawing.Point(10, 4)
        Me.GunaAdvenceButton3.Name = "GunaAdvenceButton3"
        Me.GunaAdvenceButton3.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton3.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.OnHoverForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton3.OnHoverImage = Nothing
        Me.GunaAdvenceButton3.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton3.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton3.Radius = 3
        Me.GunaAdvenceButton3.Size = New System.Drawing.Size(131, 22)
        Me.GunaAdvenceButton3.TabIndex = 129
        Me.GunaAdvenceButton3.Text = "3ο Εξάμηνο"
        '
        'FlowLayoutPanel4
        '
        Me.FlowLayoutPanel4.AutoSize = True
        Me.FlowLayoutPanel4.Location = New System.Drawing.Point(1161, 73)
        Me.FlowLayoutPanel4.Name = "FlowLayoutPanel4"
        Me.FlowLayoutPanel4.Size = New System.Drawing.Size(0, 0)
        Me.FlowLayoutPanel4.TabIndex = 5
        Me.FlowLayoutPanel4.Visible = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel4.Controls.Add(Me.GunaAdvenceButton4)
        Me.Panel4.Location = New System.Drawing.Point(3, 108)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1152, 29)
        Me.Panel4.TabIndex = 6
        '
        'GunaAdvenceButton4
        '
        Me.GunaAdvenceButton4.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton4.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton4.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton4.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton4.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton4.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton4.CheckedImage = CType(resources.GetObject("GunaAdvenceButton4.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton4.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton4.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton4.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaAdvenceButton4.ForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton4.Image = CType(resources.GetObject("GunaAdvenceButton4.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton4.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton4.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton4.Location = New System.Drawing.Point(10, 4)
        Me.GunaAdvenceButton4.Name = "GunaAdvenceButton4"
        Me.GunaAdvenceButton4.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton4.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.OnHoverForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton4.OnHoverImage = Nothing
        Me.GunaAdvenceButton4.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton4.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton4.Radius = 3
        Me.GunaAdvenceButton4.Size = New System.Drawing.Size(131, 22)
        Me.GunaAdvenceButton4.TabIndex = 129
        Me.GunaAdvenceButton4.Text = "4ο Εξάμηνο"
        '
        'FlowLayoutPanel5
        '
        Me.FlowLayoutPanel5.AutoSize = True
        Me.FlowLayoutPanel5.Location = New System.Drawing.Point(1161, 108)
        Me.FlowLayoutPanel5.Name = "FlowLayoutPanel5"
        Me.FlowLayoutPanel5.Size = New System.Drawing.Size(0, 0)
        Me.FlowLayoutPanel5.TabIndex = 7
        Me.FlowLayoutPanel5.Visible = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel5.Controls.Add(Me.GunaAdvenceButton5)
        Me.Panel5.Location = New System.Drawing.Point(3, 143)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1152, 29)
        Me.Panel5.TabIndex = 8
        '
        'GunaAdvenceButton5
        '
        Me.GunaAdvenceButton5.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton5.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton5.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton5.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton5.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton5.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton5.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton5.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton5.CheckedImage = CType(resources.GetObject("GunaAdvenceButton5.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton5.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton5.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton5.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton5.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaAdvenceButton5.ForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton5.Image = CType(resources.GetObject("GunaAdvenceButton5.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton5.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton5.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton5.Location = New System.Drawing.Point(10, 4)
        Me.GunaAdvenceButton5.Name = "GunaAdvenceButton5"
        Me.GunaAdvenceButton5.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton5.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton5.OnHoverForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton5.OnHoverImage = Nothing
        Me.GunaAdvenceButton5.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton5.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton5.Radius = 3
        Me.GunaAdvenceButton5.Size = New System.Drawing.Size(131, 22)
        Me.GunaAdvenceButton5.TabIndex = 129
        Me.GunaAdvenceButton5.Text = "5ο Εξάμηνο"
        '
        'FlowLayoutPanel6
        '
        Me.FlowLayoutPanel6.AutoSize = True
        Me.FlowLayoutPanel6.Location = New System.Drawing.Point(1161, 143)
        Me.FlowLayoutPanel6.Name = "FlowLayoutPanel6"
        Me.FlowLayoutPanel6.Size = New System.Drawing.Size(0, 0)
        Me.FlowLayoutPanel6.TabIndex = 9
        Me.FlowLayoutPanel6.Visible = False
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel6.Controls.Add(Me.GunaAdvenceButton6)
        Me.Panel6.Location = New System.Drawing.Point(3, 178)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1152, 29)
        Me.Panel6.TabIndex = 10
        '
        'GunaAdvenceButton6
        '
        Me.GunaAdvenceButton6.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton6.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton6.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton6.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton6.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton6.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton6.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton6.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton6.CheckedImage = CType(resources.GetObject("GunaAdvenceButton6.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton6.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton6.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton6.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaAdvenceButton6.ForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton6.Image = CType(resources.GetObject("GunaAdvenceButton6.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton6.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton6.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton6.Location = New System.Drawing.Point(10, 4)
        Me.GunaAdvenceButton6.Name = "GunaAdvenceButton6"
        Me.GunaAdvenceButton6.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton6.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton6.OnHoverForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton6.OnHoverImage = Nothing
        Me.GunaAdvenceButton6.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton6.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton6.Radius = 3
        Me.GunaAdvenceButton6.Size = New System.Drawing.Size(131, 22)
        Me.GunaAdvenceButton6.TabIndex = 129
        Me.GunaAdvenceButton6.Text = "6ο Εξάμηνο"
        '
        'FlowLayoutPanel7
        '
        Me.FlowLayoutPanel7.AutoSize = True
        Me.FlowLayoutPanel7.Location = New System.Drawing.Point(1161, 178)
        Me.FlowLayoutPanel7.Name = "FlowLayoutPanel7"
        Me.FlowLayoutPanel7.Size = New System.Drawing.Size(0, 0)
        Me.FlowLayoutPanel7.TabIndex = 11
        Me.FlowLayoutPanel7.Visible = False
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel7.Controls.Add(Me.GunaAdvenceButton7)
        Me.Panel7.Location = New System.Drawing.Point(3, 213)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(1152, 29)
        Me.Panel7.TabIndex = 12
        '
        'GunaAdvenceButton7
        '
        Me.GunaAdvenceButton7.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton7.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton7.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton7.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton7.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton7.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton7.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton7.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton7.CheckedImage = CType(resources.GetObject("GunaAdvenceButton7.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton7.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton7.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton7.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton7.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaAdvenceButton7.ForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton7.Image = CType(resources.GetObject("GunaAdvenceButton7.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton7.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton7.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton7.Location = New System.Drawing.Point(10, 4)
        Me.GunaAdvenceButton7.Name = "GunaAdvenceButton7"
        Me.GunaAdvenceButton7.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton7.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton7.OnHoverForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton7.OnHoverImage = Nothing
        Me.GunaAdvenceButton7.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton7.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton7.Radius = 3
        Me.GunaAdvenceButton7.Size = New System.Drawing.Size(131, 22)
        Me.GunaAdvenceButton7.TabIndex = 129
        Me.GunaAdvenceButton7.Text = "7ο Εξάμηνο"
        '
        'FlowLayoutPanel8
        '
        Me.FlowLayoutPanel8.AutoSize = True
        Me.FlowLayoutPanel8.Location = New System.Drawing.Point(1161, 213)
        Me.FlowLayoutPanel8.Name = "FlowLayoutPanel8"
        Me.FlowLayoutPanel8.Size = New System.Drawing.Size(0, 0)
        Me.FlowLayoutPanel8.TabIndex = 13
        Me.FlowLayoutPanel8.Visible = False
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel8.Controls.Add(Me.GunaAdvenceButton8)
        Me.Panel8.Location = New System.Drawing.Point(3, 248)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(1152, 29)
        Me.Panel8.TabIndex = 14
        '
        'GunaAdvenceButton8
        '
        Me.GunaAdvenceButton8.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton8.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton8.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton8.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton8.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton8.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton8.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton8.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton8.CheckedImage = CType(resources.GetObject("GunaAdvenceButton8.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton8.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton8.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton8.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton8.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaAdvenceButton8.ForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton8.Image = CType(resources.GetObject("GunaAdvenceButton8.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton8.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton8.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton8.Location = New System.Drawing.Point(10, 4)
        Me.GunaAdvenceButton8.Name = "GunaAdvenceButton8"
        Me.GunaAdvenceButton8.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton8.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton8.OnHoverForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton8.OnHoverImage = Nothing
        Me.GunaAdvenceButton8.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton8.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton8.Radius = 3
        Me.GunaAdvenceButton8.Size = New System.Drawing.Size(131, 22)
        Me.GunaAdvenceButton8.TabIndex = 129
        Me.GunaAdvenceButton8.Text = "8ο Εξάμηνο"
        '
        'FlowLayoutPanel9
        '
        Me.FlowLayoutPanel9.AutoSize = True
        Me.FlowLayoutPanel9.Location = New System.Drawing.Point(1161, 248)
        Me.FlowLayoutPanel9.Name = "FlowLayoutPanel9"
        Me.FlowLayoutPanel9.Size = New System.Drawing.Size(0, 0)
        Me.FlowLayoutPanel9.TabIndex = 15
        Me.FlowLayoutPanel9.Visible = False
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel9.Controls.Add(Me.GunaAdvenceButton9)
        Me.Panel9.Location = New System.Drawing.Point(3, 283)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(1152, 29)
        Me.Panel9.TabIndex = 16
        '
        'GunaAdvenceButton9
        '
        Me.GunaAdvenceButton9.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton9.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton9.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton9.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton9.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton9.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton9.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton9.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton9.CheckedImage = CType(resources.GetObject("GunaAdvenceButton9.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton9.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton9.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton9.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton9.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaAdvenceButton9.ForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton9.Image = CType(resources.GetObject("GunaAdvenceButton9.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton9.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton9.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton9.Location = New System.Drawing.Point(10, 4)
        Me.GunaAdvenceButton9.Name = "GunaAdvenceButton9"
        Me.GunaAdvenceButton9.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton9.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton9.OnHoverForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton9.OnHoverImage = Nothing
        Me.GunaAdvenceButton9.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton9.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton9.Radius = 3
        Me.GunaAdvenceButton9.Size = New System.Drawing.Size(131, 22)
        Me.GunaAdvenceButton9.TabIndex = 129
        Me.GunaAdvenceButton9.Text = "9ο Εξάμηνο"
        '
        'FlowLayoutPanel10
        '
        Me.FlowLayoutPanel10.AutoSize = True
        Me.FlowLayoutPanel10.Location = New System.Drawing.Point(1161, 283)
        Me.FlowLayoutPanel10.Name = "FlowLayoutPanel10"
        Me.FlowLayoutPanel10.Size = New System.Drawing.Size(0, 0)
        Me.FlowLayoutPanel10.TabIndex = 17
        Me.FlowLayoutPanel10.Visible = False
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel10.Controls.Add(Me.GunaAdvenceButton10)
        Me.Panel10.Location = New System.Drawing.Point(3, 318)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(1152, 29)
        Me.Panel10.TabIndex = 18
        '
        'GunaAdvenceButton10
        '
        Me.GunaAdvenceButton10.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceButton10.AnimationSpeed = 0.03!
        Me.GunaAdvenceButton10.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceButton10.BaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton10.BorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton10.CheckedBaseColor = System.Drawing.Color.Gray
        Me.GunaAdvenceButton10.CheckedBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton10.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceButton10.CheckedImage = CType(resources.GetObject("GunaAdvenceButton10.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceButton10.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceButton10.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceButton10.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceButton10.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaAdvenceButton10.ForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton10.Image = CType(resources.GetObject("GunaAdvenceButton10.Image"), System.Drawing.Image)
        Me.GunaAdvenceButton10.ImageSize = New System.Drawing.Size(20, 20)
        Me.GunaAdvenceButton10.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton10.Location = New System.Drawing.Point(10, 4)
        Me.GunaAdvenceButton10.Name = "GunaAdvenceButton10"
        Me.GunaAdvenceButton10.OnHoverBaseColor = System.Drawing.Color.WhiteSmoke
        Me.GunaAdvenceButton10.OnHoverBorderColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton10.OnHoverForeColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceButton10.OnHoverImage = Nothing
        Me.GunaAdvenceButton10.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceButton10.OnPressedColor = System.Drawing.Color.Black
        Me.GunaAdvenceButton10.Radius = 3
        Me.GunaAdvenceButton10.Size = New System.Drawing.Size(183, 22)
        Me.GunaAdvenceButton10.TabIndex = 129
        Me.GunaAdvenceButton10.Text = "Μαθήματα Επιλογής"
        '
        'FlowLayoutPanel11
        '
        Me.FlowLayoutPanel11.AutoSize = True
        Me.FlowLayoutPanel11.Location = New System.Drawing.Point(1161, 318)
        Me.FlowLayoutPanel11.Name = "FlowLayoutPanel11"
        Me.FlowLayoutPanel11.Size = New System.Drawing.Size(0, 0)
        Me.FlowLayoutPanel11.TabIndex = 19
        Me.FlowLayoutPanel11.Visible = False
        '
        'GunaShadowPanel2
        '
        Me.GunaShadowPanel2.BackColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel2.BaseColor = System.Drawing.Color.Transparent
        Me.GunaShadowPanel2.Controls.Add(Me.GunaAdvenceTileButton1)
        Me.GunaShadowPanel2.Location = New System.Drawing.Point(12, 9)
        Me.GunaShadowPanel2.Name = "GunaShadowPanel2"
        Me.GunaShadowPanel2.ShadowColor = System.Drawing.Color.Black
        Me.GunaShadowPanel2.ShadowShift = 1
        Me.GunaShadowPanel2.ShadowStyle = Guna.UI.WinForms.ShadowMode.ForwardDiagonal
        Me.GunaShadowPanel2.Size = New System.Drawing.Size(217, 32)
        Me.GunaShadowPanel2.TabIndex = 42
        Me.GunaShadowPanel2.Visible = False
        '
        'GunaAdvenceTileButton1
        '
        Me.GunaAdvenceTileButton1.AllowDrop = True
        Me.GunaAdvenceTileButton1.Animated = True
        Me.GunaAdvenceTileButton1.AnimationHoverSpeed = 0.07!
        Me.GunaAdvenceTileButton1.AnimationSpeed = 0.03!
        Me.GunaAdvenceTileButton1.BackColor = System.Drawing.Color.Transparent
        Me.GunaAdvenceTileButton1.BaseColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton1.BorderColor = System.Drawing.Color.Gainsboro
        Me.GunaAdvenceTileButton1.BorderSize = 1
        Me.GunaAdvenceTileButton1.CheckedBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton1.CheckedBorderColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton1.CheckedForeColor = System.Drawing.Color.White
        Me.GunaAdvenceTileButton1.CheckedImage = CType(resources.GetObject("GunaAdvenceTileButton1.CheckedImage"), System.Drawing.Image)
        Me.GunaAdvenceTileButton1.CheckedLineColor = System.Drawing.Color.DimGray
        Me.GunaAdvenceTileButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GunaAdvenceTileButton1.DialogResult = System.Windows.Forms.DialogResult.None
        Me.GunaAdvenceTileButton1.FocusedColor = System.Drawing.Color.Empty
        Me.GunaAdvenceTileButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.GunaAdvenceTileButton1.ForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton1.Image = Nothing
        Me.GunaAdvenceTileButton1.ImageSize = New System.Drawing.Size(52, 52)
        Me.GunaAdvenceTileButton1.LineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton1.Location = New System.Drawing.Point(3, 0)
        Me.GunaAdvenceTileButton1.Name = "GunaAdvenceTileButton1"
        Me.GunaAdvenceTileButton1.OnHoverBaseColor = System.Drawing.Color.FromArgb(CType(CType(237, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton1.OnHoverBorderColor = System.Drawing.Color.LightGray
        Me.GunaAdvenceTileButton1.OnHoverForeColor = System.Drawing.Color.Black
        Me.GunaAdvenceTileButton1.OnHoverImage = Nothing
        Me.GunaAdvenceTileButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.GunaAdvenceTileButton1.OnPressedColor = System.Drawing.Color.FromArgb(CType(CType(240, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(233, Byte), Integer))
        Me.GunaAdvenceTileButton1.Radius = 2
        Me.GunaAdvenceTileButton1.Size = New System.Drawing.Size(211, 29)
        Me.GunaAdvenceTileButton1.TabIndex = 2
        Me.GunaAdvenceTileButton1.Text = "Αναζήτηση"
        '
        'GunaTextBox9
        '
        Me.GunaTextBox9.BackColor = System.Drawing.Color.Transparent
        Me.GunaTextBox9.BaseColor = System.Drawing.Color.White
        Me.GunaTextBox9.BorderColor = System.Drawing.Color.Silver
        Me.GunaTextBox9.BorderSize = 0
        Me.GunaTextBox9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GunaTextBox9.FocusedBaseColor = System.Drawing.Color.White
        Me.GunaTextBox9.FocusedBorderColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GunaTextBox9.FocusedForeColor = System.Drawing.SystemColors.ControlText
        Me.GunaTextBox9.Font = New System.Drawing.Font("Segoe UI Semibold", 8.0!)
        Me.GunaTextBox9.ForeColor = System.Drawing.Color.Black
        Me.GunaTextBox9.Location = New System.Drawing.Point(248, 9)
        Me.GunaTextBox9.Name = "GunaTextBox9"
        Me.GunaTextBox9.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GunaTextBox9.Radius = 3
        Me.GunaTextBox9.Size = New System.Drawing.Size(350, 30)
        Me.GunaTextBox9.TabIndex = 73
        Me.GunaTextBox9.Text = "Αναζήτηση Μαθήματος ..."
        Me.GunaTextBox9.Visible = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(1167, 700)
        Me.Controls.Add(Me.GunaTextBox9)
        Me.Controls.Add(Me.GunaShadowPanel2)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.GunaShadowPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents FlowLayoutPanel2 As FlowLayoutPanel
    Friend WithEvents GunaAdvenceButton1 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents Panel2 As Panel
    Friend WithEvents GunaAdvenceButton2 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents FlowLayoutPanel3 As FlowLayoutPanel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents GunaAdvenceButton3 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents FlowLayoutPanel4 As FlowLayoutPanel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents GunaAdvenceButton4 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents FlowLayoutPanel5 As FlowLayoutPanel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents GunaAdvenceButton5 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents FlowLayoutPanel6 As FlowLayoutPanel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents GunaAdvenceButton6 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents FlowLayoutPanel7 As FlowLayoutPanel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents GunaAdvenceButton7 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents FlowLayoutPanel8 As FlowLayoutPanel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents GunaAdvenceButton8 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents FlowLayoutPanel9 As FlowLayoutPanel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents GunaAdvenceButton9 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents FlowLayoutPanel10 As FlowLayoutPanel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents GunaAdvenceButton10 As Guna.UI.WinForms.GunaAdvenceButton
    Friend WithEvents FlowLayoutPanel11 As FlowLayoutPanel
    Friend WithEvents GunaShadowPanel2 As Guna.UI.WinForms.GunaShadowPanel
    Friend WithEvents GunaAdvenceTileButton1 As Guna.UI.WinForms.GunaAdvenceTileButton
    Friend WithEvents GunaTextBox9 As Guna.UI.WinForms.GunaTextBox
End Class
